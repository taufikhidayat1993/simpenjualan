-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.46-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema pabrik
--

CREATE DATABASE IF NOT EXISTS pabrik;
USE pabrik;

--
-- Definition of table `accaktiva`
--

DROP TABLE IF EXISTS `accaktiva`;
CREATE TABLE `accaktiva` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `tglbeli` date NOT NULL DEFAULT '0000-00-00',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `harga` double(15,2) NOT NULL DEFAULT '0.00',
  `residu` double(15,2) NOT NULL DEFAULT '0.00',
  `umur` double(9,0) NOT NULL DEFAULT '0',
  `kelompokid` varchar(30) NOT NULL DEFAULT '',
  `accountid` varchar(30) NOT NULL DEFAULT '',
  `acckas` varchar(30) NOT NULL DEFAULT '',
  `accakumulasi` varchar(30) NOT NULL DEFAULT '',
  `accpenyusutan` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `jurnal` char(1) NOT NULL DEFAULT '',
  `metode` char(1) NOT NULL DEFAULT '',
  `kondisi` char(1) NOT NULL DEFAULT '',
  `aktif` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`kelompokid`,`accountid`,`acckas`,`accakumulasi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accaktiva`
--

/*!40000 ALTER TABLE `accaktiva` DISABLE KEYS */;
INSERT INTO `accaktiva` (`id`,`tanggal`,`tglbeli`,`nama`,`harga`,`residu`,`umur`,`kelompokid`,`accountid`,`acckas`,`accakumulasi`,`accpenyusutan`,`jurnalid`,`jurnal`,`metode`,`kondisi`,`aktif`,`user`,`jam`) VALUES 
 ('20120102-160548','2012-01-01','2012-01-01','ALAT TUTLIS KANTOR',1000000.00,0.00,3,'20120102-155628','140-01','100-01','140-08','140-08','','0','1','1','1','admin','2013-02-03 17:33:56');
/*!40000 ALTER TABLE `accaktiva` ENABLE KEYS */;


--
-- Definition of table `accaktivajurnal`
--

DROP TABLE IF EXISTS `accaktivajurnal`;
CREATE TABLE `accaktivajurnal` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accaktivajurnal`
--

/*!40000 ALTER TABLE `accaktivajurnal` DISABLE KEYS */;
/*!40000 ALTER TABLE `accaktivajurnal` ENABLE KEYS */;


--
-- Definition of table `accaktivajurnaldetail`
--

DROP TABLE IF EXISTS `accaktivajurnaldetail`;
CREATE TABLE `accaktivajurnaldetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `aktivaid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`aktivaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accaktivajurnaldetail`
--

/*!40000 ALTER TABLE `accaktivajurnaldetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `accaktivajurnaldetail` ENABLE KEYS */;


--
-- Definition of table `accaktivakelompok`
--

DROP TABLE IF EXISTS `accaktivakelompok`;
CREATE TABLE `accaktivakelompok` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `jenis` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accaktivakelompok`
--

/*!40000 ALTER TABLE `accaktivakelompok` DISABLE KEYS */;
INSERT INTO `accaktivakelompok` (`id`,`nama`,`jenis`,`user`,`jam`) VALUES 
 ('20120102-155607','AKTIVA LANCAR','1','bumdes','2012-01-02 15:56:07'),
 ('20120102-155628','AKTIVA TETAP','2','bumdes','2012-01-02 15:56:28'),
 ('20120102-155657','PASIVA','3','bumdes','2012-01-02 15:56:57');
/*!40000 ALTER TABLE `accaktivakelompok` ENABLE KEYS */;


--
-- Definition of table `accgrup`
--

DROP TABLE IF EXISTS `accgrup`;
CREATE TABLE `accgrup` (
  `id` int(4) NOT NULL DEFAULT '0',
  `nama` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accgrup`
--

/*!40000 ALTER TABLE `accgrup` DISABLE KEYS */;
INSERT INTO `accgrup` (`id`,`nama`) VALUES 
 (1,'AKTIVA LANCAR'),
 (2,'AKTIVA TETAP'),
 (3,'AKTIVA LAIN'),
 (4,'HUTANG LANCAR'),
 (5,'HUTANG JANGKA PANJANG'),
 (6,'MODAL'),
 (7,'PENDAPATAN'),
 (8,'HPP'),
 (9,'BIAYA');
/*!40000 ALTER TABLE `accgrup` ENABLE KEYS */;


--
-- Definition of table `accheader`
--

DROP TABLE IF EXISTS `accheader`;
CREATE TABLE `accheader` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(300) NOT NULL,
  `grupid` int(4) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`grupid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accheader`
--

/*!40000 ALTER TABLE `accheader` DISABLE KEYS */;
INSERT INTO `accheader` (`id`,`nama`,`grupid`,`keterangan`,`user`,`jam`) VALUES 
 ('100','AKTIVA',1,'','admin','2013-02-03 17:32:18'),
 ('110','BANK',1,'','admin','2010-10-27 08:07:07'),
 ('120','PERSEDIAAN',1,'','admin','2010-10-27 08:29:21'),
 ('150','PIUTANG USAHA',1,'','admin','2010-10-27 08:07:23'),
 ('160','UANG MUKA',1,'','admin','2010-10-27 08:18:17'),
 ('200','PERLENGKAPAN',2,'','admin','2010-10-27 08:28:23'),
 ('301','AKTIVA LAIN LAIN',3,'','admin','2010-10-27 08:10:03'),
 ('400','HUTANG LANCAR',4,'','admin','2010-10-27 08:34:40'),
 ('500','HUTANG JANGKA PANJANG',5,'','admin','2010-10-27 08:35:01'),
 ('600','MODAL',6,'','admin','2010-10-27 08:11:25'),
 ('700','PENDAPATAN PENJUALAN',7,'','admin','2010-10-27 08:11:57'),
 ('702','PENDAPATAN USAHA LAIN',7,'','admin','2010-10-27 08:12:43'),
 ('703','PENDAPATAN DILUAR USAHA',7,'','admin','2010-10-27 08:13:00'),
 ('840','HARGA POKOK PRODUKSI',8,'','admin','2013-03-20 00:00:00'),
 ('850','HARGA POKOK PENJUALAN',8,'','admin','2011-07-26 00:00:00'),
 ('860','BIAYA MARKETING',9,'','admin','2010-10-27 08:13:17'),
 ('861','BIAYA PABRIK',9,'','admin','2010-10-27 08:13:39'),
 ('862','BIAYA ADM. DAN UMUM',9,'','admin','2010-10-27 08:14:04'),
 ('863','BIAYA LAIN LAIN',9,'','admin','2010-10-27 08:14:29');
/*!40000 ALTER TABLE `accheader` ENABLE KEYS */;


--
-- Definition of table `accjurnal`
--

DROP TABLE IF EXISTS `accjurnal`;
CREATE TABLE `accjurnal` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `automated` char(1) NOT NULL,
  `posted` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accjurnal`
--

/*!40000 ALTER TABLE `accjurnal` DISABLE KEYS */;
INSERT INTO `accjurnal` (`id`,`tanggal`,`keterangan`,`automated`,`posted`,`user`,`jam`) VALUES 
 ('ADMN1301290001','2013-01-29','Penjualan No. Bukti:FP.13010001','2','0','admin','2013-02-04 12:54:59'),
 ('ADMN1301300001','2013-01-30','Kasir Rekam Medis No. Bukti:KR.13010001','2','0','admin','2013-02-04 14:40:20'),
 ('ADMN1301310001','2013-01-31','Tutup buku','1','1','admin','2013-01-31 15:30:09'),
 ('ADMN1302020001','2013-02-02','Kasir Laboratorium No. Bukti:KL.13020001','2','0','admin','2013-02-04 12:59:14'),
 ('ADMN1302030001','2013-02-03','','3','0','admin','2013-02-03 17:33:08'),
 ('ADMN1302030002','2013-02-03','','2','0','admin','2013-02-03 17:33:32'),
 ('ADMN1302040005','2013-02-04','Pencairan Penerimaan Cek/Giro Nomor:1asas','2','0','admin','2013-03-21 14:12:28'),
 ('ADMN1302280001','2013-02-28','Tutup buku','1','1','admin','2013-02-03 17:32:38'),
 ('ADMN1303050001','2013-03-05','Pendapatan SPP NIS:Ari','2','0','admin','2013-03-05 10:27:30'),
 ('ADMN1303050002','2013-03-05','Pendapatan SPP NIS:Ari','2','0','admin','2013-03-05 11:14:18'),
 ('ADMN1303060001','2013-03-06','Pendapatan SPP NIS:Ari','2','0','admin','2013-03-05 10:27:43'),
 ('ADMN1303140001','2013-03-14','Terima Barang No. Bukti:TB.13030001','2','0','admin','2013-03-14 14:39:40'),
 ('ADMN1303140002','2013-03-14','Pemakaian Barang No. Bukti:123','2','0','admin','2013-03-14 14:43:35'),
 ('ADMN1303140003','2013-03-14','Revisi Stok No. Bukti: 222','2','0','admin','2013-03-14 15:01:26'),
 ('ADMN1303140004','2013-03-14','Barang Hilang No. Bukti:111','2','0','admin','2013-03-14 15:02:26'),
 ('ADMN1303140005','2013-03-14','Retur Pembelian No. Bukti:RB.13030001','2','0','admin','2013-03-14 15:03:05'),
 ('ADMN1303180001','2013-03-18','Produksi Produk:1-produk 1','2','0','admin','2013-03-21 10:54:31'),
 ('ADMN1303180002','2013-03-18','Revisi Produk No. Bukti: RP.13030001','2','0','admin','2013-03-18 10:56:09'),
 ('ADMN1303200001','2013-03-20','Penjualan No. Bukti:FP.13030001','2','0','admin','2013-03-21 13:52:13'),
 ('ADMN1303200002','2013-03-20','Retur Penjualan No. Bukti:RJ.13030001','2','0','admin','2013-03-20 15:55:19'),
 ('ADMN1303210001','2013-03-21','QC Produk:1-produk 1','2','0','admin','2013-03-21 10:54:16'),
 ('ADMN1303210002','2013-03-21','Penjualan No. Bukti:FP.13030002','2','0','admin','2013-03-21 11:01:46'),
 ('ADMN1303210003','2013-03-21','Pencairan Pengeluaran Cek/Giro Nomor:111','2','0','admin','2013-03-21 13:52:46'),
 ('ADMN1303210004','2013-03-21','Pembayaran Cek/Giro No. Bukti:BG.13030001','2','0','admin','2013-03-21 13:58:55'),
 ('ADMN1303210005','2013-03-21','Pembayaran Transfer No. Bukti:BR.13030001','2','0','admin','2013-03-21 14:03:15'),
 ('ADMN1303210006','2013-03-21','Pembayaran Tunai No. Bukti:BT.13030001','2','0','admin','2013-03-21 14:03:36'),
 ('ADMN1303210007','2013-03-21','Pencairan Pengeluaran Cek/Giro Nomor:111','2','0','admin','2013-03-21 14:03:52'),
 ('ADMN1303210008','2013-03-21','Pendapatan Cek/Giro No. Bukti:TG.13030001','2','0','admin','2013-03-21 14:57:29'),
 ('ADMN1303210009','2013-03-21','Pendapatan Transfer No. Bukti:TR.13030001','2','0','admin','2013-03-21 15:14:30'),
 ('ADMN1303210010','2013-03-21','Pendapatan Tunai No. Bukti:TT.13030001','2','0','admin','2013-03-21 15:20:46'),
 ('ADMN1303210011','2013-03-21','Pendapatan Tunai No. Bukti:TT.13030002','2','0','admin','2013-03-21 15:22:44');
/*!40000 ALTER TABLE `accjurnal` ENABLE KEYS */;


--
-- Definition of table `accjurnaldetail`
--

DROP TABLE IF EXISTS `accjurnaldetail`;
CREATE TABLE `accjurnaldetail` (
  `id` varchar(30) NOT NULL,
  `accountid` varchar(30) NOT NULL,
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `debet` double(15,2) NOT NULL,
  `kredit` double(15,2) NOT NULL,
  KEY `id2` (`id`,`accountid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accjurnaldetail`
--

/*!40000 ALTER TABLE `accjurnaldetail` DISABLE KEYS */;
INSERT INTO `accjurnaldetail` (`id`,`accountid`,`keterangan`,`debet`,`kredit`) VALUES 
 ('ADMN1301310001','701-01','',15006.00,0.00),
 ('ADMN1301310001','701-02','',35000.00,0.00),
 ('ADMN1301310001','850-05','',9988.00,0.00),
 ('ADMN1301310001','850-06','',0.00,28.00),
 ('ADMN1301310001','600-01','',0.00,59966.00),
 ('ADMN1302280001','850-06','',0.00,40.00),
 ('ADMN1302280001','600-01','',40.00,0.00),
 ('ADMN1302030001','100-01','Kas Masuk',10000.00,0.00),
 ('ADMN1302030001','100-01','Kas Masuk',0.00,10000.00),
 ('ADMN1302030002','100-01','',30000.00,0.00),
 ('ADMN1302030002','100-01','',0.00,30000.00),
 ('ADMN1301290001','701-01','',0.00,15000.00),
 ('ADMN1301290001','100-01','',15000.00,0.00),
 ('ADMN1301290001','120-01','',0.00,20.00),
 ('ADMN1301290001','850-06','',20.00,0.00),
 ('ADMN1302020001','100-02','',0.00,5.00),
 ('ADMN1302020001','150-02','',5.00,0.00),
 ('ADMN1302020001','120-01','',0.00,40.00),
 ('ADMN1302020001','850-06','',40.00,0.00),
 ('ADMN1301300001','701-01','',0.00,6.00),
 ('ADMN1301300001','701-02','',0.00,35000.00),
 ('ADMN1301300001','150-02','',35006.00,0.00),
 ('ADMN1301300001','120-01','',0.00,8.00),
 ('ADMN1301300001','850-06','',8.00,0.00),
 ('ADMN1303050001','0','',100000.00,0.00),
 ('ADMN1303050001','700-05','',0.00,100000.00),
 ('ADMN1303060001','0','',20000.00,0.00),
 ('ADMN1303060001','700-05','',0.00,20000.00),
 ('ADMN1303050002','0','',120000.00,0.00),
 ('ADMN1303050002','700-05','',0.00,120000.00),
 ('ADMN1303140001','120-02','',1200000.00,0.00),
 ('ADMN1303140001','400-03','',0.00,1200000.00),
 ('ADMN1303140002','850-06','',120000.00,0.00),
 ('ADMN1303140002','120-02','',0.00,120000.00),
 ('ADMN1303140003','850-05','',0.00,2500000.00),
 ('ADMN1303140003','120-02','',2500000.00,0.00),
 ('ADMN1303140004','850-05','',150000.00,0.00),
 ('ADMN1303140004','120-02','',0.00,150000.00),
 ('ADMN1303140005','120-02','',0.00,60000.00),
 ('ADMN1303140005','400-03','',60000.00,0.00),
 ('ADMN1303180002','850-05','',0.00,975000.00),
 ('ADMN1303180002','120-03','',375000.00,0.00),
 ('ADMN1303180002','120-04','',600000.00,0.00),
 ('ADMN1303200002','850-05','',0.00,2000.00),
 ('ADMN1303200002','700-05','',20000.00,0.00),
 ('ADMN1303200002','100-01','',0.00,18000.00),
 ('ADMN1303200002','120-04','',30000.00,0.00),
 ('ADMN1303200002','850-06','',0.00,30000.00),
 ('ADMN1303210001','120-03','',1000000.00,0.00),
 ('ADMN1303210001','850-07','',200000.00,0.00),
 ('ADMN1303210001','850-06','',0.00,1200000.00),
 ('ADMN1303180001','120-02','',0.00,1200000.00),
 ('ADMN1303180001','840-01','',1200000.00,0.00),
 ('ADMN1303210002','700-05','',0.00,5000.00),
 ('ADMN1303210002','100-01','',5000.00,0.00),
 ('ADMN1303210002','120-03','',0.00,500000.00),
 ('ADMN1303210002','850-06','',500000.00,0.00),
 ('ADMN1303200001','850-05','',2000.00,0.00),
 ('ADMN1303200001','700-05','',0.00,40000.00),
 ('ADMN1303200001','400-07','',0.00,3800.00),
 ('ADMN1303200001','150-02','',41800.00,0.00),
 ('ADMN1303200001','120-04','',0.00,60000.00),
 ('ADMN1303200001','850-06','',60000.00,0.00),
 ('ADMN1303210003','400-14','',1000000.00,0.00),
 ('ADMN1303210003','110-08','',0.00,1000000.00),
 ('ADMN1303210004','400-03','',500000.00,0.00),
 ('ADMN1303210004','400-14','',0.00,500000.00),
 ('ADMN1303210005','400-03','',20000.00,0.00),
 ('ADMN1303210005','110-08','',0.00,20000.00),
 ('ADMN1303210006','400-03','',10000.00,0.00),
 ('ADMN1303210006','100-01','',0.00,10000.00),
 ('ADMN1303210007','400-14','',1000000.00,0.00),
 ('ADMN1303210007','110-08','',0.00,1000000.00),
 ('ADMN1302040005','100-01','',1000.00,0.00),
 ('ADMN1302040005','150-07','',0.00,1000.00),
 ('ADMN1303210008','150-07','',1000.00,0.00),
 ('ADMN1303210008','150-02','',0.00,1000.00),
 ('ADMN1303210009','110-08','',800.00,0.00),
 ('ADMN1303210009','150-02','',0.00,800.00),
 ('ADMN1303210010','100-01','',5000.00,0.00),
 ('ADMN1303210010','150-02','',0.00,5000.00),
 ('ADMN1303210011','100-01','',100000.00,0.00),
 ('ADMN1303210011','150-02','',0.00,100000.00);
/*!40000 ALTER TABLE `accjurnaldetail` ENABLE KEYS */;


--
-- Definition of table `acckas`
--

DROP TABLE IF EXISTS `acckas`;
CREATE TABLE `acckas` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `penyetor` varchar(100) NOT NULL,
  `penerima` varchar(100) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `kas` char(1) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acckas`
--

/*!40000 ALTER TABLE `acckas` DISABLE KEYS */;
INSERT INTO `acckas` (`id`,`tanggal`,`nobukti`,`penyetor`,`penerima`,`keterangan`,`jurnalid`,`kas`,`cetak`,`user`,`jam`) VALUES 
 ('ADMN20130203-173300','2013-02-03','TK.13020001','aa','sasa','','ADMN1302030001','1','0','admin','2013-02-03 17:33:08'),
 ('ADMN20130203-173332','2013-02-03','TB.13020001','','','','ADMN1302030002','0','0','admin','2013-02-03 17:33:32');
/*!40000 ALTER TABLE `acckas` ENABLE KEYS */;


--
-- Definition of table `acckasdetail`
--

DROP TABLE IF EXISTS `acckasdetail`;
CREATE TABLE `acckasdetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `kasid` varchar(30) NOT NULL DEFAULT '',
  `accdebet` varchar(30) NOT NULL DEFAULT '',
  `acckredit` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`kasid`,`accdebet`,`acckredit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acckasdetail`
--

/*!40000 ALTER TABLE `acckasdetail` DISABLE KEYS */;
INSERT INTO `acckasdetail` (`id`,`kasid`,`accdebet`,`acckredit`,`keterangan`,`nominal`) VALUES 
 ('ADMN20130203-173300','bbm20120101-205153','100-01','100-01','',10000.00),
 ('ADMN20130203-173332','bbm20120101-205330','100-01','100-01','dsdsd',30000.00);
/*!40000 ALTER TABLE `acckasdetail` ENABLE KEYS */;


--
-- Definition of table `acckodekas`
--

DROP TABLE IF EXISTS `acckodekas`;
CREATE TABLE `acckodekas` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `kode` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `accdebet` varchar(30) NOT NULL DEFAULT '',
  `acckredit` varchar(30) NOT NULL DEFAULT '',
  `kas` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acckodekas`
--

/*!40000 ALTER TABLE `acckodekas` DISABLE KEYS */;
INSERT INTO `acckodekas` (`id`,`kode`,`nama`,`accdebet`,`acckredit`,`kas`,`user`,`jam`) VALUES 
 ('bbm20120101-205153','0001','Kas Masuk','100-01','100-01','1','admin','2013-02-03 17:32:47'),
 ('bbm20120101-205330','0002','Kas Keluar','100-01','100-01','0','admin','2013-02-03 17:33:20');
/*!40000 ALTER TABLE `acckodekas` ENABLE KEYS */;


--
-- Definition of table `accneraca`
--

DROP TABLE IF EXISTS `accneraca`;
CREATE TABLE `accneraca` (
  `tanggal` date NOT NULL,
  `accountid` varchar(30) NOT NULL,
  `nominal` double(15,2) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  KEY `id` (`tanggal`,`accountid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accneraca`
--

/*!40000 ALTER TABLE `accneraca` DISABLE KEYS */;
INSERT INTO `accneraca` (`tanggal`,`accountid`,`nominal`,`user`,`jam`) VALUES 
 ('2012-12-31','100-01',20000000.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','100-02',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','100-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','100-04',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','110-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','110-02',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','110-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','110-07',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','110-08',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','120-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','120-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','150-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','150-02',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','150-07',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','160-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','160-02',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','160-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','160-05',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','160-06',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','200-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','200-04',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','200-05',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','200-06',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','200-07',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','200-08',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','301-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','301-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','302-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','302-02',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','302-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-02',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-05',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-06',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-07',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-08',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-09',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-10',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-11',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-12',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-13',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-14',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','400-15',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','500-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','500-02',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','500-03',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','500-04',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','500-05',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','500-06',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','600-01',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','600-04',20000000.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','600-05',0.00,'admin','2013-01-31 15:30:04'),
 ('2012-12-31','600-06',0.00,'admin','2013-01-31 15:30:04'),
 ('2013-01-31','100-01',20050006.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','100-02',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','100-03',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','100-04',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','110-01',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','110-02',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','110-03',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','110-07',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','110-08',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','120-01',31960.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','120-03',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','150-01',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','150-02',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','150-07',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','160-01',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','160-02',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','160-03',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','160-05',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','160-06',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','200-01',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','200-04',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','200-05',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','200-06',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','200-07',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','200-08',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','301-01',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','301-03',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','302-01',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','302-02',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','302-03',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-02',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-03',18000.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-05',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-06',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-07',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-08',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-09',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-10',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-11',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-12',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-13',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-14',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','400-15',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','500-01',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','500-02',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','500-03',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','500-04',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','500-05',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','500-06',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','600-01',59966.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','600-04',20004000.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','600-05',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-01-31','600-06',0.00,'admin','2013-01-31 15:30:10'),
 ('2013-02-28','100-01',20050011.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','100-02',-5.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','100-03',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','100-04',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','110-01',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','110-02',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','110-03',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','110-07',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','110-08',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','120-01',31920.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','120-03',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','150-01',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','150-02',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','150-07',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','160-01',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','160-02',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','160-03',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','160-05',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','160-06',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','200-01',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','200-04',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','200-05',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','200-06',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','200-07',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','200-08',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','301-01',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','301-03',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','302-01',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','302-02',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','302-03',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-02',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-03',18000.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-05',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-06',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-07',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-08',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-09',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-10',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-11',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-12',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-13',0.00,'admin','2013-02-03 17:32:38'),
 ('2013-02-28','400-14',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','400-15',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','500-01',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','500-02',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','500-03',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','500-04',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','500-05',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','500-06',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','600-01',59926.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','600-04',20004000.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','600-05',0.00,'admin','2013-02-03 17:32:39'),
 ('2013-02-28','600-06',0.00,'admin','2013-02-03 17:32:39');
/*!40000 ALTER TABLE `accneraca` ENABLE KEYS */;


--
-- Definition of table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(300) NOT NULL,
  `headerid` varchar(30) NOT NULL,
  `tipe` varchar(10) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`headerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`,`nama`,`headerid`,`tipe`,`user`,`jam`) VALUES 
 ('100-01','KAS BESAR','100','Debet','admin','2012-11-08 13:14:00'),
 ('100-02','KAS KECIL','100','Debet','admin','2010-10-27 08:36:19'),
 ('100-03','KAS BON SEMENTARA','100','Debet','admin','2010-10-27 08:36:38'),
 ('100-04','SURAT BERHARGA','100','Debet','admin','2010-12-16 09:33:00'),
 ('110-01','BANK SYARIAH MANDIRI','110','Debet','admin','2010-10-27 08:37:04'),
 ('110-02','BANK NIAGA ','110','Debet','admin','2010-10-27 08:37:22'),
 ('110-03','BANK BNI ','110','Debet','admin','2010-10-27 08:37:50'),
 ('110-07','BANK BUKOPIN','110','Debet','admin','2010-10-27 08:40:26'),
 ('110-08','BANK BCA','110','Debet','admin','2010-10-27 08:40:41'),
 ('120-01','PERSEDIAAN LOGISTIK','120','Debet','admin','2013-03-01 15:06:06'),
 ('120-02','PERSEDIAAN BAHAN BAKU','120','Debet','admin','2013-03-14 12:46:31'),
 ('120-03','PERSEDIAAN BARANG','120','Debet','admin','2010-11-26 08:56:38'),
 ('120-04','PERSEDIAAN PRODUK','120','Debet','admin','2013-03-15 10:05:50'),
 ('150-01','PIUTANG PENJUALAN','150','Debet','admin','2013-03-01 15:05:55'),
 ('150-07','PIUTANG LAIN LAIN','150','Debet','admin','2010-10-27 15:41:10'),
 ('160-01','PERSEKOT PPH 21','160','Debet','admin','2010-10-27 08:48:43'),
 ('160-02','PERSEKOT PPH 25','160','Debet','admin','2010-10-27 08:49:21'),
 ('160-03','PERSEKOT PEMBELIAN','160','Debet','admin','2010-10-27 08:49:47'),
 ('160-05','PERSEKOT SEWA','160','Debet','admin','2010-10-27 08:50:37'),
 ('160-06','PERSEKOT BIAYA LAIN LAIN','160','Debet','admin','2010-10-27 08:50:56'),
 ('200-01','PERLENGKAPAN PABRIK','200','Debet','admin','2010-10-27 08:51:51'),
 ('200-04','PERLENGKAPAN UMUM','200','Debet','admin','2010-10-27 08:52:49'),
 ('200-05','BANGUNAN','200','Debet','admin','2010-10-27 08:53:24'),
 ('200-06','TANAH','200','Debet','admin','2010-10-27 08:53:41'),
 ('200-07','INVENTARIS','200','Debet','admin','2010-12-16 09:39:32'),
 ('200-08','KENDARAAN','200','Debet','admin','2010-10-27 08:54:24'),
 ('301-01','PIUTANG PAJAK','301','Debet','admin','2010-10-27 09:02:23'),
 ('301-03','DANA PIHAK KETIGA','301','Debet','admin','2010-10-27 09:03:17'),
 ('302-01','AKUMULASI DEPRESIASI BANGUNAN','301','Debet','admin','2010-10-27 09:04:16'),
 ('302-02','AKUMULASI DEPRESIASI INVENTARIS','301','Debet','admin','2010-12-16 09:39:56'),
 ('302-03','AKUMULASI DEPRESIASI KENDARAAN','301','Debet','admin','2010-10-27 09:06:03'),
 ('400-02','HUTANG BARANG ELEKTRONIK','400','Kredit','admin','2010-10-27 09:07:59'),
 ('400-03','HUTANG PEMBELIAN BARANG TOKO','400','Kredit','admin','2010-10-27 09:08:21'),
 ('400-05','HUTANG BARANG KONSINYASI','400','Kredit','admin','2010-10-27 09:09:49'),
 ('400-06','HUTANG BIAYA GAJI KARYAWAN','400','Kredit','admin','2010-10-27 09:10:10'),
 ('400-07','HUTANG PPN','400','Kredit','admin','2010-10-27 09:10:32'),
 ('400-08','DANA PENGEMBANGAN MASYARAKAT','400','Kredit','admin','2010-10-27 09:11:00'),
 ('400-09','DANA CADANGAN PENDIDIKAN','400','Kredit','admin','2010-10-27 09:11:30'),
 ('400-10','DANA PEMBANGUNAN DAERAH','400','Kredit','admin','2010-10-27 09:11:56'),
 ('400-11','DANA SOSIAL','400','Kredit','admin','2010-10-27 09:12:23'),
 ('400-12','HUTANG INVESTASI','400','Kredit','admin','2010-10-27 09:12:52'),
 ('400-13','DANA PENGURUS','400','Kredit','admin','2010-10-27 09:13:12'),
 ('400-14','HUTANG LAIN LAIN','400','Kredit','admin','2010-10-27 09:13:35'),
 ('400-15','DANA KGC','400','Kredit','admin','2010-10-27 09:13:55'),
 ('500-01','HUTANG BANK SYARIAH MANDIRI','500','Kredit','admin','2010-10-27 09:14:22'),
 ('500-02','HUTANG BANK NIAGA','500','Kredit','admin','2010-10-27 09:14:54'),
 ('500-03','HUTANG BANK BUKOPIN','500','Kredit','admin','2010-10-27 09:15:21'),
 ('500-04','HUTANG BANK BNI','500','Kredit','admin','2010-10-27 09:15:45'),
 ('500-05','HUTANG KE DINAS KOPERASI','500','Kredit','admin','2010-10-27 09:16:04'),
 ('500-06','HUTANG ','500','Kredit','admin','2010-10-27 09:16:25'),
 ('600-01','LABA SEBELUM PAJAK','600','Kredit','admin','2010-10-27 09:17:20'),
 ('600-04','MODAL CADANGAN','600','Kredit','admin','2010-10-27 09:18:50'),
 ('600-05','MODAL DONASI','600','Kredit','admin','2010-10-27 09:19:10'),
 ('600-06','LABA YANG DITAHAN','600','Kredit','admin','2010-10-27 09:19:31'),
 ('700-05','PENDAPATAN PENJUALAN','700','Debet','admin','2013-03-15 10:06:13'),
 ('701-02','PENDAPATAN LAIN-LAIN','700','Debet','admin','2013-03-21 08:36:29'),
 ('703-01','PENDAPATAN BUNGA BANK','703','Debet','admin','2010-10-27 09:25:43'),
 ('840-01','HARGA POKOK PRODUKSI','840','Debet','admin','2013-03-20 00:00:00'),
 ('850-01','PEMBELIAN','850','Debet','admin','2011-07-26 00:00:00'),
 ('850-02','POTONGAN PEMBELIAN','850','Kredit','admin','2011-07-26 00:00:00'),
 ('850-03','RETUR PEMBELIAN','850','Kredit','admin','2011-07-26 00:00:00'),
 ('850-04','ONGKOS ANGKUT PEMBELIAN','850','Debet','admin','2011-07-26 00:00:00'),
 ('850-05','BEBAN PENJUALAN LAINNYA','850','Debet','admin','2011-07-26 00:00:00'),
 ('850-06','HARGA POKOK PENJUALAN','850','Debet','admin','2011-07-26 00:00:00'),
 ('850-07','PRODUK GAGAL','850','Debet','admin','2013-03-21 08:44:54'),
 ('860-01','BIAYA GAJI KARYAWAN','860','Debet','admin','2010-10-27 09:28:07'),
 ('860-02','BIAYA LEMBUR KARYAWAN','860','Debet','admin','2010-10-27 09:28:30'),
 ('860-03','BIAYA HONOR PEGURUS','860','Debet','admin','2010-10-27 09:28:57'),
 ('860-04','BIAYA BONUS KARYAWAN','860','Debet','admin','2010-10-27 09:29:22'),
 ('860-05','BIAYA PESANGON KARYAWAN','860','Debet','admin','2010-10-27 09:29:46'),
 ('860-06','BIAYA ASURANSI/JAMSOSTEK KARYAWAN','860','Debet','admin','2010-10-27 09:30:12'),
 ('860-07','BIAYA ADMINISTRASI PINJAMAN','860','Debet','admin','2010-10-27 09:30:48'),
 ('861-01','TUNJANGAN TRANSPORT','861','Debet','admin','2010-10-27 09:31:12'),
 ('861-02','TUNJANGAN SHIFT','861','Debet','admin','2010-10-27 09:31:29'),
 ('861-03','TUNJANGAN CUTI','861','Debet','admin','2010-10-27 09:31:44'),
 ('861-04','TUNJANGAN TELEPON','861','Debet','admin','2010-10-27 09:32:02'),
 ('861-05','TUNJANGAN PENGOBATAN KARYAWAN','861','Debet','admin','2010-10-27 09:32:27'),
 ('861-06','TUNJANGAN PPH 21 KARYAWAN','861','Debet','admin','2010-10-27 09:33:08'),
 ('861-07','TUNJANGAN HARI RAYA','861','Debet','admin','2010-10-27 09:33:25'),
 ('861-08','TUNJANGAN PERUMAHAN','861','Debet','admin','2010-10-27 09:33:45'),
 ('861-09','TUNJANGAN JABATAN','861','Debet','admin','2010-11-25 14:55:27'),
 ('862-01','BIAYA PERALATAN','862','Debet','admin','2010-10-27 09:34:09'),
 ('862-02','BIAYA PERLEGKAPAN','862','Debet','admin','2010-10-27 09:34:26'),
 ('862-03','BIAYA PEMELIHARAAN KOMPUTER DAN SISTEM','862','Debet','admin','2010-10-27 09:34:49'),
 ('862-04','BIAYA PEMELIHARAAN KENDARAAN','862','Debet','admin','2010-10-27 09:35:10'),
 ('862-05','BIAYA TELEPON','862','Debet','admin','2010-10-27 09:35:31'),
 ('862-06','BIAYA LISTRIK','862','Debet','admin','2010-10-27 09:35:49'),
 ('862-07','BIAYA BAHAN BAKAR KENDARAAN','862','Debet','admin','2010-10-27 09:36:08'),
 ('862-08','BIAYA AUDIT','862','Debet','admin','2010-10-27 09:36:21'),
 ('862-09','BIAYA PERJALAN DINAS','862','Debet','admin','2010-10-27 09:36:45'),
 ('862-10','BIAYA BANK','862','Debet','admin','2010-10-27 09:37:03'),
 ('862-11','BIAYA RAPAT DAN JAMUAN','862','Debet','admin','2010-10-27 09:37:23'),
 ('862-12','BIAYA MATERAI','862','Debet','admin','2010-10-27 09:37:40'),
 ('862-13','BIAYA PERIJINAN','862','Debet','admin','2010-10-27 09:37:58'),
 ('862-14','BIAYA POS DAN KURIR','862','Debet','admin','2010-10-27 09:38:19'),
 ('862-15','BIAYA IKLAN DAN PROMOSI','862','Debet','admin','2010-10-27 09:38:41'),
 ('862-16','BIAYA PENGEMBANGAN/PEMBINAAN ANGOTA','862','Debet','admin','2010-10-27 09:39:13'),
 ('862-17','BIAYA PENGIRIMAN BARANG','862','Debet','admin','2010-10-27 09:39:37'),
 ('862-18','BIAYA TRAINING','862','Debet','admin','2010-10-27 09:40:05'),
 ('862-19','BIAYA MAKAN DAN MINUM KARYAWAN','862','Debet','admin','2010-10-27 09:40:30'),
 ('862-20','BIAYA PPN','862','Debet','admin','2010-10-27 09:40:44'),
 ('862-21','BIAYA PEREKRUTAN KARYAWAN','862','Debet','admin','2010-10-27 09:41:08'),
 ('862-22','BIAYA ADM. & ASURANSI PINJAMAN BANK','862','Debet','admin','2010-10-27 09:41:42'),
 ('862-23','BIAYA BUNGA PINJAMAN BANK','862','Debet','admin','2010-10-27 09:42:08'),
 ('862-24','BIAYA BUNGA SIMPANAN SUKARELA','862','Debet','admin','2010-10-27 09:43:37'),
 ('862-25','BIAYA BUNGA PINJAMAN DISKOP PROP','862','Debet','admin','2010-10-27 09:44:06'),
 ('862-26','BIAYA BERLANGGANAN','862','Debet','admin','2010-10-27 09:44:25'),
 ('862-27','BIAYA SUMBANGAN','862','Debet','admin','2010-10-27 09:44:40'),
 ('862-28','BIAYA HADIAH DAN PENGHARGAAN','862','Debet','admin','2010-10-27 09:45:00'),
 ('862-29','BIAYA KONSULTAN / PIHAK KETIGA','862','Debet','admin','2010-10-27 09:45:28'),
 ('862-31','BIAYA TRANSPORT OPERASIONAL','862','Debet','admin','2010-10-27 09:46:25'),
 ('862-32','BIAYA PPH','862','Debet','admin','2010-10-27 09:46:45'),
 ('862-33','BIAYA KLAIM ASURANSI','862','Debet','admin','2010-10-27 09:47:01'),
 ('862-34','BIAYA INSENTIF PERJALANAN DINAS','862','Debet','admin','2010-10-27 09:47:26'),
 ('862-35','BIAYA PEMBELIAN BARANG TOKO','862','Debet','admin','2010-10-27 15:34:44'),
 ('862-36','BIAYA ASURANSI PINJ REGULER','862','Debet','admin','2010-12-01 14:12:41'),
 ('863-01','BIAYA PENYUSUTAN PERSEDIAAN','863','Debet','admin','2010-10-27 09:47:50'),
 ('863-02','AMORTISASI AKTIVA','863','Debet','admin','2010-11-30 09:53:33'),
 ('863-03','AKUMULASI DEPRESIASI MOBIL','863','Debet','admin','2010-11-30 10:47:24'),
 ('863-04','BIAYA PENYUSUTAN SEPEDA MOTOR','863','Debet','admin','2010-10-27 09:49:02'),
 ('863-05','INVENTORY ADJUSTMENT - PRICE VARIANCE','863','Debet','admin','2010-10-27 09:49:36'),
 ('863-06','INVENTORY ADJUSTMENT - QUANTITY','863','Debet','admin','2010-10-27 09:50:06'),
 ('863-07','BIAYA KERUSAKAN BARANG TOKO','863','Debet','admin','2010-10-27 09:50:24'),
 ('863-08','DISKON TUNAI','863','Debet','admin','2010-10-27 09:50:41'),
 ('863-09','BIAYA DENDA','863','Debet','admin','2010-10-27 09:51:00'),
 ('863-10','BIAYA LAIN LAIN','863','Debet','admin','2010-10-27 09:51:16'),
 ('863-11','BIAYA DANA PENSIUN','863','Debet','admin','2010-10-27 09:51:31'),
 ('863-12','BIAYA MAINTENANCE','863','Debet','admin','2010-10-27 09:51:47'),
 ('863-13','BIAYA KEHILANGAN BARANG TOKO','863','Debet','admin','2010-12-01 09:25:45'),
 ('863-14','AKM. AMORTISASI AKTIVA','863','Kredit','admin','2010-11-30 09:59:49'),
 ('863-15','DEPRESIASI KENDARAAN','863','Debet','admin','2010-11-30 09:34:23');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;


--
-- Definition of table `agama`
--

DROP TABLE IF EXISTS `agama`;
CREATE TABLE `agama` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) DEFAULT NULL,
  `user` varchar(30) DEFAULT NULL,
  `jam` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agama`
--

/*!40000 ALTER TABLE `agama` DISABLE KEYS */;
INSERT INTO `agama` (`id`,`nama`,`user`,`jam`) VALUES 
 ('20090628-000339','Katholik','admin','2009-06-28 00:03:39'),
 ('20090628-000351','Kristen','admin','2009-06-28 00:03:51'),
 ('20090628-000357','Islam','admin','2009-06-28 00:03:57'),
 ('20090628-000415','Budha','admin','2009-06-28 00:04:15'),
 ('20090628-000423','Hindu','admin','2009-06-28 00:04:23');
/*!40000 ALTER TABLE `agama` ENABLE KEYS */;


--
-- Definition of table `barang`
--

DROP TABLE IF EXISTS `barang`;
CREATE TABLE `barang` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kategoriid` varchar(30) NOT NULL,
  `accountid` varchar(30) NOT NULL DEFAULT '',
  `acchpp` varchar(30) NOT NULL DEFAULT '',
  `hargastok` double(15,2) NOT NULL,
  `minimal` double(9,2) NOT NULL,
  `expired` char(1) NOT NULL DEFAULT '',
  `logistik` char(1) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`satuanid`,`kategoriid`,`accountid`,`acchpp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

/*!40000 ALTER TABLE `barang` DISABLE KEYS */;
INSERT INTO `barang` (`id`,`nama`,`satuanid`,`kategoriid`,`accountid`,`acchpp`,`hargastok`,`minimal`,`expired`,`logistik`,`aktif`,`user`,`jam`) VALUES 
 ('1','bahan 1','20130314-124420','20130314-124414','120-02','840-01',1000.00,5000.00,'2','0','1','admin','2013-03-20 09:56:45'),
 ('2','Kertas HVS','20130227-093757','20130227-093722','120-01','840-01',30000.00,5.00,'3','1','1','admin','2013-03-20 09:56:55'),
 ('3','bahan 2','20130314-124420','20130227-093722','120-02','840-01',900.00,100.00,'3','0','1','admin','2013-03-20 09:57:06');
/*!40000 ALTER TABLE `barang` ENABLE KEYS */;


--
-- Definition of table `brgkategori`
--

DROP TABLE IF EXISTS `brgkategori`;
CREATE TABLE `brgkategori` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brgkategori`
--

/*!40000 ALTER TABLE `brgkategori` DISABLE KEYS */;
INSERT INTO `brgkategori` (`id`,`nama`,`aktif`,`user`,`jam`) VALUES 
 ('20130227-093718','Buku','1','admin','2013-02-27 09:37:18'),
 ('20130227-093722','Alat Tulis','1','admin','2013-02-27 09:37:22'),
 ('20130314-124414','Bahan Baku','1','admin','2013-03-14 12:44:14');
/*!40000 ALTER TABLE `brgkategori` ENABLE KEYS */;


--
-- Definition of table `brgsatuan`
--

DROP TABLE IF EXISTS `brgsatuan`;
CREATE TABLE `brgsatuan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brgsatuan`
--

/*!40000 ALTER TABLE `brgsatuan` DISABLE KEYS */;
INSERT INTO `brgsatuan` (`id`,`nama`,`user`,`jam`) VALUES 
 ('20130227-093757','Unit','admin','2013-02-27 09:37:57'),
 ('20130314-124420','Kg','admin','2013-03-14 12:44:20');
/*!40000 ALTER TABLE `brgsatuan` ENABLE KEYS */;


--
-- Definition of table `departemen`
--

DROP TABLE IF EXISTS `departemen`;
CREATE TABLE `departemen` (
  `id` varchar(30) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departemen`
--

/*!40000 ALTER TABLE `departemen` DISABLE KEYS */;
INSERT INTO `departemen` (`id`,`kode`,`nama`,`aktif`,`user`,`jam`) VALUES 
 ('20130314-091006','D1','Departemen 1','1','admin','2013-03-14 09:22:32');
/*!40000 ALTER TABLE `departemen` ENABLE KEYS */;


--
-- Definition of table `gudang`
--

DROP TABLE IF EXISTS `gudang`;
CREATE TABLE `gudang` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `departemenid` varchar(30) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`departemenid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudang`
--

/*!40000 ALTER TABLE `gudang` DISABLE KEYS */;
INSERT INTO `gudang` (`id`,`nama`,`departemenid`,`user`,`jam`) VALUES 
 ('20130125-160132','Gudang 1','20130314-091006','admin','2013-03-14 14:13:31'),
 ('20130125-160143','Gudang 2','20130314-091006','admin','2013-03-14 14:00:50');
/*!40000 ALTER TABLE `gudang` ENABLE KEYS */;


--
-- Definition of table `gudhilang`
--

DROP TABLE IF EXISTS `gudhilang`;
CREATE TABLE `gudhilang` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `gudangid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`gudangid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudhilang`
--

/*!40000 ALTER TABLE `gudhilang` DISABLE KEYS */;
INSERT INTO `gudhilang` (`id`,`tanggal`,`nobukti`,`gudangid`,`jurnalid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('ADMN20130314-150226','2013-03-14','111','20130125-160132','ADMN1303140004','','0','admin','2013-03-14 15:02:26');
/*!40000 ALTER TABLE `gudhilang` ENABLE KEYS */;


--
-- Definition of table `gudhilangdetail`
--

DROP TABLE IF EXISTS `gudhilangdetail`;
CREATE TABLE `gudhilangdetail` (
  `id` varchar(30) NOT NULL,
  `id2` varchar(10) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudhilangdetail`
--

/*!40000 ALTER TABLE `gudhilangdetail` DISABLE KEYS */;
INSERT INTO `gudhilangdetail` (`id`,`id2`,`barangid`,`satuanid`,`kuantitas`) VALUES 
 ('ADMN20130314-150226','1','1','20130314-124420',150.00);
/*!40000 ALTER TABLE `gudhilangdetail` ENABLE KEYS */;


--
-- Definition of table `gudhilangdetail2`
--

DROP TABLE IF EXISTS `gudhilangdetail2`;
CREATE TABLE `gudhilangdetail2` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `terimaid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`terimaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudhilangdetail2`
--

/*!40000 ALTER TABLE `gudhilangdetail2` DISABLE KEYS */;
INSERT INTO `gudhilangdetail2` (`id`,`barangid`,`terimaid`,`kuantitas`,`harga`) VALUES 
 ('ADMN20130314-150226','1','ADMN20130314-150126',150.00,1000.00);
/*!40000 ALTER TABLE `gudhilangdetail2` ENABLE KEYS */;


--
-- Definition of table `gudminta`
--

DROP TABLE IF EXISTS `gudminta`;
CREATE TABLE `gudminta` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `departemenid` varchar(30) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`departemenid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudminta`
--

/*!40000 ALTER TABLE `gudminta` DISABLE KEYS */;
INSERT INTO `gudminta` (`id`,`tanggal`,`nobukti`,`departemenid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('ADMN20130314-131828','2013-03-14','123','20130314-091006','','0','admin','2013-03-14 14:13:37');
/*!40000 ALTER TABLE `gudminta` ENABLE KEYS */;


--
-- Definition of table `gudmintadetail`
--

DROP TABLE IF EXISTS `gudmintadetail`;
CREATE TABLE `gudmintadetail` (
  `id` varchar(30) NOT NULL,
  `id2` varchar(10) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudmintadetail`
--

/*!40000 ALTER TABLE `gudmintadetail` DISABLE KEYS */;
INSERT INTO `gudmintadetail` (`id`,`id2`,`barangid`,`satuanid`,`kuantitas`) VALUES 
 ('ADMN20130314-131828','1','1','20130314-124420',10000.00);
/*!40000 ALTER TABLE `gudmintadetail` ENABLE KEYS */;


--
-- Definition of table `gudpakai`
--

DROP TABLE IF EXISTS `gudpakai`;
CREATE TABLE `gudpakai` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `gudangid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`gudangid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudpakai`
--

/*!40000 ALTER TABLE `gudpakai` DISABLE KEYS */;
INSERT INTO `gudpakai` (`id`,`tanggal`,`nobukti`,`gudangid`,`jurnalid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('ADMN20130314-144335','2013-03-14','123','20130125-160132','ADMN1303140002','','0','admin','2013-03-14 14:43:35');
/*!40000 ALTER TABLE `gudpakai` ENABLE KEYS */;


--
-- Definition of table `gudpakaidetail`
--

DROP TABLE IF EXISTS `gudpakaidetail`;
CREATE TABLE `gudpakaidetail` (
  `id` varchar(30) NOT NULL,
  `id2` varchar(10) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `accountid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudpakaidetail`
--

/*!40000 ALTER TABLE `gudpakaidetail` DISABLE KEYS */;
INSERT INTO `gudpakaidetail` (`id`,`id2`,`barangid`,`satuanid`,`accountid`,`kuantitas`) VALUES 
 ('ADMN20130314-144335','1','1','20130314-124420','850-06',100.00);
/*!40000 ALTER TABLE `gudpakaidetail` ENABLE KEYS */;


--
-- Definition of table `gudpakaidetail2`
--

DROP TABLE IF EXISTS `gudpakaidetail2`;
CREATE TABLE `gudpakaidetail2` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `terimaid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`terimaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudpakaidetail2`
--

/*!40000 ALTER TABLE `gudpakaidetail2` DISABLE KEYS */;
INSERT INTO `gudpakaidetail2` (`id`,`barangid`,`terimaid`,`kuantitas`,`harga`) VALUES 
 ('ADMN20130314-144335','1','ADMN20130314-143940',100.00,1200.00);
/*!40000 ALTER TABLE `gudpakaidetail2` ENABLE KEYS */;


--
-- Definition of table `gudpindah`
--

DROP TABLE IF EXISTS `gudpindah`;
CREATE TABLE `gudpindah` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `gudangid1` varchar(30) NOT NULL,
  `gudangid2` varchar(30) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`gudangid1`,`gudangid2`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudpindah`
--

/*!40000 ALTER TABLE `gudpindah` DISABLE KEYS */;
INSERT INTO `gudpindah` (`id`,`tanggal`,`nobukti`,`gudangid1`,`gudangid2`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130314-144729','2013-03-14','234','20130125-160132','20130125-160143','','0','admin','2013-03-14 14:47:29');
/*!40000 ALTER TABLE `gudpindah` ENABLE KEYS */;


--
-- Definition of table `gudpindahdetail`
--

DROP TABLE IF EXISTS `gudpindahdetail`;
CREATE TABLE `gudpindahdetail` (
  `id` varchar(30) NOT NULL,
  `id2` varchar(10) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudpindahdetail`
--

/*!40000 ALTER TABLE `gudpindahdetail` DISABLE KEYS */;
INSERT INTO `gudpindahdetail` (`id`,`id2`,`barangid`,`satuanid`,`kuantitas`) VALUES 
 ('20130314-144729','1','1','20130314-124420',200.00);
/*!40000 ALTER TABLE `gudpindahdetail` ENABLE KEYS */;


--
-- Definition of table `gudpindahdetail2`
--

DROP TABLE IF EXISTS `gudpindahdetail2`;
CREATE TABLE `gudpindahdetail2` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `terimaid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`terimaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudpindahdetail2`
--

/*!40000 ALTER TABLE `gudpindahdetail2` DISABLE KEYS */;
/*!40000 ALTER TABLE `gudpindahdetail2` ENABLE KEYS */;


--
-- Definition of table `gudrevisi`
--

DROP TABLE IF EXISTS `gudrevisi`;
CREATE TABLE `gudrevisi` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `gudangid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`gudangid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudrevisi`
--

/*!40000 ALTER TABLE `gudrevisi` DISABLE KEYS */;
INSERT INTO `gudrevisi` (`id`,`tanggal`,`nobukti`,`gudangid`,`jurnalid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('ADMN20130314-150126','2013-03-14','222','20130125-160132','ADMN1303140003','','0','admin','2013-03-14 15:01:26');
/*!40000 ALTER TABLE `gudrevisi` ENABLE KEYS */;


--
-- Definition of table `gudrevisidetail`
--

DROP TABLE IF EXISTS `gudrevisidetail`;
CREATE TABLE `gudrevisidetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL,
  `barangid` varchar(30) NOT NULL DEFAULT '',
  `satuanid` varchar(30) NOT NULL DEFAULT '',
  `kuantitas` double(9,2) NOT NULL DEFAULT '0.00',
  `harga` double(15,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudrevisidetail`
--

/*!40000 ALTER TABLE `gudrevisidetail` DISABLE KEYS */;
INSERT INTO `gudrevisidetail` (`id`,`id2`,`barangid`,`satuanid`,`kuantitas`,`harga`) VALUES 
 ('ADMN20130314-150126','1','1','20130314-124420',2500.00,1000.00);
/*!40000 ALTER TABLE `gudrevisidetail` ENABLE KEYS */;


--
-- Definition of table `gudterima`
--

DROP TABLE IF EXISTS `gudterima`;
CREATE TABLE `gudterima` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `pembelianid` varchar(30) NOT NULL,
  `departemenid` varchar(30) NOT NULL,
  `gudangid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pembelianid`,`departemenid`,`gudangid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudterima`
--

/*!40000 ALTER TABLE `gudterima` DISABLE KEYS */;
INSERT INTO `gudterima` (`id`,`tanggal`,`nobukti`,`pembelianid`,`departemenid`,`gudangid`,`jurnalid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('ADMN20130314-143940','2013-03-14','TB.13030001','20130314-141618','20130314-091006','20130125-160132','ADMN1303140001','','0','admin','2013-03-14 14:39:40');
/*!40000 ALTER TABLE `gudterima` ENABLE KEYS */;


--
-- Definition of table `gudterimadetail`
--

DROP TABLE IF EXISTS `gudterimadetail`;
CREATE TABLE `gudterimadetail` (
  `id` varchar(30) NOT NULL,
  `id2` varchar(10) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `expired` char(1) NOT NULL,
  `tglexpired` date NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gudterimadetail`
--

/*!40000 ALTER TABLE `gudterimadetail` DISABLE KEYS */;
INSERT INTO `gudterimadetail` (`id`,`id2`,`barangid`,`satuanid`,`expired`,`tglexpired`,`kuantitas`) VALUES 
 ('ADMN20130314-143940','1','1','20130314-124420','0','2013-03-14',1000.00);
/*!40000 ALTER TABLE `gudterimadetail` ENABLE KEYS */;


--
-- Definition of table `hrdabsen`
--

DROP TABLE IF EXISTS `hrdabsen`;
CREATE TABLE `hrdabsen` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `karyawanid` varchar(30) NOT NULL DEFAULT '',
  `lama` double(9,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`karyawanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdabsen`
--

/*!40000 ALTER TABLE `hrdabsen` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdabsen` ENABLE KEYS */;


--
-- Definition of table `hrdbagian`
--

DROP TABLE IF EXISTS `hrdbagian`;
CREATE TABLE `hrdbagian` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdbagian`
--

/*!40000 ALTER TABLE `hrdbagian` DISABLE KEYS */;
INSERT INTO `hrdbagian` (`id`,`nama`,`user`,`jam`) VALUES 
 ('20130128-125941','Tenaga Pengajar','admin','2013-03-03 16:19:52'),
 ('20130128-130016','Administrasi','admin','2013-01-28 13:00:16'),
 ('20130128-130020','Accounting','admin','2013-01-28 13:00:20');
/*!40000 ALTER TABLE `hrdbagian` ENABLE KEYS */;


--
-- Definition of table `hrdgaji`
--

DROP TABLE IF EXISTS `hrdgaji`;
CREATE TABLE `hrdgaji` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `karyawanid` varchar(30) NOT NULL DEFAULT '',
  `pokok` double(15,2) NOT NULL DEFAULT '0.00',
  `tunjangan` double(15,2) NOT NULL DEFAULT '0.00',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `id2` (`karyawanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdgaji`
--

/*!40000 ALTER TABLE `hrdgaji` DISABLE KEYS */;
INSERT INTO `hrdgaji` (`id`,`karyawanid`,`pokok`,`tunjangan`,`user`,`jam`) VALUES 
 ('ADMN20130204-153421','ADMN20130128-130336',2000000.00,1000000.00,'admin','2013-02-04 15:35:39');
/*!40000 ALTER TABLE `hrdgaji` ENABLE KEYS */;


--
-- Definition of table `hrdgajidetail`
--

DROP TABLE IF EXISTS `hrdgajidetail`;
CREATE TABLE `hrdgajidetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `komponenid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `persen` char(1) NOT NULL,
  KEY `id` (`id`,`komponenid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdgajidetail`
--

/*!40000 ALTER TABLE `hrdgajidetail` DISABLE KEYS */;
INSERT INTO `hrdgajidetail` (`id`,`id2`,`komponenid`,`nominal`,`persen`) VALUES 
 ('ADMN20130204-153421','1','20130204-153414',0.00,'0');
/*!40000 ALTER TABLE `hrdgajidetail` ENABLE KEYS */;


--
-- Definition of table `hrdhari`
--

DROP TABLE IF EXISTS `hrdhari`;
CREATE TABLE `hrdhari` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `bulan` date NOT NULL DEFAULT '0000-00-00',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdhari`
--

/*!40000 ALTER TABLE `hrdhari` DISABLE KEYS */;
INSERT INTO `hrdhari` (`id`,`bulan`,`user`,`jam`) VALUES 
 ('ADMN20130128-130114','2013-01-28','admin','2013-01-28 13:01:14');
/*!40000 ALTER TABLE `hrdhari` ENABLE KEYS */;


--
-- Definition of table `hrdharidetail`
--

DROP TABLE IF EXISTS `hrdharidetail`;
CREATE TABLE `hrdharidetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `libur` char(1) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdharidetail`
--

/*!40000 ALTER TABLE `hrdharidetail` DISABLE KEYS */;
INSERT INTO `hrdharidetail` (`id`,`tanggal`,`libur`,`keterangan`) VALUES 
 ('ADMN20130128-130114','2013-01-01','1',''),
 ('ADMN20130128-130114','2013-01-02','0',''),
 ('ADMN20130128-130114','2013-01-03','0',''),
 ('ADMN20130128-130114','2013-01-04','0',''),
 ('ADMN20130128-130114','2013-01-05','0',''),
 ('ADMN20130128-130114','2013-01-06','1',''),
 ('ADMN20130128-130114','2013-01-07','0',''),
 ('ADMN20130128-130114','2013-01-08','0',''),
 ('ADMN20130128-130114','2013-01-09','0',''),
 ('ADMN20130128-130114','2013-01-10','0',''),
 ('ADMN20130128-130114','2013-01-11','0',''),
 ('ADMN20130128-130114','2013-01-12','0',''),
 ('ADMN20130128-130114','2013-01-13','1',''),
 ('ADMN20130128-130114','2013-01-14','0',''),
 ('ADMN20130128-130114','2013-01-15','0',''),
 ('ADMN20130128-130114','2013-01-16','0',''),
 ('ADMN20130128-130114','2013-01-17','0',''),
 ('ADMN20130128-130114','2013-01-18','0',''),
 ('ADMN20130128-130114','2013-01-19','0',''),
 ('ADMN20130128-130114','2013-01-20','1',''),
 ('ADMN20130128-130114','2013-01-21','0',''),
 ('ADMN20130128-130114','2013-01-22','0',''),
 ('ADMN20130128-130114','2013-01-23','0',''),
 ('ADMN20130128-130114','2013-01-24','1',''),
 ('ADMN20130128-130114','2013-01-25','0',''),
 ('ADMN20130128-130114','2013-01-26','0',''),
 ('ADMN20130128-130114','2013-01-27','1',''),
 ('ADMN20130128-130114','2013-01-28','0',''),
 ('ADMN20130128-130114','2013-01-29','0',''),
 ('ADMN20130128-130114','2013-01-30','0',''),
 ('ADMN20130128-130114','2013-01-31','0','');
/*!40000 ALTER TABLE `hrdharidetail` ENABLE KEYS */;


--
-- Definition of table `hrdjabatan`
--

DROP TABLE IF EXISTS `hrdjabatan`;
CREATE TABLE `hrdjabatan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `pokok` double(15,2) NOT NULL DEFAULT '0.00',
  `tunjangan` double(15,2) NOT NULL DEFAULT '0.00',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdjabatan`
--

/*!40000 ALTER TABLE `hrdjabatan` DISABLE KEYS */;
INSERT INTO `hrdjabatan` (`id`,`nama`,`pokok`,`tunjangan`,`user`,`jam`) VALUES 
 ('20130128-130036','Kabag',2000000.00,1000000.00,'admin','2013-01-28 13:00:36'),
 ('20130128-130045','Staff',1500000.00,500000.00,'admin','2013-01-28 13:00:45');
/*!40000 ALTER TABLE `hrdjabatan` ENABLE KEYS */;


--
-- Definition of table `hrdjam`
--

DROP TABLE IF EXISTS `hrdjam`;
CREATE TABLE `hrdjam` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `masuk` time NOT NULL DEFAULT '00:00:00',
  `pulang` time NOT NULL DEFAULT '00:00:00',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdjam`
--

/*!40000 ALTER TABLE `hrdjam` DISABLE KEYS */;
INSERT INTO `hrdjam` (`id`,`nama`,`masuk`,`pulang`,`user`,`jam`) VALUES 
 ('20130128-130127','Staff','08:00:00','17:00:00','admin','2013-01-28 13:01:27'),
 ('20130128-130152','Shift 1','07:00:00','15:00:00','admin','2013-01-28 13:02:52'),
 ('20130128-130213','Shift 2','15:00:00','23:00:00','admin','2013-01-28 13:03:00'),
 ('20130128-130233','Shift 3','23:00:00','07:00:00','admin','2013-01-28 13:03:05');
/*!40000 ALTER TABLE `hrdjam` ENABLE KEYS */;


--
-- Definition of table `hrdkaryawan`
--

DROP TABLE IF EXISTS `hrdkaryawan`;
CREATE TABLE `hrdkaryawan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tglmasuk` date NOT NULL DEFAULT '0000-00-00',
  `nik` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `alamat` varchar(300) NOT NULL DEFAULT '',
  `kotaid` varchar(30) NOT NULL DEFAULT '',
  `kodepos` varchar(30) NOT NULL DEFAULT '',
  `telepon` varchar(100) NOT NULL DEFAULT '',
  `tempatlahir` varchar(100) NOT NULL DEFAULT '',
  `tgllahir` date NOT NULL DEFAULT '0000-00-00',
  `gender` char(1) NOT NULL DEFAULT '',
  `darah` char(1) NOT NULL DEFAULT '',
  `agamaid` varchar(30) NOT NULL DEFAULT '',
  `pendidikanid` varchar(30) NOT NULL DEFAULT '',
  `status` char(1) NOT NULL DEFAULT '',
  `tanggungan` double(9,2) NOT NULL DEFAULT '0.00',
  `noktp` varchar(50) NOT NULL DEFAULT '',
  `npwp` varchar(50) NOT NULL DEFAULT '',
  `departemenid` varchar(30) NOT NULL,
  `bagianid` varchar(30) NOT NULL DEFAULT '',
  `jabatanid` varchar(30) NOT NULL DEFAULT '',
  `jamid` varchar(30) NOT NULL DEFAULT '',
  `norekening` varchar(30) NOT NULL DEFAULT '',
  `foto` mediumblob,
  `tglkeluar` date NOT NULL DEFAULT '0000-00-00',
  `aktif` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`kotaid`,`agamaid`,`pendidikanid`,`bagianid`,`jabatanid`,`jamid`,`norekening`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdkaryawan`
--

/*!40000 ALTER TABLE `hrdkaryawan` DISABLE KEYS */;
INSERT INTO `hrdkaryawan` (`id`,`tglmasuk`,`nik`,`nama`,`alamat`,`kotaid`,`kodepos`,`telepon`,`tempatlahir`,`tgllahir`,`gender`,`darah`,`agamaid`,`pendidikanid`,`status`,`tanggungan`,`noktp`,`npwp`,`departemenid`,`bagianid`,`jabatanid`,`jamid`,`norekening`,`foto`,`tglkeluar`,`aktif`,`user`,`jam`) VALUES 
 ('ADMN20130128-130336','2013-01-28','1','Ari','semeru','20100321-200822150','','','','2013-01-28','1','1','20090628-000357','20130128-130058','1',0.00,'','','20130212-095104','20130128-125941','20130128-130036','20130128-130127','20130128-130127',NULL,'2013-01-28','1','admin','2013-03-03 16:20:02');
/*!40000 ALTER TABLE `hrdkaryawan` ENABLE KEYS */;


--
-- Definition of table `hrdkomponen`
--

DROP TABLE IF EXISTS `hrdkomponen`;
CREATE TABLE `hrdkomponen` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `aktif` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdkomponen`
--

/*!40000 ALTER TABLE `hrdkomponen` DISABLE KEYS */;
INSERT INTO `hrdkomponen` (`id`,`nama`,`nominal`,`aktif`,`user`,`jam`) VALUES 
 ('20130204-153414','sada',0.00,'1','admin','2013-02-04 15:34:14');
/*!40000 ALTER TABLE `hrdkomponen` ENABLE KEYS */;


--
-- Definition of table `hrdposting`
--

DROP TABLE IF EXISTS `hrdposting`;
CREATE TABLE `hrdposting` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `bulan` date NOT NULL DEFAULT '0000-00-00',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdposting`
--

/*!40000 ALTER TABLE `hrdposting` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdposting` ENABLE KEYS */;


--
-- Definition of table `hrdpostingdetail`
--

DROP TABLE IF EXISTS `hrdpostingdetail`;
CREATE TABLE `hrdpostingdetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `karyawanid` varchar(30) NOT NULL DEFAULT '',
  `pokok` double(15,2) NOT NULL DEFAULT '0.00',
  `tunjangan` double(15,2) NOT NULL DEFAULT '0.00',
  `pph21` double(15,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`karyawanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdpostingdetail`
--

/*!40000 ALTER TABLE `hrdpostingdetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdpostingdetail` ENABLE KEYS */;


--
-- Definition of table `hrdpostingdetail2`
--

DROP TABLE IF EXISTS `hrdpostingdetail2`;
CREATE TABLE `hrdpostingdetail2` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `karyawanid` varchar(30) NOT NULL DEFAULT '',
  `komponenid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`komponenid`,`karyawanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdpostingdetail2`
--

/*!40000 ALTER TABLE `hrdpostingdetail2` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdpostingdetail2` ENABLE KEYS */;


--
-- Definition of table `hrdpph`
--

DROP TABLE IF EXISTS `hrdpph`;
CREATE TABLE `hrdpph` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `minimal` double(15,0) NOT NULL DEFAULT '0',
  `maksimal` double(15,0) NOT NULL DEFAULT '0',
  `persen` double(6,2) NOT NULL DEFAULT '0.00',
  `user` varchar(20) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdpph`
--

/*!40000 ALTER TABLE `hrdpph` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdpph` ENABLE KEYS */;


--
-- Definition of table `hrdpresensi`
--

DROP TABLE IF EXISTS `hrdpresensi`;
CREATE TABLE `hrdpresensi` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `bulan` date NOT NULL DEFAULT '0000-00-00',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdpresensi`
--

/*!40000 ALTER TABLE `hrdpresensi` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdpresensi` ENABLE KEYS */;


--
-- Definition of table `hrdpresensidetail`
--

DROP TABLE IF EXISTS `hrdpresensidetail`;
CREATE TABLE `hrdpresensidetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `karyawanid` varchar(30) NOT NULL DEFAULT '',
  `hadir` double(9,2) NOT NULL DEFAULT '0.00',
  `terlambat` double(9,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`karyawanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdpresensidetail`
--

/*!40000 ALTER TABLE `hrdpresensidetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdpresensidetail` ENABLE KEYS */;


--
-- Definition of table `hrdptkp`
--

DROP TABLE IF EXISTS `hrdptkp`;
CREATE TABLE `hrdptkp` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tahun` varchar(10) NOT NULL DEFAULT '',
  `user` varchar(20) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdptkp`
--

/*!40000 ALTER TABLE `hrdptkp` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdptkp` ENABLE KEYS */;


--
-- Definition of table `hrdptkpdetail`
--

DROP TABLE IF EXISTS `hrdptkpdetail`;
CREATE TABLE `hrdptkpdetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `kawin` char(1) NOT NULL DEFAULT '',
  `tanggungan` int(4) NOT NULL DEFAULT '0',
  `nominal` double(15,0) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hrdptkpdetail`
--

/*!40000 ALTER TABLE `hrdptkpdetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `hrdptkpdetail` ENABLE KEYS */;


--
-- Definition of table `kecamatan`
--

DROP TABLE IF EXISTS `kecamatan`;
CREATE TABLE `kecamatan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `kotaid` varchar(30) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`kotaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kecamatan`
--

/*!40000 ALTER TABLE `kecamatan` DISABLE KEYS */;
INSERT INTO `kecamatan` (`id`,`nama`,`kotaid`,`user`,`jam`) VALUES 
 ('20121108-111219','lor','20100321-200829401','admin','2013-02-03 17:23:30'),
 ('20130203-172333','1','20100321-200830452','admin','2013-02-03 17:23:33');
/*!40000 ALTER TABLE `kecamatan` ENABLE KEYS */;


--
-- Definition of table `kelurahan`
--

DROP TABLE IF EXISTS `kelurahan`;
CREATE TABLE `kelurahan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `kecamatanid` varchar(30) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`kecamatanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelurahan`
--

/*!40000 ALTER TABLE `kelurahan` DISABLE KEYS */;
INSERT INTO `kelurahan` (`id`,`nama`,`kecamatanid`,`user`,`jam`) VALUES 
 ('20121108-111954','aa','20121108-111219','admin','2013-02-03 17:23:26');
/*!40000 ALTER TABLE `kelurahan` ENABLE KEYS */;


--
-- Definition of table `keubank`
--

DROP TABLE IF EXISTS `keubank`;
CREATE TABLE `keubank` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `norekening` varchar(100) NOT NULL,
  `accountid` varchar(30) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`accountid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keubank`
--

/*!40000 ALTER TABLE `keubank` DISABLE KEYS */;
INSERT INTO `keubank` (`id`,`nama`,`norekening`,`accountid`,`aktif`,`user`,`jam`) VALUES 
 ('20121108-140531','bca','asas','110-08','1','admin','2012-11-08 14:05:55'),
 ('20121108-140538','bni','sas','110-03','1','admin','2012-11-08 14:05:47');
/*!40000 ALTER TABLE `keubank` ENABLE KEYS */;


--
-- Definition of table `keubayargiro`
--

DROP TABLE IF EXISTS `keubayargiro`;
CREATE TABLE `keubayargiro` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `supplierid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `penerima` varchar(100) NOT NULL,
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`supplierid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keubayargiro`
--

/*!40000 ALTER TABLE `keubayargiro` DISABLE KEYS */;
INSERT INTO `keubayargiro` (`id`,`tanggal`,`nobukti`,`supplierid`,`jurnalid`,`penerima`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130321-135855','2013-03-21','BG.13030001','1','ADMN1303210004','','','0','admin','2013-03-21 13:58:55');
/*!40000 ALTER TABLE `keubayargiro` ENABLE KEYS */;


--
-- Definition of table `keubayargirodetail`
--

DROP TABLE IF EXISTS `keubayargirodetail`;
CREATE TABLE `keubayargirodetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `pembelianid` varchar(30) NOT NULL DEFAULT '',
  `giroid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  KEY `id` (`id`,`pembelianid`,`giroid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keubayargirodetail`
--

/*!40000 ALTER TABLE `keubayargirodetail` DISABLE KEYS */;
INSERT INTO `keubayargirodetail` (`id`,`id2`,`pembelianid`,`giroid`,`nominal`,`keterangan`) VALUES 
 ('20130321-135855','1','20130314-141618','20130321-135236',500000.00,'');
/*!40000 ALTER TABLE `keubayargirodetail` ENABLE KEYS */;


--
-- Definition of table `keubayartransfer`
--

DROP TABLE IF EXISTS `keubayartransfer`;
CREATE TABLE `keubayartransfer` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `supplierid` varchar(30) NOT NULL DEFAULT '',
  `bankid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `penerima` varchar(100) NOT NULL,
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`supplierid`,`bankid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keubayartransfer`
--

/*!40000 ALTER TABLE `keubayartransfer` DISABLE KEYS */;
INSERT INTO `keubayartransfer` (`id`,`tanggal`,`nobukti`,`supplierid`,`bankid`,`jurnalid`,`penerima`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130321-140315','2013-03-21','BR.13030001','1','20121108-140531','ADMN1303210005','','','0','admin','2013-03-21 14:03:15');
/*!40000 ALTER TABLE `keubayartransfer` ENABLE KEYS */;


--
-- Definition of table `keubayartransferdetail`
--

DROP TABLE IF EXISTS `keubayartransferdetail`;
CREATE TABLE `keubayartransferdetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `pembelianid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  KEY `id` (`id`,`pembelianid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keubayartransferdetail`
--

/*!40000 ALTER TABLE `keubayartransferdetail` DISABLE KEYS */;
INSERT INTO `keubayartransferdetail` (`id`,`id2`,`pembelianid`,`nominal`,`keterangan`) VALUES 
 ('20130321-140315','1','20130314-141618',20000.00,'');
/*!40000 ALTER TABLE `keubayartransferdetail` ENABLE KEYS */;


--
-- Definition of table `keubayartunai`
--

DROP TABLE IF EXISTS `keubayartunai`;
CREATE TABLE `keubayartunai` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `supplierid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `penerima` varchar(100) NOT NULL,
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`supplierid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keubayartunai`
--

/*!40000 ALTER TABLE `keubayartunai` DISABLE KEYS */;
INSERT INTO `keubayartunai` (`id`,`tanggal`,`nobukti`,`supplierid`,`jurnalid`,`penerima`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130321-140336','2013-03-21','BT.13030001','1','ADMN1303210006','','','0','admin','2013-03-21 14:03:36');
/*!40000 ALTER TABLE `keubayartunai` ENABLE KEYS */;


--
-- Definition of table `keubayartunaidetail`
--

DROP TABLE IF EXISTS `keubayartunaidetail`;
CREATE TABLE `keubayartunaidetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `pembelianid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  KEY `id` (`id`,`pembelianid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keubayartunaidetail`
--

/*!40000 ALTER TABLE `keubayartunaidetail` DISABLE KEYS */;
INSERT INTO `keubayartunaidetail` (`id`,`id2`,`pembelianid`,`nominal`,`keterangan`) VALUES 
 ('20130321-140336','1','20130314-141618',10000.00,'');
/*!40000 ALTER TABLE `keubayartunaidetail` ENABLE KEYS */;


--
-- Definition of table `keugirobayar`
--

DROP TABLE IF EXISTS `keugirobayar`;
CREATE TABLE `keugirobayar` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `jatuhtempo` date NOT NULL DEFAULT '0000-00-00',
  `supplierid` varchar(30) NOT NULL DEFAULT '',
  `bankid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `nomor` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cair` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`supplierid`,`bankid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keugirobayar`
--

/*!40000 ALTER TABLE `keugirobayar` DISABLE KEYS */;
INSERT INTO `keugirobayar` (`id`,`tanggal`,`jatuhtempo`,`supplierid`,`bankid`,`jurnalid`,`nomor`,`nominal`,`keterangan`,`cair`,`user`,`jam`) VALUES 
 ('20130321-135236','2013-03-21','2013-03-21','1','20121108-140531','','111',1000000.00,'','1','admin','2013-03-21 13:58:37');
/*!40000 ALTER TABLE `keugirobayar` ENABLE KEYS */;


--
-- Definition of table `keugiroterima`
--

DROP TABLE IF EXISTS `keugiroterima`;
CREATE TABLE `keugiroterima` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `jatuhtempo` date NOT NULL DEFAULT '0000-00-00',
  `pelangganid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `bank` varchar(100) NOT NULL DEFAULT '',
  `cabang` varchar(100) NOT NULL DEFAULT '',
  `nomor` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cair` char(1) NOT NULL DEFAULT '',
  `kas` char(1) NOT NULL DEFAULT '',
  `bankid` varchar(30) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pelangganid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keugiroterima`
--

/*!40000 ALTER TABLE `keugiroterima` DISABLE KEYS */;
INSERT INTO `keugiroterima` (`id`,`tanggal`,`jatuhtempo`,`pelangganid`,`jurnalid`,`bank`,`cabang`,`nomor`,`nominal`,`keterangan`,`cair`,`kas`,`bankid`,`user`,`jam`) VALUES 
 ('20130204-145858','2013-02-04','2013-02-04','p1','ADMN1302040005','asas','asas','1asas',1000.00,'asas','1','1','','admin','2013-03-21 14:12:20');
/*!40000 ALTER TABLE `keugiroterima` ENABLE KEYS */;


--
-- Definition of table `keuterimagiro`
--

DROP TABLE IF EXISTS `keuterimagiro`;
CREATE TABLE `keuterimagiro` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `pelangganid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `penyetor` varchar(100) NOT NULL,
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pelangganid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuterimagiro`
--

/*!40000 ALTER TABLE `keuterimagiro` DISABLE KEYS */;
INSERT INTO `keuterimagiro` (`id`,`tanggal`,`nobukti`,`pelangganid`,`jurnalid`,`penyetor`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130321-142521','2013-03-21','TG.13030001','p1','ADMN1303210008','','','0','admin','2013-03-21 14:57:29');
/*!40000 ALTER TABLE `keuterimagiro` ENABLE KEYS */;


--
-- Definition of table `keuterimagirodetail`
--

DROP TABLE IF EXISTS `keuterimagirodetail`;
CREATE TABLE `keuterimagirodetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `penjualanid` varchar(30) NOT NULL DEFAULT '',
  `giroid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  KEY `id` (`id`,`penjualanid`,`giroid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuterimagirodetail`
--

/*!40000 ALTER TABLE `keuterimagirodetail` DISABLE KEYS */;
INSERT INTO `keuterimagirodetail` (`id`,`id2`,`penjualanid`,`giroid`,`nominal`,`keterangan`) VALUES 
 ('20130321-142521','1','20130320-125206','20130204-145858',1000.00,'');
/*!40000 ALTER TABLE `keuterimagirodetail` ENABLE KEYS */;


--
-- Definition of table `keuterimatransfer`
--

DROP TABLE IF EXISTS `keuterimatransfer`;
CREATE TABLE `keuterimatransfer` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `pelangganid` varchar(30) NOT NULL DEFAULT '',
  `bankid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `penyetor` varchar(100) NOT NULL,
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pelangganid`,`bankid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuterimatransfer`
--

/*!40000 ALTER TABLE `keuterimatransfer` DISABLE KEYS */;
INSERT INTO `keuterimatransfer` (`id`,`tanggal`,`nobukti`,`pelangganid`,`bankid`,`jurnalid`,`penyetor`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130321-151430','2013-03-21','TR.13030001','p1','20121108-140531','ADMN1303210009','','','0','admin','2013-03-21 15:14:30');
/*!40000 ALTER TABLE `keuterimatransfer` ENABLE KEYS */;


--
-- Definition of table `keuterimatransferdetail`
--

DROP TABLE IF EXISTS `keuterimatransferdetail`;
CREATE TABLE `keuterimatransferdetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `penjualanid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  KEY `id` (`id`,`penjualanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuterimatransferdetail`
--

/*!40000 ALTER TABLE `keuterimatransferdetail` DISABLE KEYS */;
INSERT INTO `keuterimatransferdetail` (`id`,`id2`,`penjualanid`,`nominal`,`keterangan`) VALUES 
 ('20130321-151430','1','20130320-125206',800.00,'');
/*!40000 ALTER TABLE `keuterimatransferdetail` ENABLE KEYS */;


--
-- Definition of table `keuterimatunai`
--

DROP TABLE IF EXISTS `keuterimatunai`;
CREATE TABLE `keuterimatunai` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `pelangganid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `penyetor` varchar(100) NOT NULL,
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pelangganid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuterimatunai`
--

/*!40000 ALTER TABLE `keuterimatunai` DISABLE KEYS */;
INSERT INTO `keuterimatunai` (`id`,`tanggal`,`nobukti`,`pelangganid`,`jurnalid`,`penyetor`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130321-152041','2013-03-21','TT.13030001','p1','ADMN1303210010','','','0','admin','2013-03-21 15:20:46'),
 ('20130321-152244','2013-03-21','TT.13030002','','ADMN1303210011','','','0','admin','2013-03-21 15:22:44');
/*!40000 ALTER TABLE `keuterimatunai` ENABLE KEYS */;


--
-- Definition of table `keuterimatunaidetail`
--

DROP TABLE IF EXISTS `keuterimatunaidetail`;
CREATE TABLE `keuterimatunaidetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `penjualanid` varchar(30) NOT NULL DEFAULT '',
  `nominal` double(15,2) NOT NULL DEFAULT '0.00',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  KEY `id` (`id`,`penjualanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuterimatunaidetail`
--

/*!40000 ALTER TABLE `keuterimatunaidetail` DISABLE KEYS */;
INSERT INTO `keuterimatunaidetail` (`id`,`id2`,`penjualanid`,`nominal`,`keterangan`) VALUES 
 ('20130321-152041','1','20130320-125206',5000.00,'asas'),
 ('20130321-152244','1','',100000.00,'asas');
/*!40000 ALTER TABLE `keuterimatunaidetail` ENABLE KEYS */;


--
-- Definition of table `konversi`
--

DROP TABLE IF EXISTS `konversi`;
CREATE TABLE `konversi` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `satuanid1` varchar(30) NOT NULL DEFAULT '',
  `satuanid2` varchar(30) NOT NULL DEFAULT '',
  `nilai` double(15,2) NOT NULL DEFAULT '0.00',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`satuanid1`,`satuanid2`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `konversi`
--

/*!40000 ALTER TABLE `konversi` DISABLE KEYS */;
/*!40000 ALTER TABLE `konversi` ENABLE KEYS */;


--
-- Definition of table `kota`
--

DROP TABLE IF EXISTS `kota`;
CREATE TABLE `kota` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `propinsiid` varchar(30) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`propinsiid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kota`
--

/*!40000 ALTER TABLE `kota` DISABLE KEYS */;
INSERT INTO `kota` (`id`,`nama`,`propinsiid`,`user`,`jam`) VALUES 
 ('1','Kab. Sarmi','30','admin','2010-03-21 20:08:30'),
 ('10','Kab. Asmat','30','admin','2010-03-21 20:08:30'),
 ('11','Kab. Supiori','30','admin','2010-03-21 20:08:30'),
 ('12','Kab. Mamberamo Raya','30','admin','2010-03-21 20:08:30'),
 ('13','Kab. Dogiyai','30','admin','2010-03-21 20:08:30'),
 ('14','Kab. Lanny Jaya','30','admin','2010-03-21 20:08:30'),
 ('15','Kab. Mamberamo Tengah','30','admin','2010-03-21 20:08:30'),
 ('16','Kab. Nduga Tengah','30','admin','2010-03-21 20:08:30'),
 ('17','Kab. Yalimo','30','admin','2010-03-21 20:08:30'),
 ('18','Kab. Puncak','30','admin','2010-03-21 20:08:30'),
 ('19','Kab./Kota Lainnya','30','admin','2010-03-21 20:08:30'),
 ('2','Kab. Keerom','30','admin','2010-03-21 20:08:30'),
 ('20','Kota Jayapura','30','admin','2010-03-21 20:08:30'),
 ('20100321-20081910','Kab. Bekasi','1','admin','2010-10-29 20:29:25'),
 ('20100321-2008192','Kab. Purwakarta','1','admin','2010-03-21 20:08:19'),
 ('20100321-2008193','Kab. Karawang','1','admin','2010-03-21 20:08:19'),
 ('20100321-2008194','Kab. Bogor','1','admin','2010-03-21 20:08:19'),
 ('20100321-2008195','Kab. Sukabumi','1','admin','2010-03-21 20:08:19'),
 ('20100321-2008196','Kab. Cianjur','1','admin','2010-03-21 20:08:19'),
 ('20100321-2008197','Kab. Bandung','1','admin','2010-03-21 20:08:19'),
 ('20100321-2008198','Kab. Sumedang','1','admin','2010-03-21 20:08:19'),
 ('20100321-2008199','Kab. Tasikmalaya','1','admin','2010-03-21 20:08:19'),
 ('20100321-20082011','Kab. Garut','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082012','Kab. Ciamis','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082013','Kab. Cirebon','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082014','Kab. Kuningan','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082015','Kab. Indramayu','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082016','Kab. Majalengka','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082017','Kab. Subang','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082018','Kab. Bandung Barat','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082019','Kota Banjar','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082020','Kab./Kota Lainnya','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082021','Kota Bandung','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082022','Kota Bogor','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082023','Kota Sukabumi','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082024','Kota Cirebon','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082025','Kota Tasikmalaya','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082026','Kota Cimahi','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082027','Kota Depok','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082028','Kota Bekasi','1','admin','2010-03-21 20:08:20'),
 ('20100321-20082029','Kab. Lebak','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082030','Kab. Pandeglang','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082031','Kab. Serang','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082032','Kab. Tangerang','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082033','Kab./Kota Lainnya','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082034','Kota Cilegon','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082035','Kota Tangerang','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082036','Kota Serang','2','admin','2010-03-21 20:08:20'),
 ('20100321-20082037','Wil. Kota Jakarta Pusat','3','admin','2010-03-21 20:08:20'),
 ('20100321-20082038','Wil. Kota Jakarta Utara','3','admin','2010-03-21 20:08:20'),
 ('20100321-20082039','Wil. Kota Jakarta Barat','3','admin','2010-03-21 20:08:20'),
 ('20100321-20082040','Wil. Kota Jakarta Selatan','3','admin','2010-03-21 20:08:20'),
 ('20100321-20082041','Wil. Kota Jakarta Timur','3','admin','2010-03-21 20:08:20'),
 ('20100321-20082042','Wil. Kepulauan Seribu','3','admin','2010-03-21 20:08:20'),
 ('20100321-20082043','Kab. Bantul','4','admin','2010-03-21 20:08:20'),
 ('20100321-20082044','Kab. Sleman','4','admin','2010-03-21 20:08:20'),
 ('20100321-20082045','Kab. Gunung Kidul','4','admin','2010-03-21 20:08:20'),
 ('20100321-20082046','Kab. Kulon Progo','4','admin','2010-03-21 20:08:20'),
 ('20100321-20082047','Kab./Kota Lainnya','4','admin','2010-03-21 20:08:20'),
 ('20100321-20082048','Kota Yogyakarta','4','admin','2010-03-21 20:08:20'),
 ('20100321-20082049','Kab. Semarang','4','admin','2010-03-21 20:08:20'),
 ('20100321-20082050','Kab. Kendal','5','admin','2010-03-21 20:08:20'),
 ('20100321-20082051','Kab. Demak','5','admin','2010-03-21 20:08:20'),
 ('20100321-20082052','Kab. Grobogan','5','admin','2010-03-21 20:08:20'),
 ('20100321-20082053','Kab. Pekalongan','5','admin','2010-03-21 20:08:20'),
 ('20100321-20082054','Kab. Tegal','5','admin','2010-03-21 20:08:20'),
 ('20100321-20082055','Kab. Brebes','5','admin','2010-03-21 20:08:20'),
 ('20100321-200821100','Kab. Pati','6','admin','2010-03-21 20:08:21'),
 ('20100321-200821101','Kab. Kudus','6','admin','2010-03-21 20:08:21'),
 ('20100321-200821102','Kab. Pemalang','6','admin','2010-03-21 20:08:21'),
 ('20100321-200821103','Kab. Jepara','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082156','Kab. Rembang','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082157','Kab. Blora','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082158','Kab. Banyumas','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082159','Kab. Cilacap','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082160','Kab. Purbalingga','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082161','Kab. Banjarnegara','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082162','Kab. Magelang','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082163','Kab. Temanggung','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082164','Kab. Wonosobo','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082165','Kab. Purworejo','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082166','Kab. Kebumen','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082167','Kab. Klaten','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082168','Kab. Boyolali','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082169','Kab. Sragen','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082170','Kab. Sukoharjo','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082171','Kab. Karanganyar','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082172','Kab. Wonogiri','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082173','Kab. Batang','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082174','Kab./Kota Lainnya','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082175','Kota Semarang','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082176','Kota Salatiga','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082177','Kota Pekalongan','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082178','Kota Tegal','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082179','Kota Magelang','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082180','Kota Surakarta/Solo','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082181','Kab. Gresik','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082182','Kab. Sidoarjo','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082183','Kab. Mojokerto','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082184','Kab. Jombang','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082185','Kab. Sampang','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082186','Kab. Pamekasan','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082187','Kab. Sumenep','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082188','Kab. Bangkalan','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082189','Kab. Bondowoso','5','admin','2010-03-21 20:08:21'),
 ('20100321-20082190','Kab. Banyuwangi','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082191','Kab. Jember','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082192','Kab. Malang','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082193','Kab. Pasuruan','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082194','Kab. Probolinggo','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082195','Kab. Lumajang','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082196','Kab. Kediri','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082197','Kab. Nganjuk','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082198','Kab. Tulungagung','6','admin','2010-03-21 20:08:21'),
 ('20100321-20082199','Kab. Trenggalek','6','admin','2010-03-21 20:08:21'),
 ('20100321-200822104','Kab. Blitar','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822105','Kab. Madiun','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822106','Kab. Ngawi','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822107','Kab. Magetan','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822108','Kab. Ponorogo','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822109','Kab. Pacitan','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822110','Kab. Bojonegoro','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822111','Kab. Tuban','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822112','Kab. Lamongan','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822113','Kab. Situbondo','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822114','Kota Batu','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822115','Kab./Kota Lainnya','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822116','Kota Surabaya','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822117','Kota Mojokerto','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822118','Kota Malang','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822119','Kota Pasuruan','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822120','Kota Probolinggo','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822121','Kota Blitar','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822122','Kota Kediri','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822123','Kota Madiun','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822124','Kab. Bengkulu Selatan','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822125','Kab. Bengkulu Utara','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822126','Kab. Rejang Lebong','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822127','Kab. Lebong','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822128','Kab. Kepahiang','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822129','Kab. Mukomuko','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822130','Kab. Seluma','6','admin','2010-03-21 20:08:22'),
 ('20100321-200822131','Kab. Kaur','7','admin','2010-03-21 20:08:22'),
 ('20100321-200822132','Kab./Kota Lainnya','7','admin','2010-03-21 20:08:22'),
 ('20100321-200822133','Kota Bengkulu','7','admin','2010-03-21 20:08:22'),
 ('20100321-200822134','Kab. Batanghari','7','admin','2010-03-21 20:08:22'),
 ('20100321-200822135','Kab. Sarolangun','7','admin','2010-03-21 20:08:22'),
 ('20100321-200822136','Kab. Kerinci','7','admin','2010-03-21 20:08:22'),
 ('20100321-200822137','Kab. Muaro Jambi','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822138','Kab. Tanjung Jabung Barat','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822139','Kab. Tanjung Jabung Timur','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822140','Kab. Tebo','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822141','Kab. Merangin','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822142','Kab. Bungo','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822143','Kab./Kota Lainnya','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822144','Kota Jambi','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822145','Kab. Aceh Besar','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822146','Kab. Pidie','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822147','Kab. Aceh Utara','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822148','Kab. Aceh Timur','8','admin','2010-03-21 20:08:22'),
 ('20100321-200822149','Kab. Aceh Selatan','9','admin','2010-03-21 20:08:22'),
 ('20100321-200822150','Kab. Aceh Barat','9','admin','2010-03-21 20:08:22'),
 ('20100321-200823151','Kab. Aceh Tengah','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823152','Kab. Aceh Tenggara','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823153','Kab. Aceh Singkil','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823154','Kab. Aceh Jeumpa/Bireuen','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823155','Kab. Aceh Tamiang','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823156','Kab. Gayo Luwes','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823157','Kab. Aceh Barat Daya','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823158','Kab. Aceh Jaya','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823159','Kab. Nagan Raya','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823160','Kab. Aceh Simeuleu','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823161','Kab. Bener Meriah','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823162','Kab. Pidie Jaya','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823163','Kab. Subulussalam','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823164','Kab./Kota Lainnya','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823165','Kota Banda Aceh','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823166','Kota Sabang','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823167','Kota Lhokseumawe','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823168','Kota Langsa','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823169','Kab. Deli Serdang','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823170','Kab. Langkat','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823171','Kab. Karo','9','admin','2010-03-21 20:08:23'),
 ('20100321-200823172','Kab. Simalungun','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823173','Kab. Labuhan Batu','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823174','Kab. Asahan','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823175','Kab. Dairi','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823176','Kab. Tapanuli Utara','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823177','Kab. Tapanuli Tengah','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823178','Kab. Tapanuli Selatan','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823179','Kab. Nias','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823180','Kab. Toba Samosir','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823181','Kab. Mandailing Natal','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823182','Kab. Nias Selatan','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823183','Kab. Humbang Hasundutan','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823184','Kab. Pakpak Bharat','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823185','Kab. Samosir','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823186','Kab. Serdang Bedagai','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823187','Kab. Angkola Sipirok','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823188','Kab. Batu Bara','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823189','Kab. Padang Lawas','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823190','Kab. Padang Lawas Utara','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823191','Kab/Kota Lainnya','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823192','Kota Tebing Tinggi','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823193','Kota Binjai','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823194','Kota Pematang Siantar','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823195','Kota Tanjung Balai','10','admin','2010-03-21 20:08:23'),
 ('20100321-200823196','Kota Sibolga','11','admin','2010-03-21 20:08:23'),
 ('20100321-200823197','Kota Medan','11','admin','2010-03-21 20:08:23'),
 ('20100321-200824198','Kota Padang Sidempuan','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824199','Kab. Agam','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824200','Kab. Pasaman','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824201','Kab. Limapuluh Koto','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824202','Kab. Solok Selatan','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824203','Kab. Padang Pariaman','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824204','Kab. Pesisir Selatan','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824205','Kab. Tanah Datar','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824206','Kab. Sawahlunto/Sijunjung','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824207','Kab. Kepulauan Mentawai','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824208','Kab. Pasaman Barat','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824209','Kab. Dharmasraya','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824210','Kab. Solok','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824211','Kab/Kota Lainnya','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824212','Kota Bukittinggi','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824213','Kota Padang','11','admin','2010-03-21 20:08:24'),
 ('20100321-200824214','Kota Sawahlunto','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824215','Kota Padang Panjang','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824216','Kota Solok','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824217','Kota Payakumbuh','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824218','Kota Pariaman','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824219','Kab. Kampar','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824220','Kab. Bengkalis','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824221','Kab. Indragiri Hulu','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824222','Kab. Indragiri Hilir','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824223','Kab. Rokan Hulu','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824224','Kab. Rokan Hilir','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824225','Kab. Pelalawan','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824226','Kab. Siak','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824227','Kab. Kuantan Singingi','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824228','Kab./Kota Lainnya','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824229','Kota Pekanbaru','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824230','Kota Dumai','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824231','Kab. Musi Banyuasin','12','admin','2010-03-21 20:08:24'),
 ('20100321-200824232','Kab. Ogan Komering Ulu','13','admin','2010-03-21 20:08:24'),
 ('20100321-200824233','Kab. Lematang Ilir Ogan Tengah (Muara Enim)','13','admin','2010-03-21 20:08:24'),
 ('20100321-200824234','Kab. Lahat','13','admin','2010-03-21 20:08:24'),
 ('20100321-200824235','Kab. Musi Rawas','13','admin','2010-03-21 20:08:24'),
 ('20100321-200825236','Kab. Ogan Komering Ilir','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825237','Kab. Banyuasin','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825238','Kab. Ogan Komeing Ulu Selatan','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825239','OKU TIMUR','13','bumdes','2012-01-01 20:43:04'),
 ('20100321-200825240','Kab. Ogan Ilir','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825241','Kab. Empat Lawang','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825242','Kab./Kota Lainnya','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825243','Kota Palembang','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825244','Kota Lubuklinggau','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825245','Kota Prabumulih','13','admin','2010-03-21 20:08:25'),
 ('20100321-200825246','Kota Pagar Alam','14','admin','2010-03-21 20:08:25'),
 ('20100321-200825247','Kab. Bangka','14','admin','2010-03-21 20:08:25'),
 ('20100321-200825248','Kab. Belitung','14','admin','2010-03-21 20:08:25'),
 ('20100321-200825249','Kab. Bangka Barat','14','admin','2010-03-21 20:08:25'),
 ('20100321-200825250','Kab. Bangka Selatan','14','admin','2010-03-21 20:08:25'),
 ('20100321-200825251','Kab. Bangka Tengah','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825252','Kab. Belitung Timur','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825253','Kab./Kota Lainnya','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825254','Kota Pangkal Pinang','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825255','Kab. Karimun','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825256','Kab. Lingga','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825257','Kab. Natuna','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825258','Kab. Bintan (d/h Kabupaten Kepulauan Riau)','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825259','Kab./Kota Lainnya','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825260','Kota Tanjung Pinang','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825261','Kota Batam','15','admin','2010-03-21 20:08:25'),
 ('20100321-200825262','Kab. Lampung Selatan','15','admin','2010-03-21 20:08:25'),
 ('20100321-200826263','Kab. Lampung Tengah','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826264','Kab. Lampung Utara','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826265','Kab. Lampung Barat','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826266','Kab. Tulang Bawang','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826267','Kab. Tanggamus','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826268','Kab. Lampung Timur','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826269','Kab. Way Kanan','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826270','Kab. Pesawaran','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826271','Kab./Kota Lainnya','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826272','Kota Bandar Lampung','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826273','Kota Metro','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826274','Kab. Banjar','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826275','Kab. Tanah Laut','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826276','Kab. Tapin','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826277','Kab. Hulu Sungai Selatan','16','admin','2010-03-21 20:08:26'),
 ('20100321-200826278','Kab. Hulu Sungai Tengah','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826279','Kab. Hulu Sungai Utara','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826280','Kab. Barito Kuala','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826281','Kab. Kota Baru','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826282','Kab. Tabalong','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826283','Kab.Tanah Bumbu','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826284','Kab. Balangan','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826285','Kab./Kota Lainnya','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826286','Kota Banjarmasin','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826287','Kota Banjarbaru','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826288','Kab. Pontianak','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826289','Kab. Sambas','17','admin','2010-03-21 20:08:26'),
 ('20100321-200826290','Kab. Ketapang','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826291','Kab. Sanggau','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826292','Kab. Sintang','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826293','Kab. Kapuas Hulu','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826294','Kab. Bengkayang','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826295','Kab. Landak','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826296','Kab. Sekadau','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826297','Kab. Melawi','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826298','Kab. Kayong Utara','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826299','Kab. Kubu Raya','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826300','Kab./Kota Lainnya','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826301','Kota Pontianak','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826302','Kota Singkawang','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826303','Kab. Kutai Kartanegara','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826304','Kab. Berau','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826305','Kab. Pasir','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826306','Kab. Bulungan','18','admin','2010-03-21 20:08:26'),
 ('20100321-200826307','Kab. Kutai Barat','19','admin','2010-03-21 20:08:26'),
 ('20100321-200826308','Kab. Kutai Timur','19','admin','2010-03-21 20:08:26'),
 ('20100321-200826309','Kab. Nunukan','19','admin','2010-03-21 20:08:26'),
 ('20100321-200827310','Kab. Malinau','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827311','Kab. Penajam Paser Utara','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827312','Kab. Tana Tidung','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827313','Kab./Kota Lainnya','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827314','Kota Samarinda','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827315','Kota Balikpapan','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827316','Kota Tarakan','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827317','Kota Bontang','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827318','Kab. Kapuas','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827319','Kab. Kotawaringin Barat','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827320','Kab. Kotawaringin Timur','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827321','Kab. Murung Raya','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827322','Kab. Barito Timur','19','admin','2010-03-21 20:08:27'),
 ('20100321-200827323','Kab. Barito Selatan','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827324','Kab. Gunung Mas','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827325','Kab. Barito Utara','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827326','Kab. Pulang Pisau','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827327','Kab. Seruyan','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827328','Kab. Katingan','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827329','Kab. Sukamara','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827330','Kab. Lamandau','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827331','Kab./Kota Lainnya','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827332','Kota Palangkaraya','20','admin','2010-03-21 20:08:27'),
 ('20100321-200827333','Kab. Donggala','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827334','Kab. Poso','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827335','Kab. Parimo/Banggai','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827336','Kab. Toli-Toli','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827337','Kab. Banggai Kepulauan','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827338','Kab. Morowali','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827339','Kab. Buol','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827340','Kab. Tojo Una-Una','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827341','Kab. Parigi Moutong','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827342','Kab./Kota Lainnya','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827343','Kota Palu','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827344','Kab. Pinrang','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827345','Kab. Gowa','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827346','Kab. Wajo','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827347','Kab. Bone','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827348','Kab. Tana Toraja','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827349','Kab. Maros','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827350','Kab. Luwu','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827351','Kab. Sinjai','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827352','Kab. Bulukumba','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827353','Kab. Bantaeng','21','admin','2010-03-21 20:08:27'),
 ('20100321-200827354','Kab. Jeneponto','21','admin','2010-03-21 20:08:27'),
 ('20100321-200828355','Kab. Selayar','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828356','Kab. Takalar','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828357','Kab. Barru','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828358','Kab. Sidenreng Rappang','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828359','Kab. Pangkajene Kepulauan','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828360','Kab. Soppeng (d/h Watansoppeng)','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828361','Kab. Enrekang','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828362','Kab. Luwu Timur (d/h Luwu Selatan)','21','admin','2010-03-21 20:08:28'),
 ('20100321-200828363','Kab. Luwu Utara','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828364','Kab./Kota Lainnya','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828365','Kota Makassar','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828366','Kota Pare-Pare','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828367','Kota Palopo','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828368','Kab. Minahasa','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828369','Kab. Bolaang Mongondow','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828370','Kab. Kepulauan Sangihe','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828371','Kab. kepulauan Talaud','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828372','Kab. Minahasa Selatan','22','admin','2010-03-21 20:08:28'),
 ('20100321-200828373','Kab. Minahasa Utara','23','admin','2010-03-21 20:08:28'),
 ('20100321-200828374','Kab. Minahasa Tenggara','23','admin','2010-03-21 20:08:28'),
 ('20100321-200828375','Kab. Bolaang Mongondow Utara','23','admin','2010-03-21 20:08:28'),
 ('20100321-200828376','Kab. Kepulauan Sitaro','23','admin','2010-03-21 20:08:28'),
 ('20100321-200828377','Kab./Kota Lainnya','23','admin','2010-03-21 20:08:28'),
 ('20100321-200828378','Kota Manado','23','admin','2010-03-21 20:08:28'),
 ('20100321-200828379','Kota Kotamobagu','23','admin','2010-03-21 20:08:28'),
 ('20100321-200828380','Kota Bitung','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828381','Kota. Tomohon','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828382','Kab. Gorontalo','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828383','Kab. Bualemo','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828384','Kab. Bonebolango','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828385','Kab. Pohuwato','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828386','Kab. Gorontalo Utara','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828387','Kab./Kota Lainnya','24','admin','2010-03-21 20:08:28'),
 ('20100321-200828388','Kota Gorontalo','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828389','Kab. Polewali Mandar','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828390','Kab. Majene','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828391','Kab. Mamasa','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828392','Kab. Mamuju Utara','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828393','Kab./Kota Lainnya','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828394','Kota Mamuju','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828395','Kab. Buton','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828396','Kab. Muna','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828397','Kab. Kolaka','25','admin','2010-03-21 20:08:28'),
 ('20100321-200828398','Kab. Wakatobi','26','admin','2010-03-21 20:08:28'),
 ('20100321-200828399','Kab. Konawe','26','admin','2010-03-21 20:08:28'),
 ('20100321-200828400','Kab. Konawe Selatan','26','admin','2010-03-21 20:08:28'),
 ('20100321-200829401','Kab. Bombana','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829402','Kab. Kolaka Utara','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829403','Kab. Buton Utara','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829404','Kab. Konawe Utara','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829405','Kab./Kota Lainnya','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829406','Kota Bau-Bau','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829407','Kota Kendari','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829408','Kab. Lombok Barat','26','admin','2010-03-21 20:08:29'),
 ('20100321-200829409','Kab. Lombok Tengah','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829410','Kab. Lombok Timur','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829411','Kab. Sumbawa','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829412','Kab. Bima','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829413','Kab. Dompu','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829414','Kab. Sumbawa Barat','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829415','Kab./Kota Lainnya','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829416','Kota Mataram','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829417','Kota. Bima','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829418','Kab. Buleleng','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829419','Kab. Jembrana','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829420','Kab. Tabanan','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829421','Kab. Badung','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829422','Kab. Gianyar','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829423','Kab. Klungkung','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829424','Kab. Bangli','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829425','Kab. Karangasem','27','admin','2010-03-21 20:08:29'),
 ('20100321-200829426','Kab./Kota Lainnya','28','admin','2010-03-21 20:08:29'),
 ('20100321-200829427','Kota Denpasar','28','admin','2010-03-21 20:08:29'),
 ('20100321-200829428','Kab. Kupang','28','admin','2010-03-21 20:08:29'),
 ('20100321-200829429','Kab. Timor-Tengah Selatan','28','admin','2010-03-21 20:08:29'),
 ('20100321-200829430','Kab. Timor-Tengah Utara','28','admin','2010-03-21 20:08:29'),
 ('20100321-200829431','Kab. Belu','28','admin','2010-03-21 20:08:29'),
 ('20100321-200829432','Kab. Alor','28','admin','2010-03-21 20:08:29'),
 ('20100321-200829433','Kab. Flores Timur','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829434','Kab. Sikka','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829435','Kab. Ende','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829436','Kab. Ngada','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829437','Kab. Manggarai','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829438','Kab. Sumba Timur','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829439','Kab. Sumba Barat','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829440','Kab. Lembata','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829441','Kab. Rote','29','admin','2010-03-21 20:08:29'),
 ('20100321-200829442','Kab. Manggarai Barat','29','admin','2010-03-21 20:08:29'),
 ('20100321-200830443','Kab. Sumba Tengah','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830444','Kab. Sumba Barat Daya','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830445','Kab. Manggarai Timur','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830446','Kab. Nagekeo','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830447','Kab./Kota Lainnya','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830448','Kota Kupang','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830449','Kab. Maluku Tengah','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830450','Kab. Maluku Tenggara','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830451','Kab. Maluku Tenggara Barat','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830452','Kab Buru','29','admin','2013-02-03 17:22:58'),
 ('20100321-200830453','Kota Seram Bagian Barat','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830454','Kota Seram Bagian Timur','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830455','Kota Kepulauan Aru','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830456','Kab./Kota Lainnya','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830457','Kota Ambon','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830458','Kota Tual','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830459','Kab. Jayapura','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830460','Kab. Biak Numfor','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830461','Kab. Yapen-Waropen','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830462','Kab. Merauke','29','admin','2010-03-21 20:08:30'),
 ('20100321-200830463','Kab. Paniai','30','admin','2010-03-21 20:08:30'),
 ('20100321-200830464','Kab. Jayawijaya','30','admin','2010-03-21 20:08:30'),
 ('20100321-200830465','Kab. Nabire','30','admin','2010-03-21 20:08:30'),
 ('20100321-200830466','Kab. Mimika','30','admin','2010-03-21 20:08:30'),
 ('20100321-200830467','Kab. Puncak Jaya','30','admin','2010-03-21 20:08:30'),
 ('21','Kab. Halmahera Tengah','30','admin','2010-03-21 20:08:30'),
 ('22','Kab. Halmahera Utara','30','admin','2010-03-21 20:08:30'),
 ('23','Kab. Halmahera Timur','30','admin','2010-03-21 20:08:30'),
 ('24','Kab. Halmahera Barat','30','admin','2010-03-21 20:08:30'),
 ('25','Kab. Halmahera Selatan','30','admin','2010-03-21 20:08:30'),
 ('26','Kab. Kepulauan Sula','30','admin','2010-03-21 20:08:30'),
 ('27','Kab./Kota Lainnya','30','admin','2010-03-21 20:08:30'),
 ('28','Kota Ternate','30','admin','2010-03-21 20:08:30'),
 ('29','Kota Tidore Kepulauan','30','admin','2010-03-21 20:08:30'),
 ('3','Kab. Pegunungan Bintang','30','admin','2010-03-21 20:08:30'),
 ('30','Kab. Sorong','30','admin','2010-03-21 20:08:30'),
 ('31','Kab. Fak-Fak','30','admin','2010-03-21 20:08:30'),
 ('32','Kab. Manokwari','30','admin','2010-03-21 20:08:30'),
 ('33','Kab. Sorong Selatan','30','admin','2010-03-21 20:08:30'),
 ('34','Kab. Raja Ampat','30','admin','2010-03-21 20:08:30'),
 ('35','Kab. Kaimana','30','admin','2010-03-21 20:08:30'),
 ('36','Kab. Teluk Bintuni','30','admin','2010-03-21 20:08:30'),
 ('37','Kab. Teluk Wondama','30','admin','2010-03-21 20:08:30'),
 ('38','Kab./Kota Lainnya','30','admin','2010-03-21 20:08:30'),
 ('39','Kota Sorong','30','admin','2010-03-21 20:08:30'),
 ('4','Kab. Yahukimo','30','admin','2010-03-21 20:08:30'),
 ('5','Kab. Tolikara','30','admin','2010-03-21 20:08:30'),
 ('6','Kab. Waropen','30','admin','2010-03-21 20:08:30'),
 ('8','Kab. Boven Digoel','30','admin','2010-03-21 20:08:30'),
 ('9','Kab. Mappi','30','admin','2010-03-21 20:08:30');
/*!40000 ALTER TABLE `kota` ENABLE KEYS */;


--
-- Definition of table `pekerjaan`
--

DROP TABLE IF EXISTS `pekerjaan`;
CREATE TABLE `pekerjaan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pekerjaan`
--

/*!40000 ALTER TABLE `pekerjaan` DISABLE KEYS */;
INSERT INTO `pekerjaan` (`id`,`nama`,`user`,`jam`) VALUES 
 ('20130128-130055','PNS','admin','2013-01-28 13:00:55'),
 ('20130128-130058','Karyawan Swasta','admin','2013-01-28 13:00:58'),
 ('20130128-130100','TNI','admin','2013-01-28 13:01:00'),
 ('20130128-130103','Ibu Rumah Tangga','admin','2013-02-13 14:38:57');
/*!40000 ALTER TABLE `pekerjaan` ENABLE KEYS */;


--
-- Definition of table `pembelian`
--

DROP TABLE IF EXISTS `pembelian`;
CREATE TABLE `pembelian` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `supplierid` varchar(30) NOT NULL,
  `jenjangid` varchar(30) NOT NULL,
  `permintaanid` varchar(30) NOT NULL,
  `diskon` double(15,2) NOT NULL,
  `ppn` double(9,2) NOT NULL,
  `pph22` double(9,2) NOT NULL,
  `tempo` double(9,0) NOT NULL DEFAULT '0',
  `keterangan` varchar(300) NOT NULL,
  `tunai` char(1) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`supplierid`,`jenjangid`,`permintaanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

/*!40000 ALTER TABLE `pembelian` DISABLE KEYS */;
INSERT INTO `pembelian` (`id`,`tanggal`,`nobukti`,`supplierid`,`jenjangid`,`permintaanid`,`diskon`,`ppn`,`pph22`,`tempo`,`keterangan`,`tunai`,`cetak`,`user`,`jam`) VALUES 
 ('20130314-141618','2013-03-14','PO.13030001','1','20130314-091006','ADMN20130314-131828',0.00,0.00,0.00,0,'','0','0','admin','2013-03-14 14:16:18');
/*!40000 ALTER TABLE `pembelian` ENABLE KEYS */;


--
-- Definition of table `pembeliandetail`
--

DROP TABLE IF EXISTS `pembeliandetail`;
CREATE TABLE `pembeliandetail` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembeliandetail`
--

/*!40000 ALTER TABLE `pembeliandetail` DISABLE KEYS */;
INSERT INTO `pembeliandetail` (`id`,`barangid`,`satuanid`,`kuantitas`,`harga`) VALUES 
 ('20130314-141618','1','20130314-124420',1000.00,1200.00);
/*!40000 ALTER TABLE `pembeliandetail` ENABLE KEYS */;


--
-- Definition of table `pembelianretur`
--

DROP TABLE IF EXISTS `pembelianretur`;
CREATE TABLE `pembelianretur` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `pembelianid` varchar(30) NOT NULL,
  `terimaid` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pembelianid`,`terimaid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelianretur`
--

/*!40000 ALTER TABLE `pembelianretur` DISABLE KEYS */;
INSERT INTO `pembelianretur` (`id`,`tanggal`,`nobukti`,`pembelianid`,`terimaid`,`jurnalid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130314-150305','2013-03-14','RB.13030001','20130314-141618','ADMN20130314-143940','ADMN1303140005','','0','admin','2013-03-14 15:03:05');
/*!40000 ALTER TABLE `pembelianretur` ENABLE KEYS */;


--
-- Definition of table `pembelianreturdetail`
--

DROP TABLE IF EXISTS `pembelianreturdetail`;
CREATE TABLE `pembelianreturdetail` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelianreturdetail`
--

/*!40000 ALTER TABLE `pembelianreturdetail` DISABLE KEYS */;
INSERT INTO `pembelianreturdetail` (`id`,`barangid`,`satuanid`,`kuantitas`) VALUES 
 ('20130314-150305','1','20130314-124420',50.00);
/*!40000 ALTER TABLE `pembelianreturdetail` ENABLE KEYS */;


--
-- Definition of table `pembelianreturdetail2`
--

DROP TABLE IF EXISTS `pembelianreturdetail2`;
CREATE TABLE `pembelianreturdetail2` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `terimaid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`terimaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelianreturdetail2`
--

/*!40000 ALTER TABLE `pembelianreturdetail2` DISABLE KEYS */;
INSERT INTO `pembelianreturdetail2` (`id`,`barangid`,`terimaid`,`kuantitas`,`harga`) VALUES 
 ('20130314-150305','1','ADMN20130314-150126',50.00,1000.00);
/*!40000 ALTER TABLE `pembelianreturdetail2` ENABLE KEYS */;


--
-- Definition of table `pendidikan`
--

DROP TABLE IF EXISTS `pendidikan`;
CREATE TABLE `pendidikan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendidikan`
--

/*!40000 ALTER TABLE `pendidikan` DISABLE KEYS */;
INSERT INTO `pendidikan` (`id`,`nama`,`user`,`jam`) VALUES 
 ('20130128-130055','SMA','admin','2013-01-28 13:00:55'),
 ('20130128-130058','S1','admin','2013-01-28 13:00:58'),
 ('20130128-130100','S2','admin','2013-01-28 13:01:00'),
 ('20130128-130103','SMK','admin','2013-01-28 13:01:03');
/*!40000 ALTER TABLE `pendidikan` ENABLE KEYS */;


--
-- Definition of table `penjkategori`
--

DROP TABLE IF EXISTS `penjkategori`;
CREATE TABLE `penjkategori` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjkategori`
--

/*!40000 ALTER TABLE `penjkategori` DISABLE KEYS */;
INSERT INTO `penjkategori` (`id`,`nama`,`aktif`,`user`,`jam`) VALUES 
 ('20130227-093718','Buku','1','admin','2013-02-27 09:37:18'),
 ('20130227-093722','Alat Tulis','1','admin','2013-02-27 09:37:22');
/*!40000 ALTER TABLE `penjkategori` ENABLE KEYS */;


--
-- Definition of table `penjpelanggan`
--

DROP TABLE IF EXISTS `penjpelanggan`;
CREATE TABLE `penjpelanggan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `alamat` varchar(300) NOT NULL,
  `kotaid` varchar(30) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `npwp` varchar(100) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`kotaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjpelanggan`
--

/*!40000 ALTER TABLE `penjpelanggan` DISABLE KEYS */;
INSERT INTO `penjpelanggan` (`id`,`nama`,`contact`,`alamat`,`kotaid`,`telepon`,`npwp`,`user`,`jam`) VALUES 
 ('p1','pelanggan 1','','','20100321-200822150','','12345','admin','2013-03-20 14:58:44');
/*!40000 ALTER TABLE `penjpelanggan` ENABLE KEYS */;


--
-- Definition of table `penjpesanan`
--

DROP TABLE IF EXISTS `penjpesanan`;
CREATE TABLE `penjpesanan` (
  `id` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `pelangganid` varchar(30) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pelangganid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjpesanan`
--

/*!40000 ALTER TABLE `penjpesanan` DISABLE KEYS */;
INSERT INTO `penjpesanan` (`id`,`tanggal`,`nobukti`,`pelangganid`,`keterangan`,`user`,`jam`) VALUES 
 ('ADMN20130316-101005','2013-03-16','PP.13030001','p1','','admin','2013-03-16 10:11:24');
/*!40000 ALTER TABLE `penjpesanan` ENABLE KEYS */;


--
-- Definition of table `penjpesanandetail`
--

DROP TABLE IF EXISTS `penjpesanandetail`;
CREATE TABLE `penjpesanandetail` (
  `id` varchar(30) NOT NULL,
  `produkid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  `diskon` double(15,2) NOT NULL,
  KEY `id` (`id`,`produkid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjpesanandetail`
--

/*!40000 ALTER TABLE `penjpesanandetail` DISABLE KEYS */;
INSERT INTO `penjpesanandetail` (`id`,`produkid`,`kuantitas`,`harga`,`diskon`) VALUES 
 ('ADMN20130316-101005','ADMN20130315-100623',10.00,1000.00,50.00);
/*!40000 ALTER TABLE `penjpesanandetail` ENABLE KEYS */;


--
-- Definition of table `penjsuratjalan`
--

DROP TABLE IF EXISTS `penjsuratjalan`;
CREATE TABLE `penjsuratjalan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `penjualanid` varchar(30) NOT NULL DEFAULT '',
  `sopir` varchar(100) NOT NULL DEFAULT '',
  `truk` varchar(100) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`penjualanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjsuratjalan`
--

/*!40000 ALTER TABLE `penjsuratjalan` DISABLE KEYS */;
INSERT INTO `penjsuratjalan` (`id`,`tanggal`,`nobukti`,`penjualanid`,`sopir`,`truk`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130320-161751','2013-03-20','SJ.13030001','20130320-125206','dfdf','dfdffff','','0','admin','2013-03-20 16:18:01');
/*!40000 ALTER TABLE `penjsuratjalan` ENABLE KEYS */;


--
-- Definition of table `penjsuratjalandetail`
--

DROP TABLE IF EXISTS `penjsuratjalandetail`;
CREATE TABLE `penjsuratjalandetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL DEFAULT '',
  `produkid` varchar(30) NOT NULL DEFAULT '',
  `satuanid` varchar(30) NOT NULL DEFAULT '',
  `kuantitas` double(9,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`produkid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjsuratjalandetail`
--

/*!40000 ALTER TABLE `penjsuratjalandetail` DISABLE KEYS */;
INSERT INTO `penjsuratjalandetail` (`id`,`id2`,`produkid`,`satuanid`,`kuantitas`) VALUES 
 ('20130320-161751','1','ADMN20130316-093310','20130314-124420',2.00);
/*!40000 ALTER TABLE `penjsuratjalandetail` ENABLE KEYS */;


--
-- Definition of table `penjualan`
--

DROP TABLE IF EXISTS `penjualan`;
CREATE TABLE `penjualan` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `nopajak` varchar(100) NOT NULL,
  `pelangganid` varchar(30) NOT NULL,
  `jurnalid` varchar(30) NOT NULL,
  `diskon` double(15,2) NOT NULL,
  `ppn` double(9,2) NOT NULL,
  `ongkos` double(15,2) NOT NULL,
  `bayar` double(15,2) NOT NULL,
  `kembalian` double(15,2) NOT NULL,
  `tunai` char(1) NOT NULL,
  `tempo` double(9,0) NOT NULL,
  `kirim` char(1) NOT NULL,
  `penerima` varchar(100) NOT NULL,
  `alamatkirim` varchar(300) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`pelangganid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

/*!40000 ALTER TABLE `penjualan` DISABLE KEYS */;
INSERT INTO `penjualan` (`id`,`tanggal`,`nobukti`,`nopajak`,`pelangganid`,`jurnalid`,`diskon`,`ppn`,`ongkos`,`bayar`,`kembalian`,`tunai`,`tempo`,`kirim`,`penerima`,`alamatkirim`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130320-125206','2013-03-20','FP.13030001','010.000-13.00000001','p1','ADMN1303200001',2000.00,10.00,15000.00,0.00,0.00,'0',10,'1','aa','sss','','0','admin','2013-03-21 13:52:13'),
 ('20130321-110146','2013-03-21','FP.13030002','','','ADMN1303210002',0.00,0.00,0.00,0.00,0.00,'1',0,'0','','','','0','admin','2013-03-21 11:01:46');
/*!40000 ALTER TABLE `penjualan` ENABLE KEYS */;


--
-- Definition of table `penjualandetail`
--

DROP TABLE IF EXISTS `penjualandetail`;
CREATE TABLE `penjualandetail` (
  `id` varchar(30) NOT NULL,
  `pesananid` varchar(30) NOT NULL,
  `produkid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  `diskon` double(15,2) NOT NULL,
  KEY `id` (`id`,`pesananid`,`produkid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualandetail`
--

/*!40000 ALTER TABLE `penjualandetail` DISABLE KEYS */;
INSERT INTO `penjualandetail` (`id`,`pesananid`,`produkid`,`satuanid`,`kuantitas`,`harga`,`diskon`) VALUES 
 ('20130321-110146','','ADMN20130315-100623','20130314-124420',5.00,1000.00,0.00),
 ('20130320-125206','','ADMN20130316-093310','20130314-124420',2.00,20000.00,0.00);
/*!40000 ALTER TABLE `penjualandetail` ENABLE KEYS */;


--
-- Definition of table `penjualandetail2`
--

DROP TABLE IF EXISTS `penjualandetail2`;
CREATE TABLE `penjualandetail2` (
  `id` varchar(30) NOT NULL,
  `produkid` varchar(30) NOT NULL,
  `produksiid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`produkid`,`produksiid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualandetail2`
--

/*!40000 ALTER TABLE `penjualandetail2` DISABLE KEYS */;
INSERT INTO `penjualandetail2` (`id`,`produkid`,`produksiid`,`kuantitas`,`harga`) VALUES 
 ('20130321-110146','ADMN20130315-100623','ADMN20130318-102239',5.00,100000.00),
 ('20130320-125206','ADMN20130316-093310','ADMN20130318-105541',2.00,30000.00);
/*!40000 ALTER TABLE `penjualandetail2` ENABLE KEYS */;


--
-- Definition of table `penjualanretur`
--

DROP TABLE IF EXISTS `penjualanretur`;
CREATE TABLE `penjualanretur` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `penjualanid` varchar(30) NOT NULL,
  `jurnalid` varchar(30) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `cetak` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`penjualanid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualanretur`
--

/*!40000 ALTER TABLE `penjualanretur` DISABLE KEYS */;
INSERT INTO `penjualanretur` (`id`,`tanggal`,`nobukti`,`penjualanid`,`jurnalid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('20130320-155519','2013-03-20','RJ.13030001','20130320-125206','ADMN1303200002','','0','admin','2013-03-20 15:55:19');
/*!40000 ALTER TABLE `penjualanretur` ENABLE KEYS */;


--
-- Definition of table `penjualanreturdetail`
--

DROP TABLE IF EXISTS `penjualanreturdetail`;
CREATE TABLE `penjualanreturdetail` (
  `id` varchar(30) NOT NULL,
  `produkid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  KEY `id` (`id`,`produkid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualanreturdetail`
--

/*!40000 ALTER TABLE `penjualanreturdetail` DISABLE KEYS */;
INSERT INTO `penjualanreturdetail` (`id`,`produkid`,`satuanid`,`kuantitas`) VALUES 
 ('20130320-155519','ADMN20130316-093310','20130314-124420',1.00);
/*!40000 ALTER TABLE `penjualanreturdetail` ENABLE KEYS */;


--
-- Definition of table `penjualanreturdetail2`
--

DROP TABLE IF EXISTS `penjualanreturdetail2`;
CREATE TABLE `penjualanreturdetail2` (
  `id` varchar(30) NOT NULL,
  `produkid` varchar(30) NOT NULL,
  `produksiid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`produkid`,`produksiid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualanreturdetail2`
--

/*!40000 ALTER TABLE `penjualanreturdetail2` DISABLE KEYS */;
INSERT INTO `penjualanreturdetail2` (`id`,`produkid`,`produksiid`,`kuantitas`,`harga`) VALUES 
 ('20130320-155519','ADMN20130316-093310','ADMN20130318-105541',1.00,30000.00);
/*!40000 ALTER TABLE `penjualanreturdetail2` ENABLE KEYS */;


--
-- Definition of table `prodkategori`
--

DROP TABLE IF EXISTS `prodkategori`;
CREATE TABLE `prodkategori` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prodkategori`
--

/*!40000 ALTER TABLE `prodkategori` DISABLE KEYS */;
INSERT INTO `prodkategori` (`id`,`nama`,`aktif`,`user`,`jam`) VALUES 
 ('20130315-083529','Beton','1','admin','2013-03-15 08:35:47'),
 ('20130315-083545','Makanan','1','admin','2013-03-15 08:35:45');
/*!40000 ALTER TABLE `prodkategori` ENABLE KEYS */;


--
-- Definition of table `prodmesin`
--

DROP TABLE IF EXISTS `prodmesin`;
CREATE TABLE `prodmesin` (
  `id` varchar(30) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prodmesin`
--

/*!40000 ALTER TABLE `prodmesin` DISABLE KEYS */;
INSERT INTO `prodmesin` (`id`,`kode`,`nama`,`aktif`,`user`,`jam`) VALUES 
 ('20130313-132120','1','mesin 1','1','admin','2013-03-13 13:21:20'),
 ('20130315-101212','2','mesin 2','1','admin','2013-03-15 10:12:12');
/*!40000 ALTER TABLE `prodmesin` ENABLE KEYS */;


--
-- Definition of table `prodqc`
--

DROP TABLE IF EXISTS `prodqc`;
CREATE TABLE `prodqc` (
  `id` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `produksiid` varchar(30) NOT NULL,
  `jurnalid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `rusak` double(9,2) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`produksiid`,`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prodqc`
--

/*!40000 ALTER TABLE `prodqc` DISABLE KEYS */;
INSERT INTO `prodqc` (`id`,`tanggal`,`nobukti`,`produksiid`,`jurnalid`,`kuantitas`,`rusak`,`keterangan`,`user`,`jam`) VALUES 
 ('ADMN20130321-105029','2013-03-21','QC.13030001','ADMN20130318-102239','ADMN1303210001',10.00,2.00,'','admin','2013-03-21 10:54:16');
/*!40000 ALTER TABLE `prodqc` ENABLE KEYS */;


--
-- Definition of table `prodrevisi`
--

DROP TABLE IF EXISTS `prodrevisi`;
CREATE TABLE `prodrevisi` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `nobukti` varchar(30) NOT NULL DEFAULT '',
  `jurnalid` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(300) NOT NULL DEFAULT '',
  `cetak` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`jurnalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prodrevisi`
--

/*!40000 ALTER TABLE `prodrevisi` DISABLE KEYS */;
INSERT INTO `prodrevisi` (`id`,`tanggal`,`nobukti`,`jurnalid`,`keterangan`,`cetak`,`user`,`jam`) VALUES 
 ('ADMN20130318-105541','2013-03-18','RP.13030001','ADMN1303180002','','0','admin','2013-03-18 10:56:09');
/*!40000 ALTER TABLE `prodrevisi` ENABLE KEYS */;


--
-- Definition of table `prodrevisidetail`
--

DROP TABLE IF EXISTS `prodrevisidetail`;
CREATE TABLE `prodrevisidetail` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `id2` varchar(10) NOT NULL,
  `produkid` varchar(30) NOT NULL DEFAULT '',
  `satuanid` varchar(30) NOT NULL DEFAULT '',
  `kuantitas` double(9,2) NOT NULL DEFAULT '0.00',
  `harga` double(15,2) NOT NULL DEFAULT '0.00',
  KEY `id` (`id`,`produkid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prodrevisidetail`
--

/*!40000 ALTER TABLE `prodrevisidetail` DISABLE KEYS */;
INSERT INTO `prodrevisidetail` (`id`,`id2`,`produkid`,`satuanid`,`kuantitas`,`harga`) VALUES 
 ('ADMN20130318-105541','1','ADMN20130315-100623','20130314-124420',15.00,25000.00),
 ('ADMN20130318-105541','2','ADMN20130316-093310','20130314-124420',20.00,30000.00);
/*!40000 ALTER TABLE `prodrevisidetail` ENABLE KEYS */;


--
-- Definition of table `produk`
--

DROP TABLE IF EXISTS `produk`;
CREATE TABLE `produk` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kategoriid` varchar(30) NOT NULL,
  `accountid` varchar(30) NOT NULL DEFAULT '',
  `accpenjualan` varchar(30) NOT NULL DEFAULT '',
  `acchpp` varchar(30) NOT NULL,
  `accgagal` varchar(30) NOT NULL,
  `hargajual` double(15,2) NOT NULL,
  `hargastok` double(15,2) NOT NULL,
  `minimal` double(9,2) NOT NULL,
  `expired` char(1) NOT NULL DEFAULT '',
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`satuanid`,`kategoriid`,`accountid`,`accpenjualan`,`acchpp`,`accgagal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

/*!40000 ALTER TABLE `produk` DISABLE KEYS */;
INSERT INTO `produk` (`id`,`kode`,`nama`,`satuanid`,`kategoriid`,`accountid`,`accpenjualan`,`acchpp`,`accgagal`,`hargajual`,`hargastok`,`minimal`,`expired`,`aktif`,`user`,`jam`) VALUES 
 ('ADMN20130315-100623','1','produk 1','20130314-124420','20130315-083529','120-03','700-05','850-06','850-07',1000.00,500.00,100.00,'1','1','admin','2013-03-21 08:53:24'),
 ('ADMN20130316-093310','2','produk 2','20130314-124420','20130315-083529','120-04','700-05','850-06','850-07',20000.00,10000.00,100.00,'1','1','admin','2013-03-21 08:53:36');
/*!40000 ALTER TABLE `produk` ENABLE KEYS */;


--
-- Definition of table `produkdetail`
--

DROP TABLE IF EXISTS `produkdetail`;
CREATE TABLE `produkdetail` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `kuantitas` double(15,3) NOT NULL,
  KEY `id` (`id`,`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produkdetail`
--

/*!40000 ALTER TABLE `produkdetail` DISABLE KEYS */;
INSERT INTO `produkdetail` (`id`,`barangid`,`satuanid`,`kuantitas`) VALUES 
 ('ADMN20130315-100623','1','20130314-124420',100.000),
 ('ADMN20130316-093310','1','20130314-124420',10.000),
 ('ADMN20130316-093310','3','20130314-124420',20.000);
/*!40000 ALTER TABLE `produkdetail` ENABLE KEYS */;


--
-- Definition of table `produkharga`
--

DROP TABLE IF EXISTS `produkharga`;
CREATE TABLE `produkharga` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `barangid` varchar(30) NOT NULL DEFAULT '',
  `satuanid` varchar(30) NOT NULL DEFAULT '',
  `minimal` double(9,2) NOT NULL DEFAULT '0.00',
  `maksimal` double(9,2) NOT NULL DEFAULT '0.00',
  `harga` double(15,2) NOT NULL DEFAULT '0.00',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`barangid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produkharga`
--

/*!40000 ALTER TABLE `produkharga` DISABLE KEYS */;
/*!40000 ALTER TABLE `produkharga` ENABLE KEYS */;


--
-- Definition of table `produksi`
--

DROP TABLE IF EXISTS `produksi`;
CREATE TABLE `produksi` (
  `id` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `nobukti` varchar(30) NOT NULL,
  `mesinid` varchar(30) NOT NULL,
  `produkid` varchar(30) NOT NULL,
  `satuanid` varchar(30) NOT NULL,
  `jurnalid` varchar(30) NOT NULL,
  `kuantitas` double(9,2) NOT NULL,
  `keterangan` varchar(300) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`mesinid`,`produkid`,`jurnalid`,`satuanid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produksi`
--

/*!40000 ALTER TABLE `produksi` DISABLE KEYS */;
INSERT INTO `produksi` (`id`,`tanggal`,`nobukti`,`mesinid`,`produkid`,`satuanid`,`jurnalid`,`kuantitas`,`keterangan`,`user`,`jam`) VALUES 
 ('ADMN20130318-102239','2013-03-18','PD.13030001','20130313-132120','ADMN20130315-100623','20130314-124420','ADMN1303180001',12.00,'','admin','2013-03-21 10:54:31');
/*!40000 ALTER TABLE `produksi` ENABLE KEYS */;


--
-- Definition of table `produksidetail`
--

DROP TABLE IF EXISTS `produksidetail`;
CREATE TABLE `produksidetail` (
  `id` varchar(30) NOT NULL,
  `barangid` varchar(30) NOT NULL,
  `terimaid` varchar(30) NOT NULL,
  `kuantitas` double(9,3) NOT NULL,
  `harga` double(15,2) NOT NULL,
  KEY `id` (`id`,`barangid`,`terimaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produksidetail`
--

/*!40000 ALTER TABLE `produksidetail` DISABLE KEYS */;
INSERT INTO `produksidetail` (`id`,`barangid`,`terimaid`,`kuantitas`,`harga`) VALUES 
 ('ADMN20130318-102239','1','ADMN20130314-150126',1200.000,1000.00);
/*!40000 ALTER TABLE `produksidetail` ENABLE KEYS */;


--
-- Definition of table `profile`
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile` (
  `nama` varchar(300) NOT NULL,
  `alamat` varchar(300) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `propinsiid` varchar(30) NOT NULL,
  `kotaid` varchar(30) NOT NULL DEFAULT '',
  `kecamatanid` varchar(30) NOT NULL,
  `kelurahanid` varchar(30) NOT NULL,
  `logo` mediumblob,
  `logo2` mediumblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` (`nama`,`alamat`,`telepon`,`propinsiid`,`kotaid`,`kecamatanid`,`kelurahanid`,`logo`,`logo2`) VALUES 
 ('Pabrik ABC','DESA SUMBERSUKO ','123','26','20100321-200829401','20121108-111219','20121108-111954',0xFFD8FFE000104A46494600010200006400640000FFEC00114475636B79000100040000003C0000FFEE000E41646F62650064C000000001FFDB0084000604040405040605050609060506090B080606080B0C0A0A0B0A0A0C100C0C0C0C0C0C100C0E0F100F0E0C1313141413131C1B1B1B1C1F1F1F1F1F1F1F1F1F1F010707070D0C0D181010181A1511151A1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1F1FFFC0001108015E015E03011100021101031101FFC400C0000100020301010100000000000000000000060801050704020301010002030101000000000000000000000001050306070402100001020302070C0508060709000000000001020304051106213112D255360741516191D152B21374941516712293B31481A1B13242547508F0C1627292A2E182C223244425F133435363738334641101000102020509070303040203010000000102031104213151120541719132527213533461B1229214150681A1D1C1E14262233343F0B2F182C224FFDA000C03010002110311003F00B52AA888AAB81131A81A4897DEE7437B9912B724C7B155AF6BA621A2B5C98151515701F335D31CAF7D1C2F355C634DBAE63BB2CA5F7B9CB852B723DE21671F3E2D1B609E179A8FFAEBF964F3B5CED3723DE21670F1A8DB08FB6667CBAFE593CED73B4DC8F78859C3C6A36C1F6CCCF975FCB279DAE769B91EF10B3878D46D83ED999F2EBF964F3B5CED3723DE21670F1A8DB07DB333E5D7F2C9E76B9DA6E47BC42CE1E351B60FB6667CBAFE593CED73B4DC8F78859C3C6A36C1F6CCCF975FCB279DAE769B91EF10B3878D46D83ED999F2EBF964F3B5CED3723DE21670F1A8DB07DB333E5D7F2C9E76B9DA6E47BC42CE1E351B60FB6667CBAFE593CED73B4DC8F78859C3C6A36C1F6CCCF975FCB279DAE769B91EF10B3878D46D83ED999F2EBF964F3B5CED3723DE21670F1A8DB07DB333E5D7F2C9E76B9DA6E47BC42CE1E351B60FB6667CBAFE593CED73B4DC8F78859C3C6A36C1F6CCCF975FCB279DAE769B91EF10B3878D46D83ED999F2EBF964F3B5CED3723DE21670F1A8DB07DB333E5D7F2C9E76B9DA6E47BC42CE1E351B60FB6667CBAFE593CED73B4DC8F78859C3C6A36C1F6CCCF975FCB279DAE769B91EF10B3878D46D83ED999F2EBF964F3B5CED3723DE21670F1A8DB07DB333E5D7F2C9E76B9DA6E47BC42CE1E351B60FB6667CBAFE593CED73B4DC8F78859C3C6A36C1F6CCCF975FCB279DAE769B91EF10B3878D46D83ED999F2EBF964F3B5CED3723DE21670F1A8DB07DB333E5D7F2CBE56FD5C94546AD7E9C8E5C4D59A828BC4AE1E351B63A53F6BCD79573E59FE1FA41BE574A344EAA156649F1398D9886ABD2262E533CA8AB866662319B75E1DD96CA14EC9C64B6147871137DAF6BBE853EB1792AA2AA75C60FD897C0000000000000000000000000846D0365945BD705D330DAD93AD31AA9067589623F06064644FACDE1C69B860BD622B8D92BAE15C6EEE52AC31DEB7B3F856BADD12AB43A9C6A654E02CBCDC05B1CD5C4A8BF51CD5FB4D76E2A14D72D6E4E12EA992CF5BCCDB8AEDCEBE4D8F0FEB31E11B1EA899906108A6A99806109C6418418C830831906106320C20C6418418C830831906106320C20C6418418C830831906106320C20C6418418C830831906106320C20C6418418C830831906106320C20C641BB06320DD83193751570D834F24A1984E742723E1395911313DAB6393E5C67D4555472BE2AB5455AE989FD1B593BDD7A649FD64AD5E6E13ACB2D48CF5C5FBCAA7DC5EAE395E5BBC332D7230AADD3D0945336E1B4092C1126A0CEB113EACCC2455B6DC7950D61BBE73D14E76B8D7A54D7FF0014CA57AA269E69FE536A27E63241F910EB54C8905D622449895724465B6615586E547225BC2A7A28CFC4EB851E6BF0DB91FF000D5BDEC9D1FBBA25DFBFF742BE8894DA94289157FCBBD7AB8BFC0FB1C7AE8BB4D5AA5ADE73856672D3FEE5131EDE4E9484C8AE0000000000000000000215B51D9ECB5EDA365414465624DAE7C9454B132ED4C305EABF65CB67A14C37ACC571ED5DF04E2F564EEE3FE13AFF00955D8B0A2428AF8515AAC8AC556BD8E4B1CD722D8AD54DF4DD28AB8C25D668B91BB15F254F921F7BB86809000000000000000000000000000000000000000000000008DD46F60587D4682A98AB461BDCFF00DD32BABB58BE1779190614D7C6C93325A92934B96888DDC63FEB37060C0BF219EDE6EBA27FD2A2E23F8F65F31F14D3B95FFA7FAC46B765BA1B6BBAB5D7325A715695507AA35214754586F72A7D88A9831F3AC2CAD66E8AF9DA4711FC6B31978DE8F8E8DB1AFA35BA0B5CD7351CD5456AE1454C28A87A5AECC60C800000000000000002BCEDE2E736975C875E94879329555548E8D4446B665A96BB06FC46A2BBD394A55676CE9DE8746FC6389F8B626C553F151D5E6FEDABA1CB2C54C0B8CF0B74AE71903E00000000000000000000000000000000000000000000000004E320C511A271862C4B2CDCDE222302A8DED7A535B97B57BCF761CC8291567E98DB116463AAAA236DB57AA7E1562E1F4701EBB39A9A344E986BDC53F1FB19889AB0DCAF9263FF00D6DFD9612E85FBBBD7AA57ADA647FF0010C445989389EAC6876EFB7753F69301696AED35C630E77C47855FCA5585C8D13AA79252132AB40000000000000113DAB536527EE0D5D930D47751056620BB75B1217ACD54FA3D0A61CC46344ADF815DAA8CDDBC39670FD15452DB12DC7C25053A9D83164FA00000000000000000000000000000000000000000000000000000089A714BD14EA94FD32761CF53E3BE566E12A3A14686B62A2F0F070625DD3EE8AE68D4C198CB537A89A2BC2AA6792752C36CCF6C12778D594BABE44A56ACB213930428E8889852DFAAF5E67116B96CD457A27ACE69C6FF001EAF2D335DB899B3FBC3A59EC6B200000000000047368FA875DEC717A263BDD49E659F06F576FBD0A926BF0EC74EA0948000000000000000000000000000000000000000000000000000000032D739AE6B98AAD7B5515AF4C68A8B6A2A70F0EE1313BBA515C46118C638BBFEC8B6B2EABF5741AF4444A9352C929C72A275E89FF0DD8BFBC6A2A58BF6BD38ED72B99DFD13ADCE7F23FC7E32F3E2D9D36E75C767FB3AC9ED69E0000000000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A400000000000000000C406203101880C406203101880C406203108C51BD013090000000000000000000888C265963DEC723D8E56B9AA8E6B916C5456ADA8A8A9BCA4D3386A4554C4C613FF9FA2CAEC8768A979A95E1F5089FEB522D448AF7588B1E1A628A88888995B8E44F4EE97195BFBF184EB872DFC8783FD2DDDEA23FDAAB57B3D9FC3A19EA6B80000000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A825200000000000491ACC3FD3FAB7026AAE218B5BBE37717C45CA67FCA20CA6EF93B89DFA7B51FB194DDF1B86FD3DA8FD8CA6EF8DC37E9ED47EC65377C6E1BF4F6A3F6329BBE370DFA7B51FB194DDF1B86FD3DA8FD8CA6EF8DC37E9ED47EC65377C6E1BF4F6A3F6329BBE370DFA7B51FB194DDF1B86FD3DA8FD8CA6EF8DC37E9ED47ECCDA8B8948DC7C4DEB78E18E32C22A2E2C3F2FCE46EBEA2A89D4C90FA090000000000000000006C2815C9FA155E5AAB2313AB99967239BCD722FAAAD76FDA8AA9F29F76AA9A2779E7CDE528CCDAAAD57D5A96D2EBDE292BC54295ABC9DA90A65B6BA1BBEB4388D5C97B1DC2D722A17B6EB8AA31871ACEE4EBCBDD9B75EBA5B53EDE5000000047368FA875DEC717A263BDD49E659F06F576FBD0A926BF0EC74EA0948000000000002753697558C7DE7A431ED4731D3B2E8E6AA5A8A8B1988A8A8BBE864CBE9AF4BC1C526632B54C6BC256E128B46B13FC04BFB26721774D14E1A9C7A73377B5574CB3E0B46FB84BFB267213E1D3B211F5377B5574C9E0B46FB84BFB26720F0E9D907D4DDED55D32782D1BEE12FEC99C83C3A7641F5377B5574C9E0B46FB84BFB26720F0E9D907D4DDED55D32782D1BEE12FEC99C83C3A7641F5377B5574C9E0B46FB84BFB26720F0E9D907D4DDED55D32782D1BEE12FEC99C83C3A7641F5377B5574C9E0B46FB84BFB26720F0E9D907D4DDED55D32782D1BEE12FEC99C83C3A7641F5377B5574C9E0B46FB84BFB26720F0E9D907D4DDED55D32782D1BEE12FEC99C83C3A7641F5377B5574CB0B44A32FF009097F650F909DCA7641F5377B7574CB5F3F72EE94F22FC551A4E22AA58AEEA21A3ACFDE4445F9CF99B54EC867B5C573346AB95FCD287D6760D72E758AB2291A991B71D09EB119FC1115DF4986BC9D3569D4B7CAFE559BB5AFE38FF005699732BD1B16BD94663E3CA236AB26CC2E8901AAD8A89C30955557FAA786EE4EAA35696D9C3FF002BCAE62629AF1A2AFDBDC80AB5CD72B5CD56B9AAA8E6AA58A8A98D14F24E3CADA22698F8B1C62582379138CE98D4126F63A40000000000007E9FA7188D3A113A743AA6C0EF6AD3ABB128130F5F84AAAABA5DBB8C9886DC7FF918993E9443DF92B984EEB51FCBB21E35A8CC531A68D7ED8FECB0A5A39B8000000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A400000000000413A9B5BA7AD547EDD2DEF9864CBF5D5FC57D257CD2B88988BEA7538C04800000000000000000166108C187229309C5F392B662E308899632572B12FA48DEC49D3C9FAA097F365544BCD0DF1E0B1B2358B3FBB9A6A607AE3B22B5BF5BD38D0F3DECB455A579C1F8E5DCAD5BBD6B71C8AEB5FA0D5683548B4DA9C0581330AC5C76B5CD77D57B5D89517E629EE5A9A65D3F87E768CDD3E25BAB18D8D721F0F6EFEF69C306410000000000004C22B8C62236EB7E92F311E5A621CCCB3D614C417362418AD5B15AE6ADAD722EFA2A0A6A98AB145DA62BA26898C69C3A5702EAD761D7AEED3EAF0D11BF1905AF7B1313626288DC3CD7A2A17F6EBDEA625C533D959B17AAB73FE33FFC7ECDA9F6F28000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A825200000000000209D4DADD3D6AA3F6E96F7CC3265FAEAFE2BE92BE695C44C45F53A9C60240000000000000000000000001F2EC7C022513A34A1DB48B892B7B28CE84DC9875597457C84CAA62763563B1FAAFB2CF9CC198B31542DF83F18AF2976263A956B55D98978D2D1E24B4786B0A3C172C38B09D8DAE62D8A8BE8B0A5AA8DD9C1D76D5CA6BA626354BF3FA37087DEA084E200000000000077EFCBBD7224C50AA14788B6FC0466C581BF911D16D4F91EC55F94B6C8D78D186C73AFCC727145EA6EC7FD91FFAE0EB67B5A68000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A825200000000000209D4DADD3D6AA3F6E96F7CC3265FAEAFE2BE92BE695C44C45F53A9C60240000000000000000000000000B3840F9565BBA4441CB8ABE6DEEEAB69D786056E59B641AA2591D130224782896AFF00599F429599DB7F14D4E8BF88E766E5A9B554FF00C7AB9A71F7395E0B12C5B52CC788F044B74A34E007C44E20480000000000E93B02A8ACB5FAF86572E44F4AC6848D45F572D8AD8A8AA9BF930D6C3DB919F89AA7E5F637B2B15F66AF7E85902D9CCC000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D412900000000000104EA6D6E9EB551FB74B7BE61932FD757F15F495F34AE22622FA9D4E3012000000000000000000000000000039FEDC296C9DB85371F232E248C4831E1EFA7AE8C72FF0BD4F366A9C685FFE337A69CE453DAD1FD5598A48757EACCFB02520000000000004B365133F0DB43A244B1572A3AC2B13FEAC27C3B57F8CF464EAFF00714BF91D1BD91B9FA7FED0B5A5DB910000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A825200000000000209D4DADD3D6AA3F6E96F7CC3265FAEAFE2BE92BE695C44C45F53A9C602400000000000000000000000000004576A0AC4B835C57D967C33B1EFDA96187313F0AD781CCFD65BC36FF455028E5D8ADCE88C43E6114EA09480000000000DF5C2EBBCEF40EAADCBF1096C29CCEB5A8FFE5B4CD95FF92155C6E63E8EEE3D95BB2F5C74000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D412900000000000104EA6D6E9EB551FB74B7BE61932FD757F15F495F34AE22622FA9D4E301200000000000000000000000005A80632DBBE4E0469D4E79B75AB4394B87312C8EB225422C2976598EC4775AEFE58761E4CDCFC2D8BF15B3BF9DA67929C71E8956A55B55577CA687558A6667E1E4088444C4EA0948000000000096EC9655B35B45A2437626C6745B3860C27C56FCEC3D1948C6E297F249C3237279BF79885AC2EDC88000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D412900000000000104EA6D6E9EB551FB74B7BE61932FD757F15F495F34AE22622FA9D4E30120000000000000000000000000C2A021F2B92DC2B890999453184E10AE5B70BD8DABDE66D2E59F9527494731CA98963BB2562707AB9393C654676F7C583A77E23C33C2B5E2D5D6ABDDC8E6C78E9D4DAAD5585521F24461A02400000000001D43F2F94A599BE3313EE65B0E4255CA8FE6C48CEC86F1B32CF7E469F8A65A8FE6399DDCBD36FB757BBFF0021624B473600000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A400000000000413A9B5BA7AD547EDD2DEF9864CBF5D5FC57D257CD2B88988BEA7538C048000000000000000000000C5AB680CA109C1F0E555B6CB0963AF57B5CFB6B1B488576E9CFA7C8B9B12B736C5482D4C3D4B571C47FF0065377E43C79ABB14C68D6D9380F06AF355C5531F046B56C73DCF72BDEE57B9EAAF739556D555C36A94F54EF69753A29A62988A753039307DCE90888C009000000002234CE099D47E9FD02674982C4EC02EF7C05D58F567A591AAD16D6FFD99757319FCEAF2E725461463B5CC7F2DCEF8999F0E3AB6FDF56132EA07ADAA8000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A825200000000000209D4DADD3D6AA3F6E96F7CC3265FAEAFE2BE92BE695C44C45F53A9C60240000000000000000000007CBB05A302234BE1EF56DAB89A98D7FDA44CE0F99DE99C21CC3683B68A6521B169F4373676AB858F8C962C182A9BAAA981EE4E6A1E4BD9B88D1CADA783FE355DEAA2BBBF0D1EF7019E9E9C9F9B8B393B15D1E666172A2C47ADB956E1E2E02A2BAA6A974AB3669B54C534C6ED30FC30AADAB85570AA867998E40200000000000026DD38CCBD749A6CC552A7294D96B3AF9C8AD810EDB6CCA8AA8DB56CDC4DD526CD3BD560F2E673516AC575CFF8C62B8547A5CB52A95294D954B2049C264187C28C4B2D5E15C6A6C34D38460E2F98BD55DB935D5AEA9C5EC2584000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D4129000000000002613461A5B3BB112143BCB498B15E90E1B2725DCF7B96C44448A8AAAAA7DE5E70AD5F9F9AA72B5D38633BB2B5CDBD5763253FD624BBC42CE2EE2E53B5C823217FB15CFF00F5967CD37634CC9778859C4F8946D4FD05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE0F34DD8D3325DE21670F128DA7D05FF002EBF96AFE18F365D745B3C624BD3F110B387894ED47D0DFF002EBF96AFE1AFA96D22E3D3FF00F62B72D6AE26C3775AABFC1947CF8F46D67B5C23377270A68ABA30F7A1D5AFCC15DA964736952D1EA316C5B1EF4F87856A62B55C8AFE269E6B99E889C217995FC3F35561372629A7F49FEAE5B7AF6A97BEF1B5F066267E1249D8164E5AD6355379CEFACE4F49E3B99AAAA6DD90FC732B97C2A98DFAB6FF006D288D9625879B1C75AF230C34461004C80000000000000044CE3A1154D51D5D6ED9F97FB98AAB16F54DB707AD2F4E6AE2DE8B13FB09F296791B1846F4B44FCBF8A44CC65ADEA8D357F4876D2C5A20000000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A40000000000053AC88D388275E844D538E186863219CD4E22674F2BEB088D14EA3219CD4E2230F698CED3219CD4E2187B4C676990CE6A710C3DA633B4C8673538861ED319DA64339A9C430F698CED3219CD4E2187B4C676990CE6A710C3DA633B4C8673538861ED319DA64339A9C430F698CED3219CD4E2187B4C676990CE6A710C3DA633B58C867353889C676A77E70C3165111312587CFEAF8DCD92C9384184EDFE3A0271298C0231C5F5333CA0400000000000118A313F4B097D4C60905C7BA1397AEBD069902D6C0FF00793930896A428498DDFBDF651384CF96B33554ABE29C569C9D99AE7AFF00E31B656C69F4F94A748C0919386906565D890E1436E0446A177118460E3D72E555D5355538CCBD04BE000000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A82520000000000000000000000000000000000000000000000000000000009827E28C363D54CA5546AB50834FA7405989C9872360C24DD5E155C4D44C2A7DDAB735CE10F3662FD16AD4DDB938452B51B3EB8D2374688D93856449D8BEBCECD5888AF7EE260FB2CB6C42EECDA8A29C1C978BF14AF397A6E4E88E48D893995560000000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A825200000000000000000000000000000000000000000000000000000080844CBD34DA6CFD4E76148C8407CCCDC77644382C4B5555717C9BEAB80FBB74555CE183E2FDFA2C51E25C9DDA2165B665B3192BA329F1530A9315D98664CCCC2616C36AAE57550B160C594EFB566F602E6C65E2DC7B5CAB8EF1AAB3B7347C36E3547F594E8F4284000000000047368FA875DEC717A263BDD49E659F06F576FBD0A926BF0EC74EA09480000000000000000000000000000000000000000000000000000112558E0DCDD6BA35BBCD516C8D2A02C45C1D74775A90A1357ED3DDB9E8C6BB87A2C589AD5FC478ADACA5BDEAF5F2472CAC9ECFF0067348BA124BD4FF89A9C644F8A9E7258ABFB10D3ECB2DDCE32DED5A8A23072FE2DC62EE72BC6AD1446AA52D32AA00000000000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D4129000000000000000000000000000000000000000000000000037F83191AB4BE2A98E5D0CC363E2446B21B5623DCA88C635329CE555B325A898D554FA8C6BD0FAAEE6E538D586EED751B91B0AAC5591B37781CFA548FD8976D9F12FDF5545456C3F951578374F6D8C8F2D4D438A7E55459F832FF001D5DAE4FEEEF345A15228920C90A54AB256559898C4C6AB8DCE55C2E72EEAA9674D31118439FE633372F5735DC9DEAA5EE3E980000000000000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A82520000000000042623109C0C006003001800C006003001800C006003001800C0060030087CCC831484E01604C9F3AEF261088D2FD656566A6E3B65E560C4988EEFAB0A135D11EBB981AD4553EA2899D4C57AFD16A31AE6298F6BA25D7D84DECAABA0C7A9AB69326EF59CB13D798B30A58D849811707DA54F41EBB593AA7ADA21AD67FF2EB16A269B71E24FEDD2ED174B66F756EC436BA465522CEA27AF3F1EC891957755157036DDE6D858DBB34D1AA1A367F8C663353F1D53BBD98D5D0941955600000000000000000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A40000000000049555841FAB90F98C648B7A3199632D9CE4E33EB09444C4E98932D9CE4E31A4FD4CB673938C693F532D9CE4E31A4FD4CB673938C693F532D9CE4E31A4FD4CB673938C693F532D9CE4E31A4FD4CB673938C693F532D9CE4E31A4FD4CB673938C693F532D9CE4E31A4FD4CB673938C6944C52653771538D06930A58EB196D99496EF5A83094C5531AA9C636E87A61484F455B214B4588AB8B261BD57E643EA2DD53C8C755FA23AD314FEB0DDD3B6777E6A0FC995A1CDADA96A3E2C3EA1967EFC6EADBF39923295CABEF71BCADB9C2ABB4E1FAD5EEC52CA4FE5FAF8CDAA2CFC796A733F69CB1DE8B6F319637F9CF453C3E79654D99FCB72B44FFB74CD7CDF0FBFF84DE87F97CBAD2A99756998F528AB8E1A2F530B899EB7F31E8A325446BD2A2CDFE5D98B9A2DC4511B75D5D2E8948BBF43A3C2EAA9723024D9BA9058D6AAFA5530AFCA7AE9A223535BCC66EEDE9C6E55555CF38B607D3CE0000000000000000000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D41290000000000008AA7536D7460418F7AA8B06331B161459E9787121BD329AE6BA2B515AA8BB8A65CB69AE21E1E2F8FD3573138614CCFECB6BE0543D1D2DEC61F217BBB0E37E357DA9E93C0687A3A57D8C3E41BB09F1ABED4F49E0343D1D2BEC61F20DD83C6AFB53D2780D0F474AFB187C83760F1ABED4F49E0343D1D2BEC61F20DD83C6AFB53D2780D0F474AFB187C83760F1ABED4F49E0343D1D2BEC61F20DD83C6AFB53D2780D0F474AFB187C83760F1ABED4F49E0343D1D2BEC61F20DD83C6AFB53D2780D0F474AFB187C83760F1ABED4F49E0343D1D2BEC61F20DD83C6AFB53D2780D0F474AFB187C83760F1ABED4F49E0142D1D2BEC61E68DD83C7B9DA9E97CADDDBBEAB6AD3255577FA8879A37613F5373B5574CBED944A2B15159212CD56ADAD54830D15178300C21137AB9D754F4BD8C63189631A8D4DE44B10962C5900000000000000000000000000000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A400000000000422BE46E6E5EB7D0BF1195F7CC32E5BAF0F0F17F4B77B93EE5C02F9C5C000000000000000000000000000000000000000000000000000000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A8252000000000002115F237372F5BE85F88CAFBE61972DD787878BFA5BBDC9F72E017CE2E000000000000000000000000000000000000000000000000000000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D412900000000000108AF91B9B97ADF42FC4657DF30CB96EBC3C3C5FD2DDEE4FB9700BE7170000000000000000000000000000000000000000000000000000000047368FA875DEC717A263BDD49E659F06F576FBD0A926BF0EC74EA0948000000000008457C8DCDCBD6FA17E232BEF9865CB75E1E1E2FE96EF727DCB805F38B80000000000000000000000000000000000000000000000000000000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A400000000000422BE46E6E5EB7D0BF1195F7CC32E5BAF0F0F17F4B77B93EE5C02F9C5C000000000000000000000000000000000000000000000000000000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A8252000000000002115F237372F5BE85F88CAFBE61972DD787878BFA5BBDC9F72E017CE2E000000000000000000000000000000000000000000000000000000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D412900000000000108AF91B9B97ADF42FC4657DF30CB96EBC3C3C5FD2DDEE4FB9700BE7170000000000000000000000000000000000000000000000000000000047368FA875DEC717A263BDD49E659F06F576FBD0A926BF0EC74EA0948000000000008457C8DCDCBD6FA17E232BEF9865CB75E1E1E2FE96EF727DCB805F38B80000000000000000000000000000000000000000000000000000000239B47D43AEF638BD131DEEA4F32CF837ABB7DE854935F8763A7504A400000000000422BE46E6E5EB7D0BF1195F7CC32E5BAF0F0F17F4B77B93EE5C02F9C5C000000000000000000000000000000000000000000000000000000011CDA3EA1D77B1C5E898EF75279967C1BD5DBEF42A49AFC3B1D3A8252000000000002115F237372F5BE85F88CAFBE61972DD787878BFA5BBDC9F72E017CE2E000000000000000000000000000000000000000000000000000000008E6D1F50EBBD8E2F44C77BA93CCB3E0DEAEDF7A1524D7E1D8E9D412900000000000108AF91B9B97ADF42FC4657DF30CB96EBC3C3C5FD2DDEE4FB9700BE7170000000000000000000000000000000000000000000000000000000047368FA875DEC717A263BDD49E659F06F576FBD0A92988D7E1D8E9D4129000000000001055C8DCDCBD70A17E232BEF9865CB75E1E0E2F3FF00F2DCEE4FB9700BE7170000000000000000000000000000000000000000000000000000000045F6A1330A5EE056DF11703A59D09BC2E88A8C6A71B8C57E70A256BC12999CDDBC3B4A9DB85043B0D3A825200000000000317CD73A9EEA0CFB69F5DA74FB9B6B652660C756EFF55111FF0042192C7C35632C5C46D6FE5EB88FF2A6617164A725A764E04E4ABD224B4CC36C5831131398F447357E5452FA2718C61C4AE5B9A2A9A6AD71383F625F0000000000000000000000000000000000000000000000000000000704DBAED020546336EC5362A3E565DE8FA84762DA8E8C8B636122A6346615770D9BC56E72FC61BB0DF7F19E1355B8FA8AE34CF563D9B5C81315BBF878CAD86F954E33A1925F20000000000041546349837716EFA0FA89453A6309582D835F46CFD156EECDC44F8DA761954555B5F2EEC39296FF00CB5B513F66CDE2D7277B7A9DDE58737FCAF854D9BBE353D4AFF69FEEEAE7B5A880000000000000000000000000000000000000000000000000000E29B5ADB0AC3598BBD77237AE88B0E7AA30DCA8AD5C1950A0B9376CB729DB9B984F06633586886EDF8F7E3737262EDD8F879227FAB88A2EEDB877FD3CA54D5A65D0AB88A642498D8138A34EC06269D80C4D3B0189A7603134EC06269D80C4D3B0208C760098F63D947AB4ED22A72D539188B0A6A51FD642726FAA58A8BC0E4B517814FBB354D15630C39ACB5198B555AAFF00C969EE0DFAA6DEEA3A4DCBFF0075390AC64ECA2ADAE63F7D37DAEDC52F6D5C8AE31722E2BC2AE64EEEE57AB9276A4C645580000000000000000000000000000000000000000000000055B12D038E6D4EFCDEA9D48D43BB74B9F6C9AE5429CA836563A2C4DC5642546E06EE656EEE60C278B3176A9D14C4B70E01C3B2B4CF8B98AE9C635538C7EEE3A9752F4A2259459FC1FF00CB1BF534ADF06A99D52DE3EEF979D335D313CF0CF952F4E859FEEB1B3499B354724BE7EE394D735D3D307952F56859FEEB1B348F0AA9E497DC714CA4FF00D94C7EA7952F56859FEEB1B3478356C93EE794F369E93CA97AB42CFF00758D9A3C1AB649F73CA79B4F49E54BD5A167FBAC6CD1E0D5B24FB9E53CDA7A4F2A5EAD0B3FDD63668F06AD927DCF29E6D3D27952F56859FEEB1B3478356C93EE794F369E93CA97AB42CFF758D9A3C1AB649F73CA79B4F49E54BD5A167FBAC6CD1E0D5B24FB9E53CDA7A4F2A5EAD0B3FDD63668F06AD927DCF29E6D3D27952F56859FEEB1B3478356C93EE794F369E912EA5EADCA2CFF00758F9A26CD731AA5F33C4B293D6B94E1CF0D85064F68141A943A8D269D50979B856D8A92B195AE6AA58AD7B55B92AD5DE5F49F76ADDCB738E979B3B98C9662DF8776AA6639E163EE55F17DE0914F8CA74CD2EA70DA9F112D31062C365BBF0DEF6A2393E72DED5CDE8D3184B99711C8C58AE628AA2BA392627DE929955C000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003FFFD9,0xFFD8FFE000104A46494600010201004800480000FFE116174578696600004D4D002A000000080007011200030000000100010000011A00050000000100000062011B0005000000010000006A012800030000000100020000013100020000001C0000007201320002000000140000008E8769000400000001000000A4000000D0000AFC8000002710000AFC800000271041646F62652050686F746F73686F70204353332057696E646F777300323031323A30313A30312032303A35353A35300000000003A00100030000000100010000A00200040000000100000064A003000400000001000000680000000000000006010300030000000100060000011A0005000000010000011E011B0005000000010000012601280003000000010002000002010004000000010000012E0202000400000001000014E10000000000000048000000010000004800000001FFD8FFE000104A46494600010200004800480000FFED000C41646F62655F434D0001FFEE000E41646F626500648000000001FFDB0084000C08080809080C09090C110B0A0B11150F0C0C0F1518131315131318110C0C0C0C0C0C110C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C010D0B0B0D0E0D100E0E10140E0E0E14140E0E0E0E14110C0C0C0C0C11110C0C0C0C0C0C110C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0CFFC00011080068006403012200021101031101FFDD00040007FFC4013F0000010501010101010100000000000000030001020405060708090A0B0100010501010101010100000000000000010002030405060708090A0B1000010401030204020507060805030C33010002110304211231054151611322718132061491A1B14223241552C16233347282D14307259253F0E1F163733516A2B283264493546445C2A3743617D255E265F2B384C3D375E3F3462794A485B495C4D4E4F4A5B5C5D5E5F55666768696A6B6C6D6E6F637475767778797A7B7C7D7E7F711000202010204040304050607070605350100021103213112044151617122130532819114A1B14223C152D1F0332462E1728292435315637334F1250616A2B283072635C2D2449354A317644555367465E2F2B384C3D375E3F34694A485B495C4D4E4F4A5B5C5D5E5F55666768696A6B6C6D6E6F62737475767778797A7B7C7FFDA000C03010002110311003F00F5384924905292543ABE7DD8748F46B2E73C3B6B9B0497012DAAA6BBDAFBECFF0007BFFF0005FE656059936D61F6577D573EE66F7869700D69E3D6C9F52A6DAC7FFDD9751FF75FF47FAB28B267C78E5084AF8B25F008C673F97E6F90492013F475ACEBF2F7329A9DED6EE2435F6B8033B1CEAE96FA7EEFA7E9FDA3D5FF008351C9EBD58C30E0F6D6E700E36B5F59968F74E354E73EDB2CB9BFCCD7E87FC62E7EEEAA30B6FDA328546D01CF00061803631AD60A5F91E9B58DF635B8387FF1EB2F27EB1F4E7584B596D8266400D9FE57EB1665EEFF00B618A119F309CF8C62842FF5638A5EF7FD5211E38FFCE6DE1F877339C038B0CE60FE9570C3FC19CF85EADDD43AB630AEECA73ABADC44CD95BDA091BDB5DFFAA636C6591E87ABEBFE8EC7ABB6F5EAC960C601EE713ED96D8E718FA2C6E3DAFDAD6FD2B2EB3D8CFF00AE2E0DBF58FA6F0EC4B479B5D448FF00D9562BF85F587A5904332ECC679FA1EAB5ED8FFAF31F9B4EDFEB6226472E718C8F730E5CBAF0CA427821FD5E28FEB3899727C239D80B972F3AEBC1C397FE83DA74EEAF5E758EA4D6EAAEAE7734CC7B76177D315D9F46EADDEFAD5F5C60B725A59961CCB05EE1BAC046C7100318EAF2A87B595DDB1BB7F9EC1B2CFF00B876AB58F9D7E23996D57B6CF51FB6DC7DA5858409B3D465916ECA99FA4BAEC8FD67FC2FA96FF47528E6787DA8E689864C8443D2253C5EE7F57247F465FA3C6D030209F0EFBBD4C250818B98CC86B411E9DE58DB1F438FBDAD7486B9C3F75DB11D595AB77493F749153FFFD0F5358FD7BAAD78CC38E1C1A5DB5B612ED926C3B6AA059FE0FD6DAEF52CFF00034AD2CCC838D8CEB5ADDEF10D632625CE218C13FD672E4733A837ADE4B05618049A1D733712DADEEFB3FAB6544D567EB177EAD57F84A71BED1955FF003AA9F3998463EDC655927C2057A7D339F07F39F2E2E2F5704BFF000B5D0166FA042C6DA2E347527567129B9C2EB2A711516367D7FB36DDBF61AB1BF41EADADFD63232BF41EA27CDBBA0DC231FAF36824B8BAD354D92F3EED86B6D35D4EFF00497575FDA6EFF0D7A1F56E8176506E3D1D4706AC7606B4B3D4D9F43F9BA7D3F7EDA68FCCFF0084FD358B2FFE655DFF0096781FF6F7FB10C58798C7131184FACF156BE81FA38C4FFA91FE5EDBAFC8E0E43863973F3631E5DE30118CF87FBE32432438D47A17D582493F581A49E4FA2EFF00C925FB07EABFFF003C0CFF00B65DFF00924BFE655DFF0096781FF6F7FB13FF00CCABBFF2D303FEDEFF00623EC65FFC4C7FE73AFF007DE5FF00F32B2FF1317FEA95BF60FD57FF00E7819FF6CBBFF2497EC1FAAFFF00CF033FED977FE493FF00CCABBFF2CF03FEDEFF00CC52FF0099577FE5A607FDBDFF0098A1EC65FF00C4C7FE72BEFBCBFF00E6567FE262FF00D52D8C0C3E8BD3AD36E1FD656D64887B7D1716387EEDB5B8ECB1BFD65B98CFFAB17BC0A7A8073A9AB7B71E905AD0FACFA8DB28F51BEAECADDEFAB0BD67E2FF00C0AE6BFE655DFF0096781FF6F7FE629C7D4BBC191D530011C1F5BFD8A48479886830103FC269F378FE1DCCDCA7F10E2C807A6528423FE3FB78A12945DCC2FACB4E57D621D3EC1B3AC56E6D5B40058F6D6E7B729CDB19BB6B7D077A8F63FF00C2D5FA3F51759839D4E6D6EB2A9018F7335EE07D07FF0052D67E918BCCBA9E15F4D6CA718D6CB31196DF6E6B1E7657717FEAD97564D6CC8CA7EDFA776FFF004D65791FE09759F55B372461E1BF2433D6B58DC7CB63640A9D43ACC4FED5B664FF0063D34889619D9D219677938CF0FB539471E3C51C71FF00593FF9EF3C46E2C131D2E3F2CBC47F55EA7BA4924AC2C7FFD1EFFEB0B727EC1EA51C55B9CE88DD3B1ECA5CD0E2DDDB6E7B1723D67AAE56274DC9CCDC05B8FB68ADF5B1CC6035EEC7C5D9EA6EDEE7E45965FEC7D9FA3C55B9D672336EEA671F1C877A5601B2C7B995C5755793F99ED73BD6BAAFA6C7FF0037E9AE37EBA64DCCE858983BDCEA464B5CD0E25D118D45AE6B4BE5DB7D5C97BD43F0FC11E6FE2D871C8486332065F27B798F233F7384FE9C638E525C4D40FF002F99C2E99F53BEB0F57C46E6E0628BF1DEE7343CD8C6925A76BFDB63DAEFA487FF00353AE7ED71D14E26DEA05A6C6D45CC00B00DDBDB6EEF4FF37F79775F5559D71FFE2F6B6F417B6BEA1F687EC73B6C6DF53F49FCE8733E8ABF9192CB3FC62F4AC73AE4E3E15BF687010373DAE780D5D7CFE2BCC473731003118E2F7F840E2F761F771E89E51C5F24FE561E83E8F9960FD5BEABD432B2B13131C597E0C9C966E6376ED26B77B9EE6B5FEE6FE62933EABF587F473D6D98C0F4E6B4BCDDBD930D77A6E3E9EEF53E9FF25765F523FF0014FF0059FE177FE7DB15DE8605DFE2D06244BAFC4CCD83CD8EB1E1499FE279F1CC8023C227CBC4D897C9CC629E5CBFA5FD4F4A80047DBF83C05BF55FAD53D299D62DC60DC0B030B2DDEC922C3B2BFD1EEF53DCE3FBAAE5DFE2FF00EB5D34BEF7F4F9631A5CED9656E74013ED635FB9CBB6FACC5B5FD41186041C5AF058EF89F45CB4FA87D63CBC1FAE1D33A300C761E7512F91EF164D9B1ED7FF00D6FE8284FC5B9C9444B1C319F56735212FE67978E3CBFBFF00370644D0BFB3F17C5B6B4F648B59DC2EE8FD4FE9D97D73AF65F52C9FB0748C0C820B9900EEB22DDB2E0FDAC67A8DFCC403FE2FEB6FD656F4C76538F4C7E33B35B94D00BCD2DF696FEEFA9BDDF4FF007168C7E29CB75910443DD9692AF923938232FD2C918CFE545780703EAE5951CE6E1645DE8606696B7289D1A457FA5AF79FA4DF7B7F35757F54AFC41D5332AC3B5F5D99ADAEFA31EC0F2C9A9D6B3ED0FB6EDEFB7653E8647A75DFE95967E8BD45CFF5FE95D13A6BF0333A1E7FDB31727DFB5E5A6DACB4B7F9CAB6B7DAFF00F86A96FD791907EB4613F331ECAA9C936D588C7DD2D632CA9DB4DDB6DDFF00A7F43D5F6FE82EFE6EAFA0B99FF8CF1C79230E6B1FA7DDC73D72C3F9BCBCA1E2865C9097E9625D8B7DB7D3D3FF007CFA57AEFF00B07AF237FA5BF74693B776EDBFBA92A3B6BFD8F3EA1F4776FF0057719DBBBE96EFF47BBFEB5E97FC0A4B03EF83F7327F31F79F93F47F73FDBFFAB64E1F2DE9FFD2EB3EB3F4DC3B2E0E7DA0D96B9EF1416EE3B9D4598DB9B60FE6B7358CFA7FE12AFD1AE4FEBDE383D030B2DA4BDEDC93EBFE8DD501EA52C652D6D76173F67A78AD66FDEBB1FAC4CAD9962FB9AF752C6D3658DAC96B8863AFAFDAE059F47D7AF7FBBFAEB1ACE9CEEB1D073BA552C21F56331D452E8DECB28BB25B5D6E82EFA55D7E9283E17CC4307C671E422023EE7B32D7D718CF1FBD9737F767EE7ABFB8BE42F1FE287EACE2758CDFF1775D1D16FF00B3673B21E596EF2C868B3F49EF6877E6AD5EA36D789F5ABEAC8CA7B5F9AEA6FA2EB069B89AD8D6BBFB77EFD8BCC7A7FD6DFAC7D2B186160E63B1F1D8E2E15EC6182E32FF00E718E7FD255337AC752CFCC19D9992FB72DBB765C4C39BB4EE66CD9B5ACDAEFDD5D9CBE119F267CB394F18C590E794383F9EFE930F6C719E1F920D7E30001F9F83EA1D2BEAFE57D5ECEFAC7D6731ECFB25ECB6CA08324B497E438BDBF99B7F9B55FEAADCDABA1FD57ADE2599176550F07821EDC831FE73170DD47EB97D62EA98470B3B34D98E637B0358C2E8D47A8EADAD73D56A7EB0F57AA8C4C7AB28B6AE9F61B711BB5BEC79DD2ED5BEFF00A6EFA687FA2B9A9E397BD381C93946CC78B83DBC5CBE4E5F1FE8FCFF00AC4D8E8F7DF5A3205FD13EB1EDFA34F50C6A5A3C056DC5647F9CB73A87D5BCACEFADDD33ACEF6371306887024EF73E6CD8D6B63E8FE93E96E5E4B675DEAD6E3E4E359925D4E6DDF69C9610DF7DB2D77A93B7737E837E82BB7FD77FAD57D2EA2CEA567A6F1B5C1AD63490748DEC635E992F84F3518C238A78E35EE46465C47F579B161C32AF4FCDFAA9A7A9B7BAC4CDA33BA77D65B28C16F580CEA25DF639FE71A0555B5EDF6BF76DF49CF67F51577E77D68FF9CB81F67E8F5635D8785603867218E0FC67398DF6B9ADFD1BABB18CD8CD8B80E91D77AA744B9F774CBFD0758DDAF101CD701F47731E1CDF6A90FACBD6C756FDB3F6B77ED0236FADEDFA31B7D3F4F6FA7E9FF236293FD11904F2708C73818118FDC3978B8A58A387865084A38E31FEBFCE8BE96F5BF5DF1F07A8E0F47EB1461FECECCCFBCD56D2F68ADE44FD2BB46FD0737F9C77F83B142AB69FF9C58B6D597F6EAADBEC393997D61C1D6328B7D47E3B5ADFE6A965D5B2AF52BD9FCD595FB3F46B3FA4F53EB1F583AD37A8F52DDD4074BA9D73696C54D1D9BAD61ADAD9BFF4B6BFF72A5A988DC877D6165F75539B8F558DCCA2A2181EDC83BB06AC67B4BFD6C4AF1A8F56CBFD4FE6EEF46CFF0046B03E3A65870C39794BD5CBE3CB33C078FDAF7BD58F1C3266E1FE6E1C1FCE2E80B90FDA1EBFD7A3F606F93FD238DCEDFBBD4DFB3D49FE7FD3FE57F3FF00A04958F49FFF0037376C77ABB3D7F4F6B6774FADB3D3DDB3D3DBFA3DBBFF009A49637B73ED2FF73F07F3BFA7FF007FFF00952C9A7E3D9FFFD3F47EAD4E23F0ACB32719994DA9A4863C0220FB5FA90EDACDBFCE2E5707333B0B2AEBC36D6B37FE986C68AEDB68DD5E4D4D7967A96D97E255F6BA2CF53E9FE8976C40702D70904411E4572BD43A4750A6CF55BEA1C7C626C2F0E96CB4345396CC7ACEFBAFAAB632BBE87B7D3B2AF57D3FD2AA3CE472094726312263198FD58F571FA671E3FDEC33F6FF0059FE02F811B16FDFD03EAEBC8C8FD97896B6FF007FAA6B69DC5DEFDC7DBF9F285FB07EAE7FE54627FDB4DFFC8AB1F563231F23A3B319B68BACC5269C81330F1EFF006FFC0ED7FEAFFF0004AFD9456CD4565C0770568C799CC6208C930081FA525840B723F60FD5CFFCA8C4FF00B69BFF00914BF60FD5BFFCA8C4FF00B69BFF00915A3BF1FF00D19FF392DF8FFE8CFF009C8FDE33FF009D9FF8D2450ECE77EC1FAB7FF95189FF006D37FF002297EC1FAB7FF95189FF006D37FF0022B477E3FF00A33FE725BF1FFD19FF00392FBC67FF003B3FF1A4AA1D9CEFD83F56FF00F2A313FEDA6FFE4531E85F56C024F48C48024C54D3C7F656A33D179DADA9C4FF0059596515567781040EE6612FBC67FF003B3FF1A4AA1D9E16EA3A1753CC7F48E9CF6E0E21A9F7752FB1B6B6D4CF49BBA87E45AE6BBD7F4DF66D7B2BFD1A9FD5EA73F236F51B182BBFABBD85F53DA18D34D63D1C76D553672198ECC3AFED0F6BEDAFDF62BD9F4F47FACDD62BE9F801965383B9DD572E83B4165BA7ECBDF57B6EFB63ABDF95FE8ABA7FD2BD74B8D818B8CF2FA5A43C80DDCE739C43470C6FA85DB58AA7318E798C788C6513212CA720F72728E3F5638C78BFE9A63E9B3D4F6D1B1A71DBC124BBA4A653FFD4F534920AAF54C0FDA3D3EFC1F5EDC5190DD86EA086D8D07E97A6F21DB777D0414F35D5307A4B7EB75590FC8355FD56B14557E3DBB6EA72690E757F44FBA9CAC7DECF4EFAEDA3D6C7FF00854DF58F3FEB5747E9C315B6D59CECF7B70F173C7EAF9155B71D9559650D6D945FB1BEEF568F43FE295BC3E83D47A1540F4FA3033C543DACF41B87791FC9CAABD5A6CB3FE329A77FFA4543AF9CAEBD762D9838EFB5DD2CDBF6EE94F78C7CC63EFACE3D59343AD1663D9E8B1F6BF1DFBBD0B9FF00CDDA8A9AFD2FAEE7BEB63717A8E37572F360AB1FA88FB16538551BDD564D1EAE3E4336B9B6337D1FCDFE7AD4FDB9914003A8746EA18CE8973A9ADB9957F66DC37BACFF00C0570B4E1E08C5B313A7E6FA7F6AC718F4B73DBF6520FAEEB7240AAC67ECDCA66EF52BFD0657FE7C5730BFE73749798C7CC0C36E35957A65CE633131F78CCADFE9FEAFFA6763E3EFDBFA4B31BF9A494F5C3EB3F47276B599E5C4C068C0C999FF00B654323AF6686838BD26CADAE3B7D7EA76B30EBEFEE6D00DF9B67D1FF40B132327EB6657D5FB436CBBED8FCBADB57A26C938F6E2B87BF46BB7EE77AB6FE67DA966DDF56FADF5116657506FECBACE45990CCBC9B5B5EDF52B7B1FEA57696D8C65791562D8C67E7D7EBA4A6DE57D60EB391D471ABA3A887DCF6D97E2558CDFB3E31BF19D67ABD3EEA2E6BF3327D5FB3BE8DF6DF4FF0048C6B2AC75D2F4DC07FD63E9B4754EB598ECEC4CAADB757D371DA69C76C8DDE9DAD6BBED19AF63BD9FA7B7D2FF00805CC30747C5B19774DA6CEB99B9D95E9D59170757D36BC8B5FEAD7B2FB19BADF4FD1A767A1EA7F47FF0562E8FA1B7A8F4EA1FD07A7DB5E767B2D7DD9D96E69662E23AF3EBBB1EBA9877DF66E7EFAB15AFFF008FB28FD1A4A61F553A8F46E9B5DE3319FB233BA8643AFB316FA9D8EC637F9AC5C7AECB195E33FD3C7AEBFE69FF00CEAEBC10448D41E0AC63F55B072983F6C5B77567CEE70C87914CFF0023069F4F11ADFEB54FFEBAD7A69AA8A994D2C15D55B436B634435AD1A35AD68FCD6A0A65DD24C9229A7FFFD5F53092F95D2414FD50B1BEB3F4DCBC8C43D43A4FB3AD60B5CFC378FCF1FE170EDD5BBE9C86FE6BBFC2FA76AF9C12494FD2FD23A5D38DD070FA6DF536C6558F5D76D7600E05C1A3D5DED74B5DB9FB9543F52BEAD36D75B8F8870EC772EC4B6DC7FF00A18B6D55FF00D15F39A496AA7E8D1F547A77E7657507B7BB5D9D9307FF000652C7FA9DF56B1EF190305975E3516E497643C1F10FCB7DDB57CE0923AA9FA4BEB4749BBAAF45BB1711C2BCC6165D876690CBA9736EA5DFE7315BE95D369E97835E1D24BF64BACB5DABACB1C77DD916BBF3ACBAC3BDCBE6249053F54252BE5749253F53A4BE584914BFFFD9FFED1B5850686F746F73686F7020332E30003842494D04040000000000071C020000022250003842494D04250000000000101BA56775C091AB14DF09E000960681353842494D042F00000000004A44000100580200005802000000000000000000000B190000C0120000BAFFFFFF69FFFFFF8219000055130000000128050000FC03000001000F2701006C6C756E000000000000000000003842494D03ED000000000010004800000001000100480000000100013842494D042600000000000E000000000000000000003F8000003842494D040D000000000004000000783842494D04190000000000040000001E3842494D03F3000000000009000000000000000001003842494D040A00000000000100003842494D271000000000000A000100000000000000023842494D03F5000000000048002F66660001006C66660006000000000001002F6666000100A1999A0006000000000001003200000001005A00000006000000000001003500000001002D000000060000000000013842494D03F80000000000700000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF03E800000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF03E800000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF03E800000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF03E800003842494D040000000000000200003842494D040200000000000200003842494D043000000000000101003842494D042D0000000000060001000000063842494D0408000000000010000000010000024000000240000000003842494D041E000000000004000000003842494D041A00000000034500000006000000000000000000000068000000640000000800420055004D004400450053002000310000000100000000000000000000000000000000000000010000000000000000000000640000006800000000000000000000000000000000010000000000000000000000000000000000000010000000010000000000006E756C6C0000000200000006626F756E64734F626A6300000001000000000000526374310000000400000000546F70206C6F6E6700000000000000004C6566746C6F6E67000000000000000042746F6D6C6F6E670000006800000000526768746C6F6E670000006400000006736C69636573566C4C73000000014F626A6300000001000000000005736C6963650000001200000007736C69636549446C6F6E67000000000000000767726F757049446C6F6E6700000000000000066F726967696E656E756D0000000C45536C6963654F726967696E0000000D6175746F47656E6572617465640000000054797065656E756D0000000A45536C6963655479706500000000496D672000000006626F756E64734F626A6300000001000000000000526374310000000400000000546F70206C6F6E6700000000000000004C6566746C6F6E67000000000000000042746F6D6C6F6E670000006800000000526768746C6F6E67000000640000000375726C54455854000000010000000000006E756C6C54455854000000010000000000004D7367655445585400000001000000000006616C74546167544558540000000100000000000E63656C6C54657874497348544D4C626F6F6C010000000863656C6C546578745445585400000001000000000009686F727A416C69676E656E756D0000000F45536C696365486F727A416C69676E0000000764656661756C740000000976657274416C69676E656E756D0000000F45536C69636556657274416C69676E0000000764656661756C740000000B6267436F6C6F7254797065656E756D0000001145536C6963654247436F6C6F7254797065000000004E6F6E6500000009746F704F75747365746C6F6E67000000000000000A6C6566744F75747365746C6F6E67000000000000000C626F74746F6D4F75747365746C6F6E67000000000000000B72696768744F75747365746C6F6E6700000000003842494D042800000000000C000000013FF00000000000003842494D0414000000000004000000063842494D040C0000000014FD0000000100000064000000680000012C000079E0000014E100180001FFD8FFE000104A46494600010200004800480000FFED000C41646F62655F434D0001FFEE000E41646F626500648000000001FFDB0084000C08080809080C09090C110B0A0B11150F0C0C0F1518131315131318110C0C0C0C0C0C110C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C010D0B0B0D0E0D100E0E10140E0E0E14140E0E0E0E14110C0C0C0C0C11110C0C0C0C0C0C110C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0CFFC00011080068006403012200021101031101FFDD00040007FFC4013F0000010501010101010100000000000000030001020405060708090A0B0100010501010101010100000000000000010002030405060708090A0B1000010401030204020507060805030C33010002110304211231054151611322718132061491A1B14223241552C16233347282D14307259253F0E1F163733516A2B283264493546445C2A3743617D255E265F2B384C3D375E3F3462794A485B495C4D4E4F4A5B5C5D5E5F55666768696A6B6C6D6E6F637475767778797A7B7C7D7E7F711000202010204040304050607070605350100021103213112044151617122130532819114A1B14223C152D1F0332462E1728292435315637334F1250616A2B283072635C2D2449354A317644555367465E2F2B384C3D375E3F34694A485B495C4D4E4F4A5B5C5D5E5F55666768696A6B6C6D6E6F62737475767778797A7B7C7FFDA000C03010002110311003F00F5384924905292543ABE7DD8748F46B2E73C3B6B9B0497012DAAA6BBDAFBECFF0007BFFF0005FE656059936D61F6577D573EE66F7869700D69E3D6C9F52A6DAC7FFDD9751FF75FF47FAB28B267C78E5084AF8B25F008C673F97E6F90492013F475ACEBF2F7329A9DED6EE2435F6B8033B1CEAE96FA7EEFA7E9FDA3D5FF008351C9EBD58C30E0F6D6E700E36B5F59968F74E354E73EDB2CB9BFCCD7E87FC62E7EEEAA30B6FDA328546D01CF00061803631AD60A5F91E9B58DF635B8387FF1EB2F27EB1F4E7584B596D8266400D9FE57EB1665EEFF00B618A119F309CF8C62842FF5638A5EF7FD5211E38FFCE6DE1F877339C038B0CE60FE9570C3FC19CF85EADDD43AB630AEECA73ABADC44CD95BDA091BDB5DFFAA636C6591E87ABEBFE8EC7ABB6F5EAC960C601EE713ED96D8E718FA2C6E3DAFDAD6FD2B2EB3D8CFF00AE2E0DBF58FA6F0EC4B479B5D448FF00D9562BF85F587A5904332ECC679FA1EAB5ED8FFAF31F9B4EDFEB6226472E718C8F730E5CBAF0CA427821FD5E28FEB3899727C239D80B972F3AEBC1C397FE83DA74EEAF5E758EA4D6EAAEAE7734CC7B76177D315D9F46EADDEFAD5F5C60B725A59961CCB05EE1BAC046C7100318EAF2A87B595DDB1BB7F9EC1B2CFF00B876AB58F9D7E23996D57B6CF51FB6DC7DA5858409B3D465916ECA99FA4BAEC8FD67FC2FA96FF47528E6787DA8E689864C8443D2253C5EE7F57247F465FA3C6D030209F0EFBBD4C250818B98CC86B411E9DE58DB1F438FBDAD7486B9C3F75DB11D595AB77493F749153FFFD0F5358FD7BAAD78CC38E1C1A5DB5B612ED926C3B6AA059FE0FD6DAEF52CFF00034AD2CCC838D8CEB5ADDEF10D632625CE218C13FD672E4733A837ADE4B05618049A1D733712DADEEFB3FAB6544D567EB177EAD57F84A71BED1955FF003AA9F3998463EDC655927C2057A7D339F07F39F2E2E2F5704BFF000B5D0166FA042C6DA2E347527567129B9C2EB2A711516367D7FB36DDBF61AB1BF41EADADFD63232BF41EA27CDBBA0DC231FAF36824B8BAD354D92F3EED86B6D35D4EFF00497575FDA6EFF0D7A1F56E8176506E3D1D4706AC7606B4B3D4D9F43F9BA7D3F7EDA68FCCFF0084FD358B2FFE655DFF0096781FF6F7FB10C58798C7131184FACF156BE81FA38C4FFA91FE5EDBAFC8E0E43863973F3631E5DE30118CF87FBE32432438D47A17D582493F581A49E4FA2EFF00C925FB07EABFFF003C0CFF00B65DFF00924BFE655DFF0096781FF6F7FB13FF00CCABBFF2D303FEDEFF00623EC65FFC4C7FE73AFF007DE5FF00F32B2FF1317FEA95BF60FD57FF00E7819FF6CBBFF2497EC1FAAFFF00CF033FED977FE493FF00CCABBFF2CF03FEDEFF00CC52FF0099577FE5A607FDBDFF0098A1EC65FF00C4C7FE72BEFBCBFF00E6567FE262FF00D52D8C0C3E8BD3AD36E1FD656D64887B7D1716387EEDB5B8ECB1BFD65B98CFFAB17BC0A7A8073A9AB7B71E905AD0FACFA8DB28F51BEAECADDEFAB0BD67E2FF00C0AE6BFE655DFF0096781FF6F7FE629C7D4BBC191D530011C1F5BFD8A48479886830103FC269F378FE1DCCDCA7F10E2C807A6528423FE3FB78A12945DCC2FACB4E57D621D3EC1B3AC56E6D5B40058F6D6E7B729CDB19BB6B7D077A8F63FF00C2D5FA3F51759839D4E6D6EB2A9018F7335EE07D07FF0052D67E918BCCBA9E15F4D6CA718D6CB31196DF6E6B1E7657717FEAD97564D6CC8CA7EDFA776FFF004D65791FE09759F55B372461E1BF2433D6B58DC7CB63640A9D43ACC4FED5B664FF0063D34889619D9D219677938CF0FB539471E3C51C71FF00593FF9EF3C46E2C131D2E3F2CBC47F55EA7BA4924AC2C7FFD1EFFEB0B727EC1EA51C55B9CE88DD3B1ECA5CD0E2DDDB6E7B1723D67AAE56274DC9CCDC05B8FB68ADF5B1CC6035EEC7C5D9EA6EDEE7E45965FEC7D9FA3C55B9D672336EEA671F1C877A5601B2C7B995C5755793F99ED73BD6BAAFA6C7FF0037E9AE37EBA64DCCE858983BDCEA464B5CD0E25D118D45AE6B4BE5DB7D5C97BD43F0FC11E6FE2D871C8486332065F27B798F233F7384FE9C638E525C4D40FF002F99C2E99F53BEB0F57C46E6E0628BF1DEE7343CD8C6925A76BFDB63DAEFA487FF00353AE7ED71D14E26DEA05A6C6D45CC00B00DDBDB6EEF4FF37F79775F5559D71FFE2F6B6F417B6BEA1F687EC73B6C6DF53F49FCE8733E8ABF9192CB3FC62F4AC73AE4E3E15BF687010373DAE780D5D7CFE2BCC473731003118E2F7F840E2F761F771E89E51C5F24FE561E83E8F9960FD5BEABD432B2B13131C597E0C9C966E6376ED26B77B9EE6B5FEE6FE62933EABF587F473D6D98C0F4E6B4BCDDBD930D77A6E3E9EEF53E9FF25765F523FF0014FF0059FE177FE7DB15DE8605DFE2D06244BAFC4CCD83CD8EB1E1499FE279F1CC8023C227CBC4D897C9CC629E5CBFA5FD4F4A80047DBF83C05BF55FAD53D299D62DC60DC0B030B2DDEC922C3B2BFD1EEF53DCE3FBAAE5DFE2FF00EB5D34BEF7F4F9631A5CED9656E74013ED635FB9CBB6FACC5B5FD41186041C5AF058EF89F45CB4FA87D63CBC1FAE1D33A300C761E7512F91EF164D9B1ED7FF00D6FE8284FC5B9C9444B1C319F56735212FE67978E3CBFBFF00370644D0BFB3F17C5B6B4F648B59DC2EE8FD4FE9D97D73AF65F52C9FB0748C0C820B9900EEB22DDB2E0FDAC67A8DFCC403FE2FEB6FD656F4C76538F4C7E33B35B94D00BCD2DF696FEEFA9BDDF4FF007168C7E29CB75910443DD9692AF923938232FD2C918CFE545780703EAE5951CE6E1645DE8606696B7289D1A457FA5AF79FA4DF7B7F35757F54AFC41D5332AC3B5F5D99ADAEFA31EC0F2C9A9D6B3ED0FB6EDEFB7653E8647A75DFE95967E8BD45CFF5FE95D13A6BF0333A1E7FDB31727DFB5E5A6DACB4B7F9CAB6B7DAFF00F86A96FD791907EB4613F331ECAA9C936D588C7DD2D632CA9DB4DDB6DDFF00A7F43D5F6FE82EFE6EAFA0B99FF8CF1C79230E6B1FA7DDC73D72C3F9BCBCA1E2865C9097E9625D8B7DB7D3D3FF007CFA57AEFF00B07AF237FA5BF74693B776EDBFBA92A3B6BFD8F3EA1F4776FF0057719DBBBE96EFF47BBFEB5E97FC0A4B03EF83F7327F31F79F93F47F73FDBFFAB64E1F2DE9FFD2EB3EB3F4DC3B2E0E7DA0D96B9EF1416EE3B9D4598DB9B60FE6B7358CFA7FE12AFD1AE4FEBDE383D030B2DA4BDEDC93EBFE8DD501EA52C652D6D76173F67A78AD66FDEBB1FAC4CAD9962FB9AF752C6D3658DAC96B8863AFAFDAE059F47D7AF7FBBFAEB1ACE9CEEB1D073BA552C21F56331D452E8DECB28BB25B5D6E82EFA55D7E9283E17CC4307C671E422023EE7B32D7D718CF1FBD9737F767EE7ABFB8BE42F1FE287EACE2758CDFF1775D1D16FF00B3673B21E596EF2C868B3F49EF6877E6AD5EA36D789F5ABEAC8CA7B5F9AEA6FA2EB069B89AD8D6BBFB77EFD8BCC7A7FD6DFAC7D2B186160E63B1F1D8E2E15EC6182E32FF00E718E7FD255337AC752CFCC19D9992FB72DBB765C4C39BB4EE66CD9B5ACDAEFDD5D9CBE119F267CB394F18C590E794383F9EFE930F6C719E1F920D7E30001F9F83EA1D2BEAFE57D5ECEFAC7D6731ECFB25ECB6CA08324B497E438BDBF99B7F9B55FEAADCDABA1FD57ADE2599176550F07821EDC831FE73170DD47EB97D62EA98470B3B34D98E637B0358C2E8D47A8EADAD73D56A7EB0F57AA8C4C7AB28B6AE9F61B711BB5BEC79DD2ED5BEFF00A6EFA687FA2B9A9E397BD381C93946CC78B83DBC5CBE4E5F1FE8FCFF00AC4D8E8F7DF5A3205FD13EB1EDFA34F50C6A5A3C056DC5647F9CB73A87D5BCACEFADDD33ACEF6371306887024EF73E6CD8D6B63E8FE93E96E5E4B675DEAD6E3E4E359925D4E6DDF69C9610DF7DB2D77A93B7737E837E82BB7FD77FAD57D2EA2CEA567A6F1B5C1AD63490748DEC635E992F84F3518C238A78E35EE46465C47F579B161C32AF4FCDFAA9A7A9B7BAC4CDA33BA77D65B28C16F580CEA25DF639FE71A0555B5EDF6BF76DF49CF67F51577E77D68FF9CB81F67E8F5635D8785603867218E0FC67398DF6B9ADFD1BABB18CD8CD8B80E91D77AA744B9F774CBFD0758DDAF101CD701F47731E1CDF6A90FACBD6C756FDB3F6B77ED0236FADEDFA31B7D3F4F6FA7E9FF236293FD11904F2708C73818118FDC3978B8A58A387865084A38E31FEBFCE8BE96F5BF5DF1F07A8E0F47EB1461FECECCCFBCD56D2F68ADE44FD2BB46FD0737F9C77F83B142AB69FF9C58B6D597F6EAADBEC393997D61C1D6328B7D47E3B5ADFE6A965D5B2AF52BD9FCD595FB3F46B3FA4F53EB1F583AD37A8F52DDD4074BA9D73696C54D1D9BAD61ADAD9BFF4B6BFF72A5A988DC877D6165F75539B8F558DCCA2A2181EDC83BB06AC67B4BFD6C4AF1A8F56CBFD4FE6EEF46CFF0046B03E3A65870C39794BD5CBE3CB33C078FDAF7BD58F1C3266E1FE6E1C1FCE2E80B90FDA1EBFD7A3F606F93FD238DCEDFBBD4DFB3D49FE7FD3FE57F3FF00A04958F49FFF0037376C77ABB3D7F4F6B6774FADB3D3DDB3D3DBFA3DBBFF009A49637B73ED2FF73F07F3BFA7FF007FFF00952C9A7E3D9FFFD3F47EAD4E23F0ACB32719994DA9A4863C0220FB5FA90EDACDBFCE2E5707333B0B2AEBC36D6B37FE986C68AEDB68DD5E4D4D7967A96D97E255F6BA2CF53E9FE8976C40702D70904411E4572BD43A4750A6CF55BEA1C7C626C2F0E96CB4345396CC7ACEFBAFAAB632BBE87B7D3B2AF57D3FD2AA3CE472094726312263198FD58F571FA671E3FDEC33F6FF0059FE02F811B16FDFD03EAEBC8C8FD97896B6FF007FAA6B69DC5DEFDC7DBF9F285FB07EAE7FE54627FDB4DFFC8AB1F563231F23A3B319B68BACC5269C81330F1EFF006FFC0ED7FEAFFF0004AFD9456CD4565C0770568C799CC6208C930081FA525840B723F60FD5CFFCA8C4FF00B69BFF00914BF60FD5BFFCA8C4FF00B69BFF00915A3BF1FF00D19FF392DF8FFE8CFF009C8FDE33FF009D9FF8D2450ECE77EC1FAB7FF95189FF006D37FF002297EC1FAB7FF95189FF006D37FF0022B477E3FF00A33FE725BF1FFD19FF00392FBC67FF003B3FF1A4AA1D9CEFD83F56FF00F2A313FEDA6FFE4531E85F56C024F48C48024C54D3C7F656A33D179DADA9C4FF0059596515567781040EE6612FBC67FF003B3FF1A4AA1D9E16EA3A1753CC7F48E9CF6E0E21A9F7752FB1B6B6D4CF49BBA87E45AE6BBD7F4DF66D7B2BFD1A9FD5EA73F236F51B182BBFABBD85F53DA18D34D63D1C76D553672198ECC3AFED0F6BEDAFDF62BD9F4F47FACDD62BE9F801965383B9DD572E83B4165BA7ECBDF57B6EFB63ABDF95FE8ABA7FD2BD74B8D818B8CF2FA5A43C80DDCE739C43470C6FA85DB58AA7318E798C788C6513212CA720F72728E3F5638C78BFE9A63E9B3D4F6D1B1A71DBC124BBA4A653FFD4F534920AAF54C0FDA3D3EFC1F5EDC5190DD86EA086D8D07E97A6F21DB777D0414F35D5307A4B7EB75590FC8355FD56B14557E3DBB6EA72690E757F44FBA9CAC7DECF4EFAEDA3D6C7FF00854DF58F3FEB5747E9C315B6D59CECF7B70F173C7EAF9155B71D9559650D6D945FB1BEEF568F43FE295BC3E83D47A1540F4FA3033C543DACF41B87791FC9CAABD5A6CB3FE329A77FFA4543AF9CAEBD762D9838EFB5DD2CDBF6EE94F78C7CC63EFACE3D59343AD1663D9E8B1F6BF1DFBBD0B9FF00CDDA8A9AFD2FAEE7BEB63717A8E37572F360AB1FA88FB16538551BDD564D1EAE3E4336B9B6337D1FCDFE7AD4FDB9914003A8746EA18CE8973A9ADB9957F66DC37BACFF00C0570B4E1E08C5B313A7E6FA7F6AC718F4B73DBF6520FAEEB7240AAC67ECDCA66EF52BFD0657FE7C5730BFE73749798C7CC0C36E35957A65CE633131F78CCADFE9FEAFFA6763E3EFDBFA4B31BF9A494F5C3EB3F47276B599E5C4C068C0C999FF00B654323AF6686838BD26CADAE3B7D7EA76B30EBEFEE6D00DF9B67D1FF40B132327EB6657D5FB436CBBED8FCBADB57A26C938F6E2B87BF46BB7EE77AB6FE67DA966DDF56FADF5116657506FECBACE45990CCBC9B5B5EDF52B7B1FEA57696D8C65791562D8C67E7D7EBA4A6DE57D60EB391D471ABA3A887DCF6D97E2558CDFB3E31BF19D67ABD3EEA2E6BF3327D5FB3BE8DF6DF4FF0048C6B2AC75D2F4DC07FD63E9B4754EB598ECEC4CAADB757D371DA69C76C8DDE9DAD6BBED19AF63BD9FA7B7D2FF00805CC30747C5B19774DA6CEB99B9D95E9D59170757D36BC8B5FEAD7B2FB19BADF4FD1A767A1EA7F47FF0562E8FA1B7A8F4EA1FD07A7DB5E767B2D7DD9D96E69662E23AF3EBBB1EBA9877DF66E7EFAB15AFFF008FB28FD1A4A61F553A8F46E9B5DE3319FB233BA8643AFB316FA9D8EC637F9AC5C7AECB195E33FD3C7AEBFE69FF00CEAEBC10448D41E0AC63F55B072983F6C5B77567CEE70C87914CFF0023069F4F11ADFEB54FFEBAD7A69AA8A994D2C15D55B436B634435AD1A35AD68FCD6A0A65DD24C9229A7FFFD5F53092F95D2414FD50B1BEB3F4DCBC8C43D43A4FB3AD60B5CFC378FCF1FE170EDD5BBE9C86FE6BBFC2FA76AF9C12494FD2FD23A5D38DD070FA6DF536C6558F5D76D7600E05C1A3D5DED74B5DB9FB9543F52BEAD36D75B8F8870EC772EC4B6DC7FF00A18B6D55FF00D15F39A496AA7E8D1F547A77E7657507B7BB5D9D9307FF000652C7FA9DF56B1EF190305975E3516E497643C1F10FCB7DDB57CE0923AA9FA4BEB4749BBAAF45BB1711C2BCC6165D876690CBA9736EA5DFE7315BE95D369E97835E1D24BF64BACB5DABACB1C77DD916BBF3ACBAC3BDCBE6249053F54252BE5749253F53A4BE584914BFFFD9003842494D042100000000005500000001010000000F00410064006F00620065002000500068006F0074006F00730068006F00700000001300410064006F00620065002000500068006F0074006F00730068006F0070002000430053003300000001003842494D04060000000000070001010100010100FFE10FCE687474703A2F2F6E732E61646F62652E636F6D2F7861702F312E302F003C3F787061636B657420626567696E3D22EFBBBF222069643D2257354D304D7043656869487A7265537A4E54637A6B633964223F3E203C783A786D706D65746120786D6C6E733A783D2261646F62653A6E733A6D6574612F2220783A786D70746B3D2241646F626520584D5020436F726520342E312D633033362034362E3237363732302C204D6F6E2046656220313920323030372032323A34303A30382020202020202020223E203C7264663A52444620786D6C6E733A7264663D22687474703A2F2F7777772E77332E6F72672F313939392F30322F32322D7264662D73796E7461782D6E7323223E203C7264663A4465736372697074696F6E207264663A61626F75743D222220786D6C6E733A64633D22687474703A2F2F7075726C2E6F72672F64632F656C656D656E74732F312E312F2220786D6C6E733A7861703D22687474703A2F2F6E732E61646F62652E636F6D2F7861702F312E302F2220786D6C6E733A7861704D4D3D22687474703A2F2F6E732E61646F62652E636F6D2F7861702F312E302F6D6D2F2220786D6C6E733A73745265663D22687474703A2F2F6E732E61646F62652E636F6D2F7861702F312E302F73547970652F5265736F75726365526566232220786D6C6E733A70686F746F73686F703D22687474703A2F2F6E732E61646F62652E636F6D2F70686F746F73686F702F312E302F2220786D6C6E733A746966663D22687474703A2F2F6E732E61646F62652E636F6D2F746966662F312E302F2220786D6C6E733A657869663D22687474703A2F2F6E732E61646F62652E636F6D2F657869662F312E302F222064633A666F726D61743D22696D6167652F6A70656722207861703A43726561746F72546F6F6C3D2241646F62652050686F746F73686F70204353332057696E646F777322207861703A437265617465446174653D22323031322D30312D30315432303A35353A35302B30373A303022207861703A4D6F64696679446174653D22323031322D30312D30315432303A35353A35302B30373A303022207861703A4D65746164617461446174653D22323031322D30312D30315432303A35353A35302B30373A303022207861704D4D3A446F63756D656E7449443D22757569643A434330453733353437463334453131313937463045423131463439383246423922207861704D4D3A496E7374616E636549443D22757569643A3635354537363530383033344531313139374630454231314634393832464239222070686F746F73686F703A436F6C6F724D6F64653D2233222070686F746F73686F703A49434350726F66696C653D22735247422049454336313936362D322E31222070686F746F73686F703A486973746F72793D222220746966663A4F7269656E746174696F6E3D22312220746966663A585265736F6C7574696F6E3D223732303030302F31303030302220746966663A595265736F6C7574696F6E3D223732303030302F31303030302220746966663A5265736F6C7574696F6E556E69743D22322220746966663A4E61746976654469676573743D223235362C3235372C3235382C3235392C3236322C3237342C3237372C3238342C3533302C3533312C3238322C3238332C3239362C3330312C3331382C3331392C3532392C3533322C3330362C3237302C3237312C3237322C3330352C3331352C33333433323B33373034323030383435383730464335313342453734323338314634334636322220657869663A506978656C5844696D656E73696F6E3D223130302220657869663A506978656C5944696D656E73696F6E3D223130342220657869663A436F6C6F7253706163653D22312220657869663A4E61746976654469676573743D2233363836342C34303936302C34303936312C33373132312C33373132322C34303936322C34303936332C33373531302C34303936342C33363836372C33363836382C33333433342C33333433372C33343835302C33343835322C33343835352C33343835362C33373337372C33373337382C33373337392C33373338302C33373338312C33373338322C33373338332C33373338342C33373338352C33373338362C33373339362C34313438332C34313438342C34313438362C34313438372C34313438382C34313439322C34313439332C34313439352C34313732382C34313732392C34313733302C34313938352C34313938362C34313938372C34313938382C34313938392C34313939302C34313939312C34313939322C34313939332C34313939342C34313939352C34313939362C34323031362C302C322C342C352C362C372C382C392C31302C31312C31322C31332C31342C31352C31362C31372C31382C32302C32322C32332C32342C32352C32362C32372C32382C33303B3435454236373539334133423335423638343534324639433733423535364545223E203C7861704D4D3A4465726976656446726F6D2073745265663A696E7374616E636549443D22757569643A4335304537333534374633344531313139374630454231314634393832464239222073745265663A646F63756D656E7449443D22757569643A4334304537333534374633344531313139374630454231314634393832464239222F3E203C2F7264663A4465736372697074696F6E3E203C2F7264663A5244463E203C2F783A786D706D6574613E2020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020203C3F787061636B657420656E643D2277223F3EFFE20C584943435F50524F46494C4500010100000C484C696E6F021000006D6E74725247422058595A2007CE00020009000600310000616373704D5346540000000049454320735247420000000000000000000000010000F6D6000100000000D32D4850202000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001163707274000001500000003364657363000001840000006C77747074000001F000000014626B707400000204000000147258595A00000218000000146758595A0000022C000000146258595A0000024000000014646D6E640000025400000070646D6464000002C400000088767565640000034C0000008676696577000003D4000000246C756D69000003F8000000146D6561730000040C0000002474656368000004300000000C725452430000043C0000080C675452430000043C0000080C625452430000043C0000080C7465787400000000436F70797269676874202863292031393938204865776C6574742D5061636B61726420436F6D70616E790000646573630000000000000012735247422049454336313936362D322E31000000000000000000000012735247422049454336313936362D322E31000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000058595A20000000000000F35100010000000116CC58595A200000000000000000000000000000000058595A200000000000006FA2000038F50000039058595A2000000000000062990000B785000018DA58595A2000000000000024A000000F840000B6CF64657363000000000000001649454320687474703A2F2F7777772E6965632E636800000000000000000000001649454320687474703A2F2F7777772E6965632E63680000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000064657363000000000000002E4945432036313936362D322E312044656661756C742052474220636F6C6F7572207370616365202D207352474200000000000000000000002E4945432036313936362D322E312044656661756C742052474220636F6C6F7572207370616365202D20735247420000000000000000000000000000000000000000000064657363000000000000002C5265666572656E63652056696577696E6720436F6E646974696F6E20696E2049454336313936362D322E3100000000000000000000002C5265666572656E63652056696577696E6720436F6E646974696F6E20696E2049454336313936362D322E31000000000000000000000000000000000000000000000000000076696577000000000013A4FE00145F2E0010CF140003EDCC0004130B00035C9E0000000158595A2000000000004C09560050000000571FE76D6561730000000000000001000000000000000000000000000000000000028F0000000273696720000000004352542063757276000000000000040000000005000A000F00140019001E00230028002D00320037003B00400045004A004F00540059005E00630068006D00720077007C00810086008B00900095009A009F00A400A900AE00B200B700BC00C100C600CB00D000D500DB00E000E500EB00F000F600FB01010107010D01130119011F0125012B01320138013E0145014C0152015901600167016E0175017C0183018B0192019A01A101A901B101B901C101C901D101D901E101E901F201FA0203020C0214021D0226022F02380241024B0254025D02670271027A0284028E029802A202AC02B602C102CB02D502E002EB02F50300030B03160321032D03380343034F035A03660372037E038A039603A203AE03BA03C703D303E003EC03F9040604130420042D043B0448045504630471047E048C049A04A804B604C404D304E104F004FE050D051C052B053A05490558056705770586059605A605B505C505D505E505F6060606160627063706480659066A067B068C069D06AF06C006D106E306F507070719072B073D074F076107740786079907AC07BF07D207E507F8080B081F08320846085A086E0882089608AA08BE08D208E708FB09100925093A094F09640979098F09A409BA09CF09E509FB0A110A270A3D0A540A6A0A810A980AAE0AC50ADC0AF30B0B0B220B390B510B690B800B980BB00BC80BE10BF90C120C2A0C430C5C0C750C8E0CA70CC00CD90CF30D0D0D260D400D5A0D740D8E0DA90DC30DDE0DF80E130E2E0E490E640E7F0E9B0EB60ED20EEE0F090F250F410F5E0F7A0F960FB30FCF0FEC1009102610431061107E109B10B910D710F511131131114F116D118C11AA11C911E81207122612451264128412A312C312E31303132313431363138313A413C513E5140614271449146A148B14AD14CE14F01512153415561578159B15BD15E0160316261649166C168F16B216D616FA171D17411765178917AE17D217F7181B18401865188A18AF18D518FA19201945196B199119B719DD1A041A2A1A511A771A9E1AC51AEC1B141B3B1B631B8A1BB21BDA1C021C2A1C521C7B1CA31CCC1CF51D1E1D471D701D991DC31DEC1E161E401E6A1E941EBE1EE91F131F3E1F691F941FBF1FEA20152041206C209820C420F0211C2148217521A121CE21FB22272255228222AF22DD230A23382366239423C223F0241F244D247C24AB24DA250925382568259725C725F726272657268726B726E827182749277A27AB27DC280D283F287128A228D429062938296B299D29D02A022A352A682A9B2ACF2B022B362B692B9D2BD12C052C392C6E2CA22CD72D0C2D412D762DAB2DE12E162E4C2E822EB72EEE2F242F5A2F912FC72FFE3035306C30A430DB3112314A318231BA31F2322A3263329B32D4330D3346337F33B833F1342B3465349E34D83513354D358735C235FD3637367236AE36E937243760379C37D738143850388C38C839053942397F39BC39F93A363A743AB23AEF3B2D3B6B3BAA3BE83C273C653CA43CE33D223D613DA13DE03E203E603EA03EE03F213F613FA23FE24023406440A640E74129416A41AC41EE4230427242B542F7433A437D43C044034447448A44CE45124555459A45DE4622466746AB46F04735477B47C04805484B489148D7491D496349A949F04A374A7D4AC44B0C4B534B9A4BE24C2A4C724CBA4D024D4A4D934DDC4E254E6E4EB74F004F494F934FDD5027507150BB51065150519B51E65231527C52C75313535F53AA53F65442548F54DB5528557555C2560F565C56A956F75744579257E0582F587D58CB591A596959B85A075A565AA65AF55B455B955BE55C355C865CD65D275D785DC95E1A5E6C5EBD5F0F5F615FB36005605760AA60FC614F61A261F56249629C62F06343639763EB6440649464E9653D659265E7663D669266E8673D679367E9683F689668EC6943699A69F16A486A9F6AF76B4F6BA76BFF6C576CAF6D086D606DB96E126E6B6EC46F1E6F786FD1702B708670E0713A719571F0724B72A67301735D73B87414747074CC7528758575E1763E769B76F8775677B37811786E78CC792A798979E77A467AA57B047B637BC27C217C817CE17D417DA17E017E627EC27F237F847FE5804780A8810A816B81CD8230829282F4835783BA841D848084E3854785AB860E867286D7873B879F8804886988CE8933899989FE8A648ACA8B308B968BFC8C638CCA8D318D988DFF8E668ECE8F368F9E9006906E90D6913F91A89211927A92E3934D93B69420948A94F4955F95C99634969F970A977597E0984C98B89924999099FC9A689AD59B429BAF9C1C9C899CF79D649DD29E409EAE9F1D9F8B9FFAA069A0D8A147A1B6A226A296A306A376A3E6A456A4C7A538A5A9A61AA68BA6FDA76EA7E0A852A8C4A937A9A9AA1CAA8FAB02AB75ABE9AC5CACD0AD44ADB8AE2DAEA1AF16AF8BB000B075B0EAB160B1D6B24BB2C2B338B3AEB425B49CB513B58AB601B679B6F0B768B7E0B859B8D1B94AB9C2BA3BBAB5BB2EBBA7BC21BC9BBD15BD8FBE0ABE84BEFFBF7ABFF5C070C0ECC167C1E3C25FC2DBC358C3D4C451C4CEC54BC5C8C646C6C3C741C7BFC83DC8BCC93AC9B9CA38CAB7CB36CBB6CC35CCB5CD35CDB5CE36CEB6CF37CFB8D039D0BAD13CD1BED23FD2C1D344D3C6D449D4CBD54ED5D1D655D6D8D75CD7E0D864D8E8D96CD9F1DA76DAFBDB80DC05DC8ADD10DD96DE1CDEA2DF29DFAFE036E0BDE144E1CCE253E2DBE363E3EBE473E4FCE584E60DE696E71FE7A9E832E8BCE946E9D0EA5BEAE5EB70EBFBEC86ED11ED9CEE28EEB4EF40EFCCF058F0E5F172F1FFF28CF319F3A7F434F4C2F550F5DEF66DF6FBF78AF819F8A8F938F9C7FA57FAE7FB77FC07FC98FD29FDBAFE4BFEDCFF6DFFFFFFEE002141646F62650064800000000103001003020306000000000000000000000000FFDB0084000C08080809080C09090C110B0A0B11150F0C0C0F1518131315131318110C0C0C0C0C0C110C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C010D0B0B0D0E0D100E0E10140E0E0E14140E0E0E0E14110C0C0C0C0C11110C0C0C0C0C0C110C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0C0CFFC20011080068006403012200021101031101FFC400DC00000202030101000000000000000000000006040501020803070100020301010000000000000000000000000102030405061000010402010206030003000000000000040102030500061115161041121314072030213122361100020102040204070C090501000000000203011204001113052232212333143142D243932435204152627282925363731506105161E1E283A3343671A2B35464A4120001020303060511090000000000000002010300111222321321314223330410416292A240F051618191A1527282B2D263D314343571B1C1738393246405FFDA000C03010102110311000000FA98080814153B6D57EAE9D6D7350E7C2D749E992ADC0D2787BE98E0C8C29EC9471CBC73E756BAE065F5F064448BC5ACD98EF1B3E64D879E6903442AD46F136A95179BD4FF005F4FCCB6729B608131DACE97F161EBC3A2A81AD7EFFCCCBE9441381656A9B8D35CFC6D7E6313D9E7FA847468C9BF5E7C966C1BD4740DAC4DBA57DA7024DE4838D64C5576558B9FE5227F46150588D5716205762D24822EF3997239005C011416B12E0323DA22CC06ED292B425B2AC31868DF4D6E8D8C0DE4E5712EA8A6E7003A5E273981D1BB7380CE9297CC423AA0E5703A9CE581BFFFDA0008010200010500C9278E3724F323DB2CE91A13E9F132646B628488DBEC4B9EC4B8C690CC54742FCAF81A5DB3ED486CD3D9CF1BD6D8C735B68366CED8E46FCC4CAB21905CBAA27927E9453E375494D6F48911F7AAE861F6DF8636447349995BF227CF913E7C89F088DF32FEAFEE7F7F0FFFDA0008010300010500C4455C86B899D24A83588AC545F06272A0C007A7E68F9F347C2E3AE27153C15786792222A709CF1917F9F4E39398FD6889CA679F38C4E5DFCC62A62A273C267099C2637FD7F471FA3FFFDA0008010100010500E3F092FF0097937D1A06EB0B61925BE8D56BADE33A4CE338CF3F0B73E60E190996349AD502C2763AE748DD8EB702D86AD512525AA39D388E14C610DCF3CBEB58C6631B2A4C6CD43322D16B0ABD0757CE83ABE741D5F000E96BA519FAC4EF0B6584AD8813A1363F3308518632C1B764DB504C527654D9D95367654D9D95367654D9D953626973A2D9853C31EAC69281E6C2D27E05CDA94256D669DB0DB89DA979D5C1D6ED6C0A66AF70FA79757BA86AA6FAFF006B861F4B5715ACCD724894ED4A7112D3DF7FC0B920D9ACF742666516AACBC7FD7A412C93EC5D23FE9E8D126FAD36656C7A0D86C6583B82E9F5C5DE2FD7F1B765BFAAA4AD7C6410BB47A63E8FB3D68724DBD8E8B41AC89706FD77632C626D555AF95AF1DAACCD8A8F682127A4B0D6CA3B6E10D80EAE79DB4772EEE383620C52C3DC5EFC1D0362646C2E4AE75C50D7EDBB1D50C6DC591E658EE5B15A050EC36F14125EDB4A3CFBBED53C3517B6949326CB7696D536771B05D08D21DB0FB4FEDCB684478409870454F41AEBD7A0EB99D075CCE83ADE741D6F3A0EB79D075BC5A2D6D126828ACCCD7A13C8CFE62A2392C2A2C219358207229E4823667AC7CF58F9EB1F3D63E33D97AB208A353E1A7D9AE0600519FE7E1680D4B76ED8CFDAA9EBAAEF4F7C7D708811367A75522F8D4695B05C91635A03F63ADD52C69AB6345454F34CB403A8D78743634515FA957D3421828285DCD52F209DB0AD7E6D6EEEC51894E2C946DB1AE8175604A6430C504589E3B3D696409515708D42BA56B4D95351AEC1F4ED6879F68A99AD696AAB61AB0739F0FFDA0008010202063F0080029D4E4E841133BB7AE2141D68D004F56951637EA00D63D2854C465D772D24486C0726A1D6550D0BC2A0E38A816508DAC4E4B83A25A35F0E18949C3A512566C99D1B4BAD556A82FDB8514656DAD52CB61345B43E40F5E1C7CB2F4A3E597A512461513CE89AE4074E6E56B4E1190B6DB42D8FB43E9F032D921236A48A5730DE5DC4F1295D3116C8A3780446945AC7A512AC50F874B06EA5570EEC2A220D287BB8ACD0AE6F0D1BAEE9722CC21360DADA7D64485B1DDC5B77C7BD43919495150314B214AE0B9409693822776037A6ECE2B6795D0D9BBBA2D40EB805A4D45C7361F137347C4FCFF670DB8A80838982596D889B78CEBDE49E25AF221D3236D1A715F20A36DFC90C34AD69B81058C60AE190CD46AA30DADDDCDDDBD1BFAC80168DB1962092954BAB79A6592959BDAA3872946CC14151BC4576AA89A1669200216C47977E037722B5BBB6E9AD0B5E1635A6DB071EA766146D23317CBD1B5D3F5FFB302E3684AA2269AB4B55D931AFC664F0F59E6422A38688A89A451B53E7146D4F9C51B53E7140D4A242A484EAB8988642DDA6C46AF4FA83FFDA0008010302063F008FB2115A64CD174A54879A674C4CB773971D14BBE842F6BB39F867C4902EBFBDA36EE7104113A7CB4701C0AE3EAA5CC6BDCC7D54F98D7B98523FF42A7112C91000F3F0DA02218549A2A8E498DD2EDA727817AEF427723BFE08EF786332466CF92CFAD1C59E51E1844FBFB5192167129C27E291DDEC44978334668CD0ABC6BD8C9D41FFDA0008010101063F00F7040951708D533026D2889CE8225A474F8B9F4FBC6AFD9E20A0C56451052D135CE631C59DB2888DAC6387B15E87DE616EBA225ACA633CD8B318998AC56FF54B6A0199686AEBF56C3C045B441914CF0E62C229CB9406DDA7488F331CCE00FE660932B253979D4339E5C344973C2D9CAE5971AFDDC68AE488E0A921CA664A23315284B84DECF375FF0057B1C1B16F538DC159C0C94408CF835AE75142D03FFD248FFCFD5FAB607BC5D42A5B1047111013944500221093B8D3101E011B1B3FBFC4C8835919E79C440E7F1BD6197757A00C64568D8FDA248CE3FF00943130176CB639E4D5131CBF9C077A9A7E55A602EE08190F28A99131414C440012EE90620B75034F6D62C67FD36E01AA78B350E96DBD321213119B35019936850758E75C7ACF9DD46FF6F81898D37C80B0D053C62259C09147C12A3DC4DBC140C9522C992A33964D2A4433CDEB525A8CF329C4A37225CDA25C50E628A6152039EBF76A69EE2AB6EA355A3EB17175D46A632B7DF851332524D9566CCCE78A8958A56A2FAC72D7DE5DE79F8999FCC03333E19D12F2B1FE401E84BCAC7F9007A12F2B1FE401E84BCAC4B6CFF328AE663231D129028F82D594D0C1F958884EE1044955636E98911835CEA0B11A83AB42CB8D565AC76BF6388DBD9146F0B215531112062B231BA21605548E816A181F9D5757A98262B3880320E9F7E2390FE4343AC0FD04D11ACE32100CF2CC8A600233F9458085C044672827055322B32EEFAAC54CA99EB0EF56579C4DB778BA5F6B81B746E362AB7081190D4A393B34E9F1D294789F69D7331ED3B0F4DFBB1ED3B0F4DFBB1ED4B0F4DFBB1ED3B0F4DFC38F6A587A6FE1C7B4EC3D37F0E338DD2C2263C13ADFBB009B695832D01AF6DE81CD0B749FAB5DAAE561717474F3BABFAE62EE3CD62CCEE60359A036F76039C428904CB4F9CD65CFCCD3FD1A88F02AA22CB2AB3A0C12430523552E30C5CDE5510DB7A50B35810044AEAB7B5A352AAC8EE18C7F01B3ABB5C0DED85AC3EDCC8860E58033323349F0B0C4B9B11B2CDA53B848CB0552411121115562DAB4FC5F858BAB4B4B7863EC739B90A8069A66565C464227C43E26277B0B689DB8464E5D58679096994E9D5A9CFF001701BC36DA06C190120DAC339864D0BEAEAD4E229F838379EDF9800C9150C59165119F0809D458F063A63036570ED0B0BD911BA99E81985F5ABAE79878C7C5C5E2ACDA6B65E8ADE8B7641C866A26877836BAB36D09D0B8D35BF498CEAB531AF9C57A55D5974674D5553F07136F6F305A4C88A18640BC96A5DCF89C245ACE57381F67A78B4B1AC893172243053259656C86908C9E654EADC99E163B098AF70EF0741153953A9D676B041CB8DAADE7A6E6DEC9BDE0A2328A8C48E2071F99FF00D1DFF2B311699664FB4BCA23F68130E311671194DAAEC40BFD6744B1B66CD1005677C8CCF38E38666CA0C4FF0097C98DFAEF72B9EE1B4585C4C490651353326D39941D201A83E26076C2BA29DB0ED8AF46E86224E523C323F0752B2E7F818B0BCD8EFF00BE5ADCF1D27232D5C8C8F68AA4784FED958B23BCB76293732D55A01BB3100628A99752DAFAFD0D5E1EA1DD9AB9319EA4E8D55EAD539D357355F5757F2B4BEC71046D896348CE112354D44865B542C8ECAA100E7F38AEAF16576332663733AFD592A23512009115B248E8D3B510AEBC2D1B2BFBB5F15C1C836B90C8619D6718C178B8FCB31746277A497A1CC8E8AA6560225F3DF5D18FCC7BCDE18774783588989CE64664EE0A4C7C4A7B3C7E5759C66170EBA41C4F8260C6E272FA418FCC74F2A770B648C7EA858DA865F4B1B66F3580DA58A3228999AC8F3650223972F59CD563F32B11623BC406E325DCF3ED06214B131E13AA9D2230F918B0EEFB3AAD9D6764C89B39B80283B62201E1211EAC96C00A028C6CFBC22CFF000EBCBF7CA9A931859CC67CCEE81E421ED0BCDB316AD55DF7E535EC9B9BC7AE0A098086EA1DB888F649072C15A8BA3B262F83ABC579CFF71E0A8ABAB52BA3533EDF4FE376FD4621EE132480A58C15CC894C013D7C25121CBAEBAF8BE5E2FB6A484C1AAD809092CAB0621D722B596525CCB5E9622CAC6F0ADEDC0A4A17404E525399F68047CD88BEBCB936DD8D343A67221A66A0A28A44292F8389B2BEBD965BCE55840804965D31A84B1123C5A5BAAEA455B7B25B68348F01CD599748F1F3973E2E6D9973249BD7779B90981E36E625A99D350F20F26090CDC99A6714940880CCC4F46558009E0DDB63F4098349C65042511CB501C10F0E3F19EF65F884C53ADC3CB953A7A74E9E9FC4A303B8EE556E11B5A89C291C9431EF0F4AE045615F5AD3F80AC03DCACEF6DD4C1BC42A6020C6E26AB155B18C9EB5A2ED91AAC7EA766ED167D5E2AA0B568D7D3A473AB3D6A34EAA34E9EAE9AFB2C319736C1742A1998038898CA784FA660A90A7B4C39F02D10AFAE8A0616D6A2A5DCA84E4351AC7DA2BBDA19A9CFD5622E3F0BB468BF8F56563354971D53C3E3E78F645A7A21F271EC8B4F443E4E3D9169E887C9C7B22D3D10F938F645A7A21F271EC8B4F443E4E266768B4CA2339C9433E0F9B83DA36E31B1B4951BB72EE62B150690D483B869096BE99B29305F5781DC5810B7EEE6126A3180194AE346DC54A1CEE02DC2CD7DE0C4DABE36632F7BF56244A33898CA63F64E3547526DEDA659270598E630309BB0B75CD6E7A9600B7A0C74D8AD5D3EB7016C2D8732D66537119E791C71F0FD8D27EAFF658CE172511EFC4E3B39FA58ECE7E963B39FA58ECE7E96291514CFCAC571194C47BF39E585EDF6100C4D8D45BADDA2698906F47E175AB85DDF0975DD7D52D3F5A789348CC1CC40D444453031E001D492A43DC2AE0EE254FDD570853EDDB4B937298225F2CF126EADEB0D37ADA8D6B7FB5C45A8B557C57E63676B7F1EAF70A6BA685318811621F40F16AA343EEB0036BB8DB6EF272C855BEE31DCAE8A159564AB946ADBDC05242C0AD1D9F8F888DC366DC2D8B2CC892B1BC57CD6D99933FA38A442FE4A672818B0B9CF3F43889B5DA58B129A75F736859AFDFE21444BEF59CBF518B65A37183718B1F68AB61EEF6D2FB6266AEDEE4384EF2E757BB9A2B6BD3FDC5B3156F846E9BD5E15F5A5D2C5CBDB6DC6536E39C55A6D112EF17A605C1D7B74BEC30F8BC0FC22FB70B827B2D5EA2B7001ECAD6DD6C602ED8F4EDD6BEC8FB5C671D313E09FD2FB1D76DAC5C0D12E44C0B06279B4CE60A9AB93113B7A2C2FE151C21A0366F98F8B74AD54B19F7894D7F598B5658DB9B4B6B96F7EDA8CE2DEF00DEB9B755CA09B0CB766881B4EDCEAD071F66DC32D36FBDD3EF56F16E91BF1EEB313AE4DB9885303F0DBA0AB517D45D7FC989CADEF2025B6CC569C91005A5BD7178B3D3F57EB8ADEDEBA7AC65B76586C0B1DDF0EED62AD1966736EDB528E3E812AEA2D56F89DEB0CBADC07F0B5CDC32E02EEE5A2BA7516607A8B6C8B001770AB560078EBD7C03B6D4B37CBDBEBAD355C3A097B6AEE1A7AABA1EC0A9BA7A29A34353FB7F34CC1EC3B7B577D7E0D375F5D90C85ADA13E75CADD6A09ADECA8EB55A89FDFB11D5E23F186BB763CEA28B83984E7F12C53A76823F2947F2F0094842D4B181580C642231D022231E28FB99DC369E0DEAC448ECCE3C78F3B66DE91AD3703E2979DD36E2CF6D7A8580AB75ADAB644144940C6AD6259895475609B6F69366C2F095A35B6FF00ECB56A97FEDC715D6E063EF895F5CE53FD6C45C458839F1D30DB992B8389FD707766EA70EB5B4285DE0483ACD9D19039242E497D20C2ECD33274664C69749318535BAE1A5E331CC9ACBDC7FFD9);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;


--
-- Definition of table `propinsi`
--

DROP TABLE IF EXISTS `propinsi`;
CREATE TABLE `propinsi` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `propinsi`
--

/*!40000 ALTER TABLE `propinsi` DISABLE KEYS */;
INSERT INTO `propinsi` (`id`,`nama`,`user`,`jam`) VALUES 
 ('1','JAWA BARAT','admin','2010-03-21 20:07:53'),
 ('10','SUMATERA UTARA','admin','2010-03-21 20:07:53'),
 ('11','SUMATERA BARAT','admin','2010-03-21 20:07:53'),
 ('12','RIAU','admin','2010-03-21 20:07:53'),
 ('13','SUMATERA SELATAN','admin','2010-03-21 20:07:53'),
 ('14','KEPULAUAN BANGKA BELITUNG','admin','2010-03-21 20:07:53'),
 ('15','LAMPUNG','admin','2010-03-21 20:07:53'),
 ('16','KALIMANTAN SELATAN','admin','2010-03-21 20:07:54'),
 ('17','KALIMANTAN BARAT','admin','2010-03-21 20:07:54'),
 ('18','KALIMANTAN TIMUR','admin','2010-03-21 20:07:54'),
 ('19','KALIMANTAN TENGAH','admin','2010-03-21 20:07:54'),
 ('2','BANTEN','admin','2010-03-21 20:07:53'),
 ('20','SULAWESI TENGAH','admin','2010-03-21 20:07:54'),
 ('21','SULAWESI SELATAN','admin','2010-03-21 20:07:54'),
 ('22','SULAWESI UTARA','admin','2010-03-21 20:07:54'),
 ('23','GORONTALO','admin','2010-03-21 20:07:54'),
 ('24','SULAWESI TENGGARA','admin','2010-03-21 20:07:54'),
 ('25','NUSA TENGGARA BARAT','admin','2010-03-21 20:07:54'),
 ('26','BALI','admin','2013-02-03 17:22:50'),
 ('27','NUSA TENGGARA TIMUR','admin','2010-03-21 20:07:54'),
 ('28','MALUKU','admin','2010-03-21 20:07:54'),
 ('29','PAPUA','admin','2010-03-21 20:07:54'),
 ('3','DKI JAKARTA','admin','2010-03-21 20:07:53'),
 ('30','MALUKU UTARA','admin','2010-03-21 20:07:54'),
 ('4','D.I. YOGYAKARTA','admin','2010-03-21 20:07:53'),
 ('5','JAWA TENGAH','admin','2010-03-21 20:07:53'),
 ('6','JAWA TIMUR','admin','2010-03-21 20:07:53'),
 ('7','BENGKULU','admin','2010-03-21 20:07:53'),
 ('8','JAMBI','admin','2010-03-21 20:07:53'),
 ('9','NANGGROE ACEH DARUSSALAM','admin','2010-03-21 20:07:53');
/*!40000 ALTER TABLE `propinsi` ENABLE KEYS */;


--
-- Definition of table `sms`
--

DROP TABLE IF EXISTS `sms`;
CREATE TABLE `sms` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nohp` varchar(30) NOT NULL DEFAULT '',
  `transaksiid` varchar(30) NOT NULL DEFAULT '',
  `pesan` varchar(320) NOT NULL DEFAULT '',
  `jenis` char(1) NOT NULL DEFAULT '',
  `kirim` char(1) NOT NULL DEFAULT '',
  `user` varchar(30) NOT NULL DEFAULT '',
  `jam` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`transaksiid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sms`
--

/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;


--
-- Definition of table `smstemplate`
--

DROP TABLE IF EXISTS `smstemplate`;
CREATE TABLE `smstemplate` (
  `pesan` varchar(320) NOT NULL DEFAULT '',
  `jenis` char(1) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `smstemplate`
--

/*!40000 ALTER TABLE `smstemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `smstemplate` ENABLE KEYS */;


--
-- Definition of table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `nama` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `alamat` varchar(300) NOT NULL,
  `kotaid` varchar(30) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`kotaid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` (`id`,`nama`,`contact`,`alamat`,`kotaid`,`telepon`,`user`,`jam`) VALUES 
 ('1','2','3','4','20100321-200822145','6','admin','2013-01-28 10:29:55'),
 ('2','3','4','5','6','7','admin','2012-11-08 16:08:15');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `passw` varchar(30) NOT NULL,
  `code` varchar(4) NOT NULL,
  `level` char(1) NOT NULL,
  `departemenid` varchar(30) NOT NULL,
  `aktif` char(1) NOT NULL,
  `user` varchar(30) NOT NULL,
  `jam` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id2` (`departemenid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`,`passw`,`code`,`level`,`departemenid`,`aktif`,`user`,`jam`) VALUES 
 ('admin','n105m100a','ADMN','1','20130314-091006','1','admin','2013-03-22 13:43:34');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `userdetail`
--

DROP TABLE IF EXISTS `userdetail`;
CREATE TABLE `userdetail` (
  `id` varchar(30) DEFAULT NULL,
  `menu` varchar(100) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetail`
--

/*!40000 ALTER TABLE `userdetail` DISABLE KEYS */;
INSERT INTO `userdetail` (`id`,`menu`) VALUES 
 ('admin','mnSetup'),
 ('admin','mnPropinsi'),
 ('admin','mnKota'),
 ('admin','mnKecamatan'),
 ('admin','mnKelurahan'),
 ('admin','mnAgama'),
 ('admin','mnPekerjaan'),
 ('admin','mnPendidikan'),
 ('admin','mnDepartemen'),
 ('admin','mnDatabase'),
 ('admin','mnBackup'),
 ('admin','mnRestore'),
 ('admin','mnUser'),
 ('admin','mnOptions'),
 ('admin','mnProfile'),
 ('admin','mnAccounting'),
 ('admin','mnChartOfAccount'),
 ('admin','mnAccount'),
 ('admin','mnHeader'),
 ('admin','mnJurnalUmum'),
 ('admin','mnTutupBuku'),
 ('admin','mnNeracaSaldoAwal'),
 ('admin','mnTransaksiKasBank'),
 ('admin','mnKodeTransaksiKasBank'),
 ('admin','mnTransaksiKas'),
 ('admin','mnTransaksiBank'),
 ('admin','mnAktivaTetap'),
 ('admin','mnKelompok'),
 ('admin','mnAktivaTetap1'),
 ('admin','mnAkumulasiPenyusutan'),
 ('admin','mnKeuangan'),
 ('admin','mnBank'),
 ('admin','mnPendapatan'),
 ('admin','mnPendapatanCek'),
 ('admin','mnPendapatanCek1'),
 ('admin','mnPendapatanCekCair'),
 ('admin','mnPendapatanCek2'),
 ('admin','mnPendapatanTransfer'),
 ('admin','mnPendapatanTunai'),
 ('admin','mnPengeluaran'),
 ('admin','mnPengeluaranCek'),
 ('admin','mnPengeluaranCek1'),
 ('admin','mnPengeluaranCekCair'),
 ('admin','mnPengeluaranCek2'),
 ('admin','mnPengeluaranTransfer'),
 ('admin','mnPengeluaranTunai'),
 ('admin','mnGudang'),
 ('admin','mnKategori'),
 ('admin','mnSubKategori'),
 ('admin','mnSatuan'),
 ('admin','mnBarang'),
 ('admin','mnKonversiSatuan'),
 ('admin','mnGudang1'),
 ('admin','mnPermintaanBarang'),
 ('admin','mnTerimaBarang'),
 ('admin','mnPakaiBarang'),
 ('admin','mnMutasiGudang'),
 ('admin','mnRevisiStok'),
 ('admin','mnBarangHilang'),
 ('admin','mnSupplier'),
 ('admin','mnPembelian'),
 ('admin','mnReturPembelian'),
 ('admin','mnProduksi'),
 ('admin','mnKategoriProduk'),
 ('admin','mnSatuan1'),
 ('admin','mnProduk'),
 ('admin','mnMesin'),
 ('admin','mnProduksi1'),
 ('admin','mnQC'),
 ('admin','mnRevisiStok1'),
 ('admin','mnPenjualan'),
 ('admin','mnPelanggan'),
 ('admin','mnPesanan'),
 ('admin','mnPenjualan1'),
 ('admin','mnReturPenjualan'),
 ('admin','mnSuratJalan'),
 ('admin','mnPersonalia'),
 ('admin','mnBagian'),
 ('admin','mnJabatan'),
 ('admin','mnHariKerja'),
 ('admin','mnJamKerja'),
 ('admin','mnKaryawan'),
 ('admin','mnKehadiran'),
 ('admin','mnIjinTidakHadir'),
 ('admin','mnKehadiran1'),
 ('admin','mnPenggajian'),
 ('admin','mnPph21'),
 ('admin','mnPTKP'),
 ('admin','mnKomponenGaji'),
 ('admin','mnSettingGajiKaryawan'),
 ('admin','mnProsesGajiKaryawan'),
 ('admin','mnLaporan'),
 ('admin','mnLapAccounting'),
 ('admin','mnDaftarAccount'),
 ('admin','mnDaftarAktivaTetap'),
 ('admin','mnDaftarSaldo'),
 ('admin','mnLapJurnalUmum'),
 ('admin','mnBukuBesar'),
 ('admin','mnLaporanLabaRugi'),
 ('admin','mnLaporanLabaRugiDetail'),
 ('admin','mnNeraca'),
 ('admin','mnNeracaDetail'),
 ('admin','mnNeracaLajur'),
 ('admin','mnNeracaKomparatif'),
 ('admin','mnNeracaKomparatifDetail'),
 ('admin','mnCatatanAtasLaporanKeuangan'),
 ('admin','mnLaporanTransaksiKasBank'),
 ('admin','mnLapKeuangan'),
 ('admin','mnLaporanKas'),
 ('admin','mnLaporanBank'),
 ('admin','mnKartuHutang'),
 ('admin','mnLaporanHutang'),
 ('admin','mnLaporanTunggakanHutang'),
 ('admin','mnKartuPiutang'),
 ('admin','mnLaporanPiutang'),
 ('admin','mnLaporanTunggakanPiutang'),
 ('admin','mnLapGudang'),
 ('admin','mnKartuStok'),
 ('admin','mnLaporanStok'),
 ('admin','mnLaporanTerimaBarang'),
 ('admin','mnLaporanMutasiGudang'),
 ('admin','mnLaporanRevisiStok'),
 ('admin','mnLaporanBarangHilang'),
 ('admin','mnDaftarSupplier'),
 ('admin','mnLaporanPembelian'),
 ('admin','mnLaporanReturPembelian'),
 ('admin','mnLapProduksi'),
 ('admin','mnDaftarProduk'),
 ('admin','mnDaftarFormulaProduk'),
 ('admin','mnLaporanProduksi'),
 ('admin','mnLaporanQC'),
 ('admin','mnLaporanRevisiStokProduk'),
 ('admin','mnLapPenjualan'),
 ('admin','mnDaftarPelanggan'),
 ('admin','mnLaporanPesanan'),
 ('admin','mnLaporanPenjualan'),
 ('admin','mnLaporanReturPenjualan'),
 ('admin','mnLaporanSuratJalan'),
 ('admin','mnLapPersonalia'),
 ('admin','mnDaftarKaryawan'),
 ('admin','mnLaporanGajiKaryawan'),
 ('admin','mnLaporanKehadiranKaryawan'),
 ('admin','mnSSP'),
 ('admin','mnSPTMasa'),
 ('admin','mnForm1721A1'),
 ('admin','mnForm1721I'),
 ('admin','mnForm1721II'),
 ('admin','mnForm1721T');
/*!40000 ALTER TABLE `userdetail` ENABLE KEYS */;


--
-- Definition of table `variabel`
--

DROP TABLE IF EXISTS `variabel`;
CREATE TABLE `variabel` (
  `id` varchar(30) NOT NULL DEFAULT '',
  `keterangan` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `variabel`
--

/*!40000 ALTER TABLE `variabel` DISABLE KEYS */;
INSERT INTO `variabel` (`id`,`keterangan`) VALUES 
 ('accgaji','860-01'),
 ('accgirokeluar','400-14'),
 ('accgiromasuk','150-07'),
 ('acchilang','850-05'),
 ('acchpp','850-06'),
 ('acchutang','400-03'),
 ('acckas','100-01'),
 ('acckasksu','100-01'),
 ('acclaba','600-01'),
 ('accmodal','600-04'),
 ('accpembulatan','120-01'),
 ('accpembulatanksu','700-06'),
 ('accpenjualan','701-01'),
 ('accpersediaan','120-01'),
 ('accpiutang','150-02'),
 ('accpotonganpembelian','850-02'),
 ('accpotonganpenjualan','850-05'),
 ('accpph22beli','400-07'),
 ('accppn','400-07'),
 ('accppnbeli','400-07'),
 ('accrevisi','850-05'),
 ('accservice',''),
 ('accshuksu','600-01'),
 ('ebulan','15'),
 ('editbiaya','1'),
 ('ehari','3'),
 ('eminggu','7'),
 ('nogudang','1'),
 ('nokeuangan','1'),
 ('nopembelian','1'),
 ('npembulatan','100'),
 ('npph22beli','0'),
 ('nppn','0'),
 ('nppnbeli','0'),
 ('port','4'),
 ('pph22beli','0'),
 ('ppnbeli','10'),
 ('ppnjual','10'),
 ('smsport','5'),
 ('versi','1.0.048-86');
/*!40000 ALTER TABLE `variabel` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
